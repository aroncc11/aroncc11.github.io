using UnityEngine;

/// <summary>Plataforma que se mueve; el jugador copia su desplazamiento mientras está encima.</summary>
public abstract class MovingBase : MonoBehaviour
{
    public Vector3 Delta { get; protected set; }
}
