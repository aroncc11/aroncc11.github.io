using UnityEngine;

// Animación procedural del gato por partes (caminar, saltar, cola, cabeza).
// Los pivotes los crea BuildSurieLevel. Eje del gato: +Z adelante, X lateral.
public class CatAnimator : MonoBehaviour
{
    public Transform body, head, tail;
    public Transform frontP, frontN, backP, backN;   // patas (pivote en la cadera)
    public PlayerController2D player;                 // opcional: para saber si está en el suelo
    public bool idleOnly = false;                     // Benito: solo cola y respiración
    public float stride = 11f, swing = 42f;

    float phase, sp;
    Vector3 lastPos;
    // ---- gestos de inactividad (v2): estirarse y bostezar, olfatear/buscar, tomar agua
    float idleT, nextGestureAt = 6f, gt;
    int gesture;                 // 0 = ninguno, 1 = estirarse+bostezo, 2 = buscar, 3 = tomar agua
    GameObject plate;
    static readonly float[] GestureLen = { 0f, 5.6f, 5.2f, 7.2f };

    void Start() { lastPos = transform.position; }

    void Update()
    {
        float dt = Mathf.Max(Time.deltaTime, 0.0001f);
        Vector3 d = transform.position - lastPos; lastPos = transform.position;
        bool climbing = player != null && player.Climbing;
        float speed = idleOnly ? 0f : new Vector3(d.x, climbing ? d.y : 0f, d.z).magnitude / dt;
        bool air = false;
        if (player != null) air = (!player.Grounded && !player.Climbing) || player.IsDashing;
        sp = Mathf.Lerp(sp, speed, Mathf.Clamp01(12f * dt));
        float k = Mathf.Clamp01(sp / 1.2f);

        // ----- gestos al quedarse quieta (solo Surie; Benito tiene idleOnly)
        bool still = !idleOnly && player != null && !air && !climbing && sp < 0.05f && Time.timeScale > 0f;
        idleT = still ? idleT + dt : 0f;
        if (gesture != 0 && !still) EndGesture();
        if (gesture == 0 && still && idleT > nextGestureAt) StartGesture(Random.Range(1, 4));
        if (gesture != 0)
        {
            gt += dt;
            if (gt >= GestureLen[gesture]) EndGesture(); else { ApplyGesture(); return; }
        }

        phase += dt * stride * (0.4f + k);
        float s = Mathf.Sin(phase) * swing * k;
        if (climbing)
        {
            float cs = Mathf.Sin(phase * 1.3f) * 32f * (0.25f + k);
            Set(frontP, -55f + cs); Set(frontN, -55f - cs); Set(backP, 25f - cs); Set(backN, 25f + cs);
        }
        else if (air)
        {
            // pose de salto: patas delanteras adelante, traseras atrás
            Set(frontP, -50f); Set(frontN, -50f); Set(backP, 40f); Set(backN, 40f);
        }
        else
        {
            Set(frontP, s); Set(backN, s);        // diagonales
            Set(frontN, -s); Set(backP, -s);
        }
        if (body) body.localPosition = new Vector3(0f, air ? 0f : Mathf.Abs(Mathf.Sin(phase)) * 0.015f * k + Mathf.Sin(Time.time * 2f) * 0.003f, 0f);
        if (head) head.localRotation = Quaternion.Euler(air ? -12f : Mathf.Sin(phase * 2f) * 3f * k, Mathf.Sin(Time.time * 0.8f) * 6f * (1f - k), 0f);
        if (tail) tail.localRotation = Quaternion.Euler(air ? 20f : 0f, Mathf.Sin(Time.time * (2f + 3f * k)) * 22f, 0f);
    }

    static void Set(Transform t, float ang) { if (t) t.localRotation = Quaternion.Euler(ang, 0f, 0f); }

    // ------------------------------------------------------------------ gestos
    void StartGesture(int g)
    {
        gesture = g; gt = 0f;
        Analytics.Event("gesto_idle", g == 1 ? "estirarse" : g == 2 ? "buscar" : "agua");
        if (g == 3) MakePlate();
    }

    void EndGesture()
    {
        gesture = 0; gt = 0f; idleT = 0f;
        nextGestureAt = Random.Range(5f, 9f);
        if (head) head.localScale = Vector3.one;
        if (plate != null) Destroy(plate);
        plate = null;
    }

    static float Ease(float a, float b, float t) { return Mathf.Clamp01((t - a) / Mathf.Max(0.0001f, b - a)); }
    static float Smooth(float x) { return x * x * (3f - 2f * x); }

    void ApplyGesture()
    {
        float t = gt;
        if (gesture == 1)
        {
            // 0-0.8 se prepara · 0.8-2.8 estirón (patas delanteras adelante, cola arriba) · 2.8-3.4 vuelve · 3.4-5.0 bostezo
            float st = Smooth(Ease(0f, 0.8f, t)) * (1f - Smooth(Ease(2.8f, 3.4f, t)));
            float ya = Smooth(Ease(3.3f, 3.7f, t)) * (1f - Smooth(Ease(4.8f, 5.4f, t)));
            Set(frontP, -38f * st); Set(frontN, -38f * st);
            Set(backP, 6f * st); Set(backN, 6f * st);
            if (head) { head.localRotation = Quaternion.Euler(12f * st - 40f * ya, 0f, 0f); head.localScale = new Vector3(1f, 1f + 0.06f * ya, 1f + 0.14f * ya * (0.8f + 0.2f * Mathf.Sin(t * 10f))); }
            if (tail) tail.localRotation = Quaternion.Euler(50f * st, Mathf.Sin(t * 3f) * 10f, 0f);
            if (body) body.localPosition = new Vector3(0f, 0.02f * st + 0.004f * Mathf.Sin(t * 2f), 0f);
        }
        else if (gesture == 2)
        {
            // mira a un lado, al otro y olfatea el piso
            float yaw = Mathf.Sin(t * 2.2f) * 42f * (1f - Smooth(Ease(3.3f, 3.8f, t)));
            float sniff = Smooth(Ease(3.3f, 3.8f, t)) * (1f - Smooth(Ease(4.7f, 5.1f, t)));
            Set(frontP, 12f * sniff); Set(frontN, 12f * sniff); Set(backP, 0f); Set(backN, 0f);
            if (head) head.localRotation = Quaternion.Euler(30f * sniff + Mathf.Sin(t * 16f) * 4f * sniff, yaw, 0f);
            if (tail) tail.localRotation = Quaternion.Euler(18f, Mathf.Sin(t * 2.2f) * 25f, 0f);
        }
        else
        {
            // 0-0.6 aparece el plato · 0.6-1.2 se agacha · 1.2-5.2 lengüetazos · 5.2-6.0 se relame · 6.0-7.2 el plato se va
            float down = Smooth(Ease(0.6f, 1.2f, t)) * (1f - Smooth(Ease(5.2f, 5.8f, t)));
            float lap = Mathf.Sin(t * 14f) * 6f * (t > 1.2f && t < 5.2f ? 1f : 0f);
            Set(frontP, 16f * down); Set(frontN, 16f * down); Set(backP, -4f * down); Set(backN, -4f * down);
            if (head) head.localRotation = Quaternion.Euler(46f * down + lap, 0f, 0f);
            if (tail) tail.localRotation = Quaternion.Euler(10f, Mathf.Sin(t * 5f) * 18f, 0f);
            if (body) body.localPosition = new Vector3(0f, -0.03f * down, 0f);
            if (plate != null)
            {
                float sc = Smooth(Ease(0f, 0.5f, t)) * (1f - Smooth(Ease(6.0f, 7.0f, t)));
                float pop = 1f + 0.25f * Mathf.Sin(Mathf.Clamp01(t / 0.5f) * Mathf.PI);
                plate.transform.localScale = new Vector3(0.28f, 0.03f, 0.28f) * Mathf.Max(0.001f, sc * pop);
            }
        }
    }

    void MakePlate()
    {
        if (plate != null) Destroy(plate);
        plate = new GameObject("Plato_Agua");
        Vector3 fwd = transform.forward; fwd.y = 0f; fwd.Normalize();
        Vector3 p = transform.position + fwd * 0.62f;
        RaycastHit hit;
        if (Physics.Raycast(p + Vector3.up * 0.6f, Vector3.down, out hit, 3f)) p.y = hit.point.y;
        plate.transform.position = p + Vector3.up * 0.015f;
        // clona un material del nivel (así se ve igual en el editor y en WebGL)
        Material src = null;
        foreach (var r in Object.FindObjectsByType<Renderer>(FindObjectsSortMode.None))
            if (r.sharedMaterial != null && !r.transform.IsChildOf(transform) && !(r is LineRenderer)) { src = r.sharedMaterial; break; }
        Color[] cols = { new Color(0.95f, 0.95f, 0.9f), new Color(0.3f, 0.62f, 0.95f) };
        float[] ys = { 0f, 0.022f }, ss = { 1f, 0.82f };
        for (int i = 0; i < 2; i++)
        {
            var c = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            Destroy(c.GetComponent<Collider>());
            c.transform.SetParent(plate.transform, false);
            c.transform.localPosition = new Vector3(0f, ys[i] / 0.03f * 0.5f, 0f);
            c.transform.localScale = new Vector3(ss[i], i == 0 ? 0.5f : 0.45f, ss[i]);
            var rr = c.GetComponent<Renderer>();
            if (src != null) { rr.material = new Material(src); }
            rr.material.color = cols[i];
        }
        plate.transform.localScale = Vector3.one * 0.001f;
    }
}
