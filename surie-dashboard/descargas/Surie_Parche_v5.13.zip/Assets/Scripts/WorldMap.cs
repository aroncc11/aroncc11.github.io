using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Mapa del mundo en 3D: una maqueta de la casa con una estación por nivel. Surie camina de una a otra con A/D
/// (o flechas); Espacio/Enter entra al nivel y M al minijuego (si se ganó con las 5 letras).
/// La escena la construye Surie ▸ Construir mundo y niveles (objetos "Estacion_0".."Estacion_5", "Surie_Mapa").
/// </summary>
public class WorldMap : MonoBehaviour
{
    public Transform[] stops;          // posición de cada estación (en orden)
    public Transform surie;
    public Transform[] locks;          // candado / aviso de cada estación (se oculta al desbloquear)
    public Transform[] flags;          // bandera de cada estación (se muestra al superarla)
    public Camera cam;

    float pos;                         // 0..N-1 entre estaciones
    bool entering;
    float t0;
    float bob;
    int hover = -1;
    string toast = ""; float toastUntil;
    GUIStyle sT, sS, sB;

    int MaxReach() { int m = 0; for (int i = 0; i < stops.Length; i++) if (Progress.Unlocked(i)) m = i; return m; }

    void Start()
    {
        Time.timeScale = 1f;
        Analytics.Level = 0;
        AudioManager.PlayMusic("musica_menu");
        AudioManager.Duck(false);
        pos = Mathf.Clamp(Progress.Current, 0, Mathf.Max(0, stops.Length - 1));
        // al volver de un nivel superado, Surie aparece en el siguiente si ya está desbloqueado
        if (Progress.Done(Progress.Current) && Progress.Current + 1 < stops.Length) pos = Progress.Current + 1;
        t0 = Time.time;
        for (int i = 0; i < stops.Length; i++)
        {
            if (locks != null && i < locks.Length && locks[i] != null) locks[i].gameObject.SetActive(!Progress.Unlocked(i));
            if (flags != null && i < flags.Length && flags[i] != null) flags[i].gameObject.SetActive(Progress.Done(i));
        }
        Place(true);
        PlayerPrefs.SetInt("surie_mundo_visto", 1);
    }

    Vector3 PointAt(float p)
    {
        int a = Mathf.Clamp(Mathf.FloorToInt(p), 0, stops.Length - 1), b = Mathf.Min(a + 1, stops.Length - 1);
        float f = Mathf.Clamp01(p - a);
        f = f * f * (3f - 2f * f);
        Vector3 v = Vector3.Lerp(stops[a].position, stops[b].position, f);
        return v;
    }

    void Place(bool snap)
    {
        if (surie == null) return;
        Vector3 v = PointAt(pos);
        float hop = Mathf.Abs(Mathf.Sin(bob * 8f)) * 0.18f;
        surie.position = v + Vector3.up * (0.45f + hop);
        Vector3 d = PointAt(pos + 0.05f) - PointAt(pos - 0.05f);
        d.y = 0f;
        if (d.sqrMagnitude > 0.0001f) surie.rotation = Quaternion.Slerp(surie.rotation, Quaternion.LookRotation(d.normalized, Vector3.up), snap ? 1f : 0.2f);
        if (cam != null)
        {
            Vector3 goal = v + new Vector3(0f, 7.5f, -9.5f);
            cam.transform.position = snap ? goal : Vector3.Lerp(cam.transform.position, goal, 1f - Mathf.Exp(-4f * Time.deltaTime));
            cam.transform.rotation = Quaternion.Euler(33f, 0f, 0f);
        }
    }

    void Update()
    {
        if (stops == null || stops.Length == 0 || entering) return;
        float h = Inp.Horizontal();
        int reach = MaxReach();
        float before = pos;
        pos = Mathf.Clamp(pos + h * 1.35f * Time.deltaTime, 0f, reach);
        if (Mathf.Abs(pos - before) > 0.0001f) bob += Time.deltaTime;
        // se "pega" a la estación más cercana al soltar la tecla
        if (Mathf.Abs(h) < 0.1f)
        {
            float r = Mathf.Round(pos);
            pos = Mathf.MoveTowards(pos, r, Time.deltaTime * 1.0f);
        }
        hover = Mathf.Abs(pos - Mathf.Round(pos)) < 0.12f ? Mathf.RoundToInt(pos) : -1;
        Place(false);

        if (hover >= 0)
        {
            if (Inp.ConfirmDown() && Time.time - t0 > 0.5f) Enter(hover);
            if (Inp.MiniDown() && Time.time - t0 > 0.5f) TryMini(hover);
        }
        if (Inp.PauseDown()) { Analytics.EndAndReset(); SceneManager.LoadScene("Menu_Surie"); }
    }

    void Enter(int i)
    {
        if (!Progress.Unlocked(i)) { Toast("Este cuarto está cerrado: termina el anterior"); return; }
        entering = true;
        AudioManager.Sfx("cascabel");
        Progress.GoLevel(i);
    }

    void TryMini(int i)
    {
        if (!Progress.HasMini(i)) { Toast("Este nivel no tiene minijuego"); return; }
        if (!Progress.MiniUnlocked(i)) { Toast("Gana el minijuego con las 5 letras S-U-R-I-E y el juguete de este nivel"); return; }
        entering = true;
        Progress.GoMini(i);
    }

    void Toast(string s) { toast = s; toastUntil = Time.time + 3f; AudioManager.Sfx("estres"); }

    void Styles()
    {
        if (sT != null) return;
        sT = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
        sS = new GUIStyle(sT) { wordWrap = true };
        sB = new GUIStyle(sT);
    }

    void OnGUI()
    {
        Styles();
        float k = Screen.height / 720f;
        sT.fontSize = Mathf.RoundToInt(22 * k); sS.fontSize = Mathf.RoundToInt(17 * k); sB.fontSize = Mathf.RoundToInt(30 * k);
        Color c0 = GUI.color;

        // rótulos sobre cada estación
        if (cam != null && stops != null)
            for (int i = 0; i < stops.Length; i++)
            {
                Vector3 sp = cam.WorldToScreenPoint(stops[i].position + Vector3.up * 2.4f);
                if (sp.z < 0f) continue;
                float y = Screen.height - sp.y;
                bool un = Progress.Unlocked(i), dn = Progress.Done(i);
                Rect r = new Rect(sp.x - 120 * k, y - 22 * k, 240 * k, 40 * k);
                GUI.color = new Color(0.1f, 0.05f, 0.18f, un ? 0.8f : 0.6f);
                GUI.DrawTexture(r, Texture2D.whiteTexture);
                GUI.color = dn ? new Color(0.7f, 1f, 0.8f) : (un ? new Color(1f, 0.93f, 0.7f) : new Color(1f, 1f, 1f, 0.5f));
                GUI.Label(r, Progress.Levels[i].name + (dn ? "  ✓" : (un ? "" : "  (cerrado)")), sS);
            }
        GUI.color = c0;

        // barra superior: progreso
        Rect top = new Rect(0, 0, Screen.width, 54 * k);
        GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.85f); GUI.DrawTexture(top, Texture2D.whiteTexture);
        GUI.color = new Color(1f, 0.93f, 0.75f);
        GUI.Label(new Rect(16 * k, 0, 520 * k, 54 * k), "MAPA DE LA CASA", sT);
        GUI.Label(new Rect(Screen.width - 640 * k, 0, 620 * k, 54 * k), "Niveles: " + Progress.DoneCount() + " / " + Progress.Levels.Length + "     Letras: " + Progress.TotalLetters() + " / " + (5 * Progress.Levels.Length), sS);
        GUI.color = c0;

        // panel de la estación actual
        if (hover >= 0 && hover < stops.Length)
        {
            var lv = Progress.Levels[hover];
            bool un = Progress.Unlocked(hover);
            Rect p = new Rect(Screen.width * 0.5f - 330 * k, Screen.height - 190 * k, 660 * k, 170 * k);
            UiKit.Panel(p);
            GUI.color = new Color(1f, 0.9f, 0.5f);
            GUI.Label(new Rect(p.x, p.y + 8 * k, p.width, 36 * k), lv.name, sT);
            GUI.color = Color.white;
            GUI.Label(new Rect(p.x + 20 * k, p.y + 44 * k, p.width - 40 * k, 40 * k), lv.blurb, sS);
            string info = un ? "Letras: " + Progress.Letters(hover) + "/5" + (Progress.Done(hover) ? "   ·   mejor tiempo " + Mathf.RoundToInt(Progress.BestTime(hover)) + " s" : "") : "Cerrado hasta terminar el nivel anterior";
            GUI.color = new Color(0.8f, 0.9f, 1f);
            GUI.Label(new Rect(p.x + 20 * k, p.y + 80 * k, p.width - 40 * k, 30 * k), info, sS);
            string mi = "";
            if (Progress.HasMini(hover)) mi = Progress.MiniUnlocked(hover) ? "M = minijuego «" + lv.miniName + "»" + (Progress.Best(hover) > 0 ? " (récord " + Progress.Best(hover) + ")" : "") : "Minijuego «" + lv.miniName + "»: se gana con S-U-R-I-E + juguete";
            GUI.color = Progress.MiniUnlocked(hover) ? new Color(0.7f, 1f, 0.8f) : new Color(1f, 1f, 1f, 0.55f);
            GUI.Label(new Rect(p.x + 20 * k, p.y + 106 * k, p.width - 40 * k, 30 * k), mi, sS);
            GUI.color = new Color(1f, 0.93f, 0.75f);
            GUI.Label(new Rect(p.x, p.y + 134 * k, p.width, 30 * k), un ? "ESPACIO / ENTER = entrar" : "", sS);
            GUI.color = c0;
        }
        else
        {
            GUI.color = new Color(1f, 1f, 1f, 0.85f);
            GUI.Label(new Rect(0, Screen.height - 60 * k, Screen.width, 40 * k), "A / D o flechas: caminar entre cuartos     ·     Esc: menú", sS);
            GUI.color = c0;
        }

        if (Time.time < toastUntil)
        {
            GUI.color = new Color(0f, 0f, 0f, 0.7f);
            GUI.DrawTexture(new Rect(Screen.width * 0.2f, 90 * k, Screen.width * 0.6f, 56 * k), Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUI.Label(new Rect(Screen.width * 0.2f, 90 * k, Screen.width * 0.6f, 56 * k), toast, sS);
            GUI.color = c0;
        }
        if (Progress.AllDone())
        {
            GUI.color = new Color(1f, 0.95f, 0.5f);
            GUI.Label(new Rect(0, 60 * k, Screen.width, 40 * k), "★ ¡Recuperaste todos los juguetes! ★", sB);
            GUI.color = c0;
        }
    }
}
