using System;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

/// <summary>
/// Registro de métricas de juego (telemetría local). Escribe 3 CSV en
/// Application.persistentDataPath/SurieMetrics/ :
///   sessions.csv  → una fila por partida (duración, resultado, sección máxima, caídas...)
///   events.csv    → cada evento (salto, dash, caída, estrés, letra, cascabel, checkpoint, victoria...)
///   positions.csv → posición de Surie cada 0.25 s (para el mapa de calor)
/// El Dashboard (Dashboard_Metricas_Surie.html) lee estos archivos.
/// </summary>
public class Analytics : MonoBehaviour
{
    public static Analytics I;
    public const float Scale = 0.15f;                       // 1 cm de maqueta = 0.15 m
    // inicio de cada sección en cm (los pone el builder del nivel)
    public static float[] SectionStartsCm = { 0, 30, 60, 90, 104, 140, 170, 200, 230 };
    public static string[] SectionNames = { "1 Inicio", "2 Desarrollo", "3 Variación", "4 Complicación", "5 Foso", "6 Cojines", "7 Estantes", "8 Salto final", "9 Cocina y TV" };

    // v2: nivel que se está jugando (0 = sala). Las secciones de los niveles 2+ se numeran desde 21, 41...
    // para no mezclarlas con las 9 secciones del nivel 1 en el dashboard.
    public static int Level;
    static int SecOffset { get { return Level * 20; } }

    public string SessionId { get; private set; }
    public static string Folder { get { return Path.Combine(Application.persistentDataPath, "SurieMetrics"); } }

    StringBuilder evBuf = new StringBuilder(), posBuf = new StringBuilder();
    float start, nextSample, nextFlush;
    int jumps, dashes, falls, stressHits, letters, croquetas, rests;
    int maxSection;
    string result = "abandono";
    bool closed;
    float lastX;

    public static void Ensure()
    {
        if (I != null) return;
        var go = new GameObject("Analytics");
        DontDestroyOnLoad(go);
        I = go.AddComponent<Analytics>();
    }

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        SessionId = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        start = Time.realtimeSinceStartup;
        try { Directory.CreateDirectory(Folder); } catch (Exception) { }
        Log("session_start", Vector3.zero, SystemInfo.deviceModel);
        Log("version", Vector3.zero, BuildInfo.Version);
    }

    public static int SectionOf(float xcm)
    {
        int s = 0;
        for (int i = 0; i < SectionStartsCm.Length; i++) if (xcm >= SectionStartsCm[i]) s = i;
        return s;
    }

    static string F(float v) { return v.ToString("0.00", CultureInfo.InvariantCulture); }

    public void Log(string ev, Vector3 worldPos, string extra = "")
    {
        float t = Time.realtimeSinceStartup - start;
        float xcm = worldPos.x / Scale, ycm = worldPos.y / Scale;
        int sec = SectionOf(xcm);
        evBuf.Append(SessionId).Append(',').Append(F(t)).Append(',').Append(ev).Append(',').Append(F(xcm)).Append(',').Append(F(ycm)).Append(',').Append(sec + 1 + SecOffset).Append(',').Append(extra.Replace(',', ';')).Append('\n');
        CloudSync.AddEvent(SessionId, t, ev, xcm, ycm, sec + 1 + SecOffset, extra);
        AudioManager.ForEvent(ev);
        switch (ev)
        {
            case "jump": jumps++; break;
            case "dash": dashes++; break;
            case "fall": case "water": falls++; break;
            case "stress": stressHits++; break;
            case "letter": letters++; break;
            case "croqueta": croquetas++; break;
            case "rest": rests++; break;
            case "win": result = "victoria"; break;
        }
    }

    /// <summary>Atajo: evento en la posición actual de Surie.</summary>
    public static void Event(string ev, string extra = "")
    {
        if (I == null) return;
        Vector3 p = Vector3.zero;
        if (GameManager.I != null && GameManager.I.player != null) p = GameManager.I.player.transform.position;
        I.Log(ev, p, extra);
    }

    void Update()
    {
        if (GameManager.I == null || GameManager.I.player == null) return;
        if (Time.time >= nextSample && Time.timeScale > 0f)
        {
            nextSample = Time.time + 0.25f;
            var p = GameManager.I.player;
            Vector3 w = p.transform.position;
            float xcm = w.x / Scale, ycm = w.y / Scale;
            int sec = SectionOf(xcm);
            if (sec + 1 > maxSection) { maxSection = sec + 1; Log("section_reached", w, Level == 0 && sec < SectionNames.Length ? SectionNames[sec] : "N" + (Level + 1) + " tramo " + (sec + 1)); }
            lastX = xcm;
            string st = p.Climbing ? "trepa" : p.IsDashing ? "dash" : p.Grounded ? "suelo" : "aire";
            CloudSync.AddPosition(SessionId, Time.realtimeSinceStartup - start, xcm, ycm, sec + 1 + SecOffset, st);
            posBuf.Append(SessionId).Append(',').Append(F(Time.realtimeSinceStartup - start)).Append(',').Append(F(xcm)).Append(',').Append(F(ycm)).Append(',').Append(sec + 1 + SecOffset).Append(',').Append(st).Append('\n');
        }
        if (Time.realtimeSinceStartup >= nextFlush) { nextFlush = Time.realtimeSinceStartup + 5f; Flush(false); }
    }

    void Flush(bool final)
    {
        try
        {
            string d = Folder;
            if (evBuf.Length > 0) { File.AppendAllText(Path.Combine(d, "events.csv"), Header(Path.Combine(d, "events.csv"), "session,t,event,x_cm,y_cm,section,extra") + evBuf.ToString()); evBuf.Length = 0; }
            if (posBuf.Length > 0) { File.AppendAllText(Path.Combine(d, "positions.csv"), Header(Path.Combine(d, "positions.csv"), "session,t,x_cm,y_cm,section,state") + posBuf.ToString()); posBuf.Length = 0; }
        }
        catch (Exception) { }
    }

    static string Header(string path, string h) { return File.Exists(path) ? "" : h + "\n"; }

    /// <summary>Cierra la partida y escribe su fila en sessions.csv.</summary>
    public void CloseSession()
    {
        if (closed) return;
        closed = true;
        float dur = Time.realtimeSinceStartup - start;
        Log("session_end", Vector3.zero, result);
        Flush(true);
        try
        {
            string p = Path.Combine(Folder, "sessions.csv");
            string row = SessionId + "," + F(dur) + "," + result + "," + maxSection + "," + jumps + "," + dashes + "," + falls + "," + stressHits + "," + letters + "," + croquetas + "," + rests + "," + F(lastX) + "," + PlayerName.Current.Replace(',', ' ') + "\n";
            CloudSync.AddSession(SessionId, dur, result, maxSection, jumps, dashes, falls, stressHits, letters, croquetas, rests, lastX, PlayerName.Current);
            File.AppendAllText(p, Header(p, "session,duration_s,result,max_section,jumps,dashes,falls,stress_hits,letters,croquetas,rests,last_x_cm,player_name") + row);
        }
        catch (Exception) { }
    }

    /// <summary>Al volver al menú o reiniciar, la partida actual se cierra y la siguiente empieza limpia.</summary>
    public void SetResult(string r) { if (result != "victoria") result = r; }

    public static void EndAndReset()
    {
        if (I == null) return;
        I.CloseSession();
        Destroy(I.gameObject);
        I = null;
    }

    void OnApplicationQuit() { CloseSession(); }
}
