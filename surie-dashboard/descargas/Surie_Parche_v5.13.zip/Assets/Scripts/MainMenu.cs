using System;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Menú principal de "Surie y el juguete robado": arte propio, Cómo jugar, Opciones, Métricas locales y Créditos.</summary>
public class MainMenu : MonoBehaviour
{
    public string levelScene = "Comic_Surie";
    enum Page { Main, Help, Options, Stats, Credits, Name, Scores }
    Page page = Page.Main;
    float t0, fade;
    float volume;
    bool fullscreen;
    string statsText = "";
    char[] nameCh = new char[PlayerName.Len];
    int nameCur;

    void Start()
    {
        Time.timeScale = 1f;
        t0 = Time.realtimeSinceStartup;
        volume = PlayerPrefs.GetFloat("surie_vol", 1f);
        AudioListener.volume = volume;
        fullscreen = Screen.fullScreen;
        AudioManager.PlayMusic("musica_menu");
        AudioManager.Duck(false);
        CloudSync.Ping();
        string saved = PlayerName.Raw.PadRight(PlayerName.Len, ' ');
        for (int i = 0; i < PlayerName.Len; i++) nameCh[i] = char.ToUpperInvariant(saved[i]);
        if (PlayerName.Raw.Trim().Length == 0) { nameCh = "      ".ToCharArray(); }
    }

    void Cycle(int slot, int d)
    {
        int idx = PlayerName.Chars.IndexOf(nameCh[slot]); if (idx < 0) idx = PlayerName.Chars.Length - 1;
        idx = (idx + d + PlayerName.Chars.Length) % PlayerName.Chars.Length;
        nameCh[slot] = PlayerName.Chars[idx];
        AudioManager.Sfx("salto");
    }

    void StartGame()
    {
        string n = new string(nameCh).Trim();
        PlayerName.Save(n.Length == 0 ? "JUGADOR" : n);
        Progress.UpdateBoard();
        Analytics.EndAndReset();
        // v5: la historieta de inicio SIEMPRE se muestra (se puede saltar con el botón SALTAR)
        SceneManager.LoadScene(levelScene);
    }

    string cloudText = "Consultando la base de datos en línea...";
    void Go(Page p)
    {
        page = p;
        if (p == Page.Stats) { statsText = LoadStats(); cloudText = "Consultando la base de datos en línea..."; CloudSync.FetchGlobal(s => cloudText = s); }
    }

    string LoadStats()
    {
        try
        {
            string p = Path.Combine(Analytics.Folder, "sessions.csv");
            if (!File.Exists(p)) return "Aún no hay partidas registradas.\nJuega una vez y vuelve aquí.";
            string[] lines = File.ReadAllLines(p);
            int n = 0, wins = 0, falls = 0, dashes = 0, jumps = 0; float dur = 0; int best = 0;
            for (int i = 1; i < lines.Length; i++)
            {
                string[] c = lines[i].Split(',');
                if (c.Length < 12) continue;
                n++;
                float d; float.TryParse(c[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d); dur += d;
                if (c[2] == "victoria") wins++;
                int ms; int.TryParse(c[3], out ms); best = Math.Max(best, ms);
                int j, da, fa; int.TryParse(c[4], out j); int.TryParse(c[5], out da); int.TryParse(c[6], out fa);
                jumps += j; dashes += da; falls += fa;
            }
            if (n == 0) return "Aún no hay partidas registradas.";
            return "Partidas jugadas: <b>" + n + "</b>\nVictorias: <b>" + wins + "</b> (" + Mathf.RoundToInt(100f * wins / n) + " %)\n" +
                   "Duración media: <b>" + Mathf.RoundToInt(dur / n / 60f * 10f) / 10f + " min</b>\nSección más lejana: <b>" + best + " de 9</b>\n" +
                   "Caídas por partida: <b>" + Mathf.RoundToInt(10f * falls / n) / 10f + "</b>   Dashes: <b>" + Mathf.RoundToInt(10f * dashes / n) / 10f + "</b>   Saltos: <b>" + Mathf.RoundToInt(10f * jumps / n) / 10f + "</b>\n\n" +
                   "Datos en:\n" + Analytics.Folder + "\nAbre Dashboard_Metricas_Surie.html y carga esos CSV.";
        }
        catch (Exception e) { return "No se pudieron leer las métricas: " + e.Message; }
    }

    void OnGUI()
    {
        float k = UiKit.K;
        UiKit.Background();
        // brillo de estrellas animado
        float t = Time.realtimeSinceStartup - t0;
        for (int i = 0; i < 18; i++)
        {
            float x = (i * 137.5f % 100f) / 100f * Screen.width, y = ((i * 61.8f) % 40f) / 100f * Screen.height;
            float a = 0.35f + 0.65f * Mathf.Abs(Mathf.Sin(t * 1.3f + i));
            GUI.color = new Color(1f, 0.95f, 0.7f, a);
            GUI.Label(new Rect(x, y, 30 * k, 30 * k), "✦", UiKit.Small);
        }
        GUI.color = Color.white;

        // logo con respiración
        if (UiKit.logo != null)
        {
            float lw = 460 * k, lh = lw * UiKit.logo.height / UiKit.logo.width;
            float bob = Mathf.Sin(t * 1.6f) * 6f * k;
            GUI.DrawTexture(new Rect(Screen.width * 0.5f - lw * 0.5f, 6 * k + bob, lw, lh), UiKit.logo, ScaleMode.ScaleToFit, true);
        }

        float cx = Screen.width * 0.5f;
        if (page == Page.Main || page == Page.Name)
        {
            // fila inferior (donde está el librero): botones pequeños y separados
            float sbh = 50 * k, sbw = sbh * 640f / 140f, sgap = 14 * k;
            int nb = 6;
            float rowW = nb * sbw + (nb - 1) * sgap;
            if (rowW > Screen.width - 30 * k) { sbw = (Screen.width - 30 * k - (nb - 1) * sgap) / nb; sbh = sbw * 140f / 640f; rowW = Screen.width - 30 * k; }
            float rx = cx - rowW * 0.5f, ry = Screen.height - sbh - 22 * k;
            bool main = page == Page.Main;
            if (UiKit.Button(new Rect(rx, ry, sbw, sbh), "CÓMO JUGAR") && main) Go(Page.Help);
            if (UiKit.Button(new Rect(rx + (sbw + sgap), ry, sbw, sbh), "OPCIONES") && main) Go(Page.Options);
            if (UiKit.Button(new Rect(rx + 2 * (sbw + sgap), ry, sbw, sbh), "MÉTRICAS") && main) Go(Page.Stats);
            if (UiKit.Button(new Rect(rx + 3 * (sbw + sgap), ry, sbw, sbh), "PUNTAJES") && main) Go(Page.Scores);
            if (UiKit.Button(new Rect(rx + 4 * (sbw + sgap), ry, sbw, sbh), "CRÉDITOS") && main) Go(Page.Credits);
            if (UiKit.Button(new Rect(rx + 5 * (sbw + sgap), ry, sbw, sbh), "SALIR") && main)
            {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
                Application.Quit();
#endif
            }
            if (main)
            {
                float bh = 84 * k, bw = bh * 640f / 140f;
                {
                    var kb = new GUIStyle(UiKit.Small); kb.alignment = TextAnchor.MiddleCenter; kb.fontStyle = FontStyle.Bold;
                    GUI.color = Application.isMobilePlatform ? new Color(1f, 0.5f, 0.45f) : new Color(1f, 0.93f, 0.75f);
                    GUI.Label(new Rect(cx - 320 * k, 300 * k + bh + 8 * k, 640 * k, 30 * k),
                        Application.isMobilePlatform ? "Este juego necesita teclado: ábrelo en una computadora" : "Se juega con teclado en computadora: A/D mover · Espacio saltar · Shift dash", kb);
                    GUI.color = Color.white;
                }
                if (UiKit.Button(new Rect(cx - bw * 0.5f, 300 * k, bw, bh), "JUGAR") || (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Return)) { Go(Page.Name); Event.current.Use(); }
            }
            else NameScreen(k, cx);
        }
        else
        {
            Rect pr = new Rect(Screen.width * 0.5f - 380 * k, 215 * k, 760 * k, 395 * k);
            UiKit.Panel(pr);
            Rect inner = new Rect(pr.x + 30 * k, pr.y + 20 * k, pr.width - 60 * k, pr.height - 110 * k);
            switch (page)
            {
                case Page.Help:
                    GUI.Label(new Rect(inner.x, inner.y, inner.width, 44 * k), "Cómo jugar", UiKit.Title);
                    GUI.Label(new Rect(inner.x, inner.y + 50 * k, inner.width, inner.height),
                        "<b>A / D</b> o flechas: moverse     <b>Espacio</b>: saltar\n<b>W</b>: trepar la cortina     <b>Shift / K</b>: dash (gasta 1 energía)\n<b>R</b>: reiniciar     <b>Esc</b>: pausa\n\n" +
                        "Benito se llevó tu juguete. Cruza la casa evitando el agua, el ruido de la TV, la Roomba y los huecos. " +
                        "Cada golpe suma <b>estrés</b> (5 = vuelves a la cama). Descansa sobre cojines y camas para recuperarte, " +
                        "come croquetas para tener energía y reúne las letras <b>S-U-R-I-E</b>.", UiKit.Label);
                    break;
                case Page.Options:
                    GUI.Label(new Rect(inner.x, inner.y, inner.width, 44 * k), "Opciones", UiKit.Title);
                    GUI.Label(new Rect(inner.x, inner.y + 56 * k, 200 * k, 36 * k), "Volumen", UiKit.Label);
                    float nv = GUI.HorizontalSlider(new Rect(inner.x + 210 * k, inner.y + 68 * k, 360 * k, 24 * k), volume, 0f, 1f);
                    if (Mathf.Abs(nv - volume) > 0.001f) { volume = nv; AudioListener.volume = nv; PlayerPrefs.SetFloat("surie_vol", nv); }
                    GUI.Label(new Rect(inner.x, inner.y + 96 * k, 200 * k, 36 * k), "Música", UiKit.Label);
                    float mv = GUI.HorizontalSlider(new Rect(inner.x + 210 * k, inner.y + 108 * k, 360 * k, 24 * k), AudioManager.MusicVol, 0f, 1f);
                    if (Mathf.Abs(mv - AudioManager.MusicVol) > 0.001f) AudioManager.MusicVol = mv;
                    GUI.Label(new Rect(inner.x, inner.y + 136 * k, 200 * k, 36 * k), "Efectos", UiKit.Label);
                    float sv = GUI.HorizontalSlider(new Rect(inner.x + 210 * k, inner.y + 148 * k, 360 * k, 24 * k), AudioManager.SfxVol, 0f, 1f);
                    if (Mathf.Abs(sv - AudioManager.SfxVol) > 0.001f) { AudioManager.SfxVol = sv; AudioManager.Sfx("salto"); }
                    GUI.Label(new Rect(inner.x, inner.y + 176 * k, 300 * k, 36 * k), "Pantalla completa", UiKit.Label);
                    bool fs = GUI.Toggle(new Rect(inner.x + 300 * k, inner.y + 180 * k, 40 * k, 30 * k), fullscreen, "");
                    if (fs != fullscreen) { fullscreen = fs; Screen.fullScreen = fs; }
                    if (GUI.Button(new Rect(inner.x + 420 * k, inner.y + 172 * k, 250 * k, 34 * k), "Borrar progreso del mapa")) { Progress.ResetAll(); AudioManager.Sfx("click"); }
                    GUI.Label(new Rect(inner.x, inner.y + 220 * k, inner.width, 60 * k), "Las métricas de juego se guardan en este equipo y en la base de datos en línea (análisis de diseño).", UiKit.Small);
                    break;
                case Page.Stats:
                    GUI.Label(new Rect(inner.x, inner.y, inner.width, 44 * k), "Mis métricas", UiKit.Title);
                    GUI.Label(new Rect(inner.x, inner.y + 50 * k, inner.width * 0.52f, inner.height), "<b>En este equipo</b>\n" + statsText, UiKit.Small);
                    GUI.Label(new Rect(inner.x + inner.width * 0.55f, inner.y + 50 * k, inner.width * 0.45f, inner.height), "<b>En línea (todos)</b>\n" + cloudText, UiKit.Small);
                    break;
                case Page.Scores:
                    GUI.Label(new Rect(inner.x, inner.y, inner.width, 44 * k), "Puntajes", UiKit.Title);
                    {
                        var bd = Progress.Board();
                        string txt = "";
                        if (bd.Count == 0) txt = "Aún no hay partidas guardadas. ¡Sé el primero!";
                        for (int i = 0; i < bd.Count && i < 7; i++)
                            txt += "<b>" + (i + 1) + ". " + bd[i].name + "</b>  " + bd[i].total + " pts  ·  " + bd[i].done + "/6 niveles\n<i>" + bd[i].detail + "</i>\n";
                        GUI.Label(new Rect(inner.x, inner.y + 46 * k, inner.width, inner.height), txt, UiKit.Small);
                    }
                    break;
                case Page.Credits:
                    GUI.Label(new Rect(inner.x, inner.y, inner.width, 44 * k), "Créditos", UiKit.Title);
                    GUI.Label(new Rect(inner.x, inner.y + 56 * k, inner.width, inner.height),
                        "<b>Diseño de juego:</b>\nAntonio Josué Tostado Estrada\nMarco Antonio Lozano Garza\nAron Covarrubias\n\n<i>Surie y el juguete robado · prototipo 2.5D de plataformas</i>", UiKit.Label);
                    break;
            }
            if (UiKit.Button(new Rect(pr.x + pr.width * 0.5f - 150 * k, pr.y + pr.height - 80 * k, 300 * k, 66 * k), "VOLVER") || (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)) Go(Page.Main);
        }

        {
            Rect br = new Rect(Screen.width - 330 * k, 14 * k, 316 * k, 44 * k);
            UiKit.Panel(br);
            GUI.color = CloudSync.Online ? new Color(0.5f, 1f, 0.7f) : new Color(1f, 0.8f, 0.5f);
            GUI.Label(new Rect(br.x + 16 * k, br.y + 6 * k, br.width, br.height), (CloudSync.Online ? "● " : "○ ") + "Base de datos: " + CloudSync.Status, UiKit.Label);
            GUI.color = Color.white;
        }

        GUI.color = new Color(1f, 1f, 1f, 0.4f);
        GUI.Label(new Rect(8 * k, Screen.height - 24 * k, 400 * k, 22 * k), "versión " + BuildInfo.Stamp + " · " + BuildInfo.Patch, UiKit.Small);
        GUI.color = Color.white;

        // fundido de entrada
        fade = Mathf.Clamp01(1f - (Time.realtimeSinceStartup - t0) / 0.8f);
        if (fade > 0f)
        {
            GUI.color = new Color(0.1f, 0.05f, 0.18f, fade);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }
    }

    void NameScreen(float k, float cx)
    {
        Rect pr = new Rect(cx - 330 * k, 215 * k, 660 * k, 300 * k);
        UiKit.Panel(pr);
        GUI.Label(new Rect(pr.x, pr.y + 12 * k, pr.width, 44 * k), "¿CÓMO TE LLAMAS?", UiKit.Title);
        GUI.Label(new Rect(pr.x + 30 * k, pr.y + 58 * k, pr.width - 60 * k, 30 * k), "▲▼ o flechas para elegir letra · ◄ ► para cambiar de casilla · Enter para empezar", UiKit.Small);
        Event e = Event.current;
        if (e.type == EventType.KeyDown)
        {
            if (e.keyCode == KeyCode.LeftArrow) { nameCur = Mathf.Max(0, nameCur - 1); e.Use(); }
            else if (e.keyCode == KeyCode.RightArrow) { nameCur = Mathf.Min(PlayerName.Len - 1, nameCur + 1); e.Use(); }
            else if (e.keyCode == KeyCode.UpArrow) { Cycle(nameCur, 1); e.Use(); }
            else if (e.keyCode == KeyCode.DownArrow) { Cycle(nameCur, -1); e.Use(); }
            else if (e.keyCode == KeyCode.Backspace) { nameCh[nameCur] = ' '; nameCur = Mathf.Max(0, nameCur - 1); e.Use(); }
            else if (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) { StartGame(); e.Use(); return; }
            else if (e.keyCode == KeyCode.Escape) { Go(Page.Main); e.Use(); return; }
            else if (e.character != 0 && PlayerName.Chars.IndexOf(char.ToUpperInvariant(e.character)) >= 0)
            { nameCh[nameCur] = char.ToUpperInvariant(e.character); nameCur = Mathf.Min(PlayerName.Len - 1, nameCur + 1); e.Use(); }
        }
        float sw = 62 * k, sg = 12 * k, total = PlayerName.Len * sw + (PlayerName.Len - 1) * sg;
        float x0 = cx - total * 0.5f, y0 = pr.y + 100 * k;
        for (int i = 0; i < PlayerName.Len; i++)
        {
            float x = x0 + i * (sw + sg);
            if (UiKit.Button(new Rect(x, y0, sw, 34 * k), "▲")) { nameCur = i; Cycle(i, 1); }
            Rect slot = new Rect(x, y0 + 38 * k, sw, 62 * k);
            GUI.color = i == nameCur ? new Color(1f, 0.85f, 0.4f) : new Color(1f, 1f, 1f, 0.85f);
            GUI.DrawTexture(slot, Texture2D.whiteTexture);
            GUI.color = new Color(0.15f, 0.1f, 0.25f);
            GUI.Label(slot, nameCh[i] == ' ' ? "_" : "" + nameCh[i], UiKit.Title);
            if (GUI.Button(slot, "", GUIStyle.none)) nameCur = i;
            GUI.color = Color.white;
            if (UiKit.Button(new Rect(x, y0 + 104 * k, sw, 34 * k), "▼")) { nameCur = i; Cycle(i, -1); }
        }
        float bh = 54 * k, bw = bh * 640f / 140f;
        if (UiKit.Button(new Rect(cx - bw - 10 * k, pr.yMax + 14 * k, bw, bh), "ATRÁS")) Go(Page.Main);
        if (UiKit.Button(new Rect(cx + 10 * k, pr.yMax + 14 * k, bw, bh), "¡A JUGAR!")) StartGame();
    }
}
