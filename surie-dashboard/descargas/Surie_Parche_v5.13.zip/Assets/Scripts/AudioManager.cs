using UnityEngine;

/// <summary>Música alegre (menú, historieta, juego) y efectos de sonido. Clips en Resources/Audio.</summary>
public class AudioManager : MonoBehaviour
{
    static AudioManager inst;
    AudioSource music, sfx;
    string current = "";
    float duck = 1f, duckTarget = 1f;
    public static float MusicVol { get { return PlayerPrefs.GetFloat("surie_mus", 0.7f); } set { PlayerPrefs.SetFloat("surie_mus", value); } }
    public static float SfxVol { get { return PlayerPrefs.GetFloat("surie_sfx", 0.9f); } set { PlayerPrefs.SetFloat("surie_sfx", value); } }

    static AudioManager I
    {
        get
        {
            if (inst == null)
            {
                var go = new GameObject("AudioManager");
                DontDestroyOnLoad(go);
                inst = go.AddComponent<AudioManager>();
                inst.music = go.AddComponent<AudioSource>();
                inst.music.loop = true;
                inst.sfx = go.AddComponent<AudioSource>();
            }
            return inst;
        }
    }

    public static void PlayMusic(string clip)
    {
        var a = I;
        if (a.current == clip && a.music.isPlaying) return;
        a.current = clip;
        var c = Resources.Load<AudioClip>("Audio/" + clip);
        if (c == null) c = Resources.Load<AudioClip>("Audio/musica_juego");      // si falta la pista del nivel, usa la general
        if (c == null) return;
        a.music.clip = c;
        a.music.Play();
    }

    public static void StopMusic() { I.music.Stop(); I.current = ""; }

    /// <summary>Baja la música mientras está la pausa.</summary>
    public static void Duck(bool on) { I.duckTarget = on ? 0.3f : 1f; }

    public static void Sfx(string clip)
    {
        var c = Resources.Load<AudioClip>("Audio/sfx_" + clip);
        if (c != null) I.sfx.PlayOneShot(c, SfxVol);
    }

    /// <summary>Convierte un evento de métricas en su sonido.</summary>
    public static void ForEvent(string ev)
    {
        switch (ev)
        {
            case "jump": Sfx("salto"); break;
            case "dash": Sfx("dash"); break;
            case "fall": case "water": Sfx("caida"); break;
            case "stress": Sfx("estres"); break;
            case "letter": Sfx("letra"); break;
            case "croqueta": Sfx("croqueta"); break;
            case "bell": Sfx("cascabel"); break;
            case "checkpoint": Sfx("checkpoint"); break;
            case "win": Sfx("victoria"); break;
        }
    }

    void Update()
    {
        duck = Mathf.Lerp(duck, duckTarget, 1f - Mathf.Exp(-6f * Time.unscaledDeltaTime));
        if (music != null) music.volume = MusicVol * duck;
    }
}
