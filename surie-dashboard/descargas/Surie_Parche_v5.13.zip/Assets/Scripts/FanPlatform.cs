using UnityEngine;

/// <summary>Plataforma del ventilador: sube y baja (cada 2 turnos en cada dirección).</summary>
[RequireComponent(typeof(Rigidbody))]
public class FanPlatform : MovingBase
{
    public float lowY = 1.2f;
    public float highY = 1.73f;
    public Transform pole;       // poste telescópico: su punta sigue a la plataforma
    public float poleBottom;     // altura (m) donde se apoya el poste
    Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
    }

    void FixedUpdate()
    {
        float turn = GameManager.I != null ? GameManager.I.TurnSeconds : 1.5f;
        float phase = Mathf.PingPong(Time.fixedTime / (2f * turn), 1f);
        float y = Mathf.Lerp(lowY, highY, Mathf.SmoothStep(0f, 1f, phase));
        Vector3 np = new Vector3(rb.position.x, y, rb.position.z);
        Delta = np - rb.position;
        rb.MovePosition(np);
        if (pole != null)
        {
            float top = y - transform.localScale.y * 0.5f;
            float hgt = Mathf.Max(0.05f, top - poleBottom);
            Vector3 ps = pole.localScale; ps.y = hgt; pole.localScale = ps;
            Vector3 pp = pole.position; pp.y = poleBottom + hgt * 0.5f; pole.position = pp;
        }
    }
}
