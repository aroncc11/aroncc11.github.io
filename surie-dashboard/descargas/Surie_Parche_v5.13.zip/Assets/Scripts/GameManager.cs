using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Reglas del juego: estrés (5 casillas), letras S-U-R-I-E, cascabel, TV, meta y marcador en pantalla.</summary>
public class GameManager : MonoBehaviour
{
    public static GameManager I;

    public const int MaxStress = 5;
    public const int MaxEnergy = 3;
    public const int MaxLives = 3;
    public int lives = MaxLives;
    public bool lost;
    float winAt = -1f;
    Texture2D endLose, endWin;
    [Tooltip("Segundos que tarda en recargarse 1 punto de energía por sí sola")]
    public float energyRegenSeconds = 6f;
    public float energy = MaxEnergy;
    float noEnergyMsgAt;
    [Tooltip("Duración de un 'turno' en segundos. La TV cambia cada 3 turnos y el ventilador cada 2.")]
    public float TurnSeconds = 1.5f;

    public int stress;
    public bool[] letters = new bool[5];
    public bool hasBell;
    public bool won;
    // ---------- ayudas de diseño v2 (tutorial y avisos)
    [Tooltip("0 = sala (nivel 1). 1..5 = niveles generados. Lo pone el constructor de niveles.")]
    public int levelIndex;
    public string levelTitle = "";
    float playTime;
    [HideInInspector] public float chaseDanger;       // 0..1: qué tan cerca está el perseguidor
    public int enemiesDefeated;
    bool everJumped, everDashed, hintJumpLogged, hintDashLogged;
    public void EnemyDefeated(string kind)
    {
        enemiesDefeated++;
        energy = Mathf.Min(MaxEnergy, energy + 0.5f);
        Say("¡Enemigo derrotado! +½ energía", 1.3f);
        AudioManager.Sfx("dash");
    }
    public void NoteJump() { everJumped = true; }

    // ---------- nivel bonus "La alacena de croquetas"
    public string sceneStamp = "";
    public Vector3 bonusStart;
    public float bonusCamMin, bonusCamMax;
    public const float BonusSeconds = 75f;
    public bool inBonus, bonusDone, bonusRunning;
    public float bonusTime;
    public int bonusScore, bonusCroq;
    string bonusSummary = "";
    bool altEnding;
    Texture2D endWinAlt;
    public static bool Sello { get { return PlayerPrefs.GetInt("surie_sello", 0) == 1; } }
    public Vector3 respawnPoint;
    public Vector3 startPoint;
    public PlayerController2D player;
    public string menuScene = "Menu_Surie";
    public bool paused;
    public float[] sectionStartsCm;

    string msg = "";
    float msgUntil;
    bool losing;
    GUIStyle big, small, center, hudL;

    public bool TvOn { get { return ((int)(Time.time / (TurnSeconds * 3f))) % 2 == 1; } }

    void Awake()
    {
        I = this;
        Physics.gravity = new Vector3(0f, -30f, 0f);
        Time.timeScale = 1f;
        Inp.Locked = false;
    }

    void Start()
    {
        if (PlayerPrefs.GetInt("surie_vida_extra", 0) == 1)
        {
            lives = MaxLives + 1;                      // premio del bonus anterior
            PlayerPrefs.SetInt("surie_vida_extra", 0);
        }
        if (player != null && startPoint == Vector3.zero) startPoint = player.transform.position;
        if (respawnPoint == Vector3.zero) respawnPoint = startPoint;
        if (sectionStartsCm != null && sectionStartsCm.Length > 0) Analytics.SectionStartsCm = sectionStartsCm;
        endLose = Resources.Load<Texture2D>("UI/gameover");
        endWin = Resources.Load<Texture2D>("UI/victoria");
        endWinAlt = Resources.Load<Texture2D>("UI/victoria_secreta");
        Analytics.Level = levelIndex;
        Progress.Current = levelIndex;
        Analytics.Ensure();
        AudioManager.PlayMusic(levelIndex == 0 ? "musica_juego" : "musica_nivel" + (levelIndex + 1));   // una pista por nivel
        AudioManager.Duck(false);
        if (levelIndex == 4 && Object.FindObjectsByType<LightsOut>(FindObjectsSortMode.None).Length == 0) gameObject.AddComponent<LightsOut>();   // sótano: los apagones van siempre, aunque la escena no los traiga
        Analytics.Event("level_start", "nivel=" + (levelIndex + 1));
        Analytics.Event("version", BuildInfo.Version);
        if (levelIndex > 0)
            Say(levelIndex == Progress.Levels.Length - 1 ? levelTitle + ": llega hasta Benito y recupera tu juguete (¡hay jefe final!)" : levelTitle + ": llega hasta el juguete. Reúne S-U-R-I-E para ganar el minijuego", 5f);
        else
        Say("Llega hasta tu juguete. A/D = mover · Espacio = saltar · W = trepar · Shift = dash (gasta energía)"
#if UNITY_EDITOR
            + "  ·  [F9 = probar el nivel bonus]"
#endif
            , 6f);
    }

    void Update()
    {
        if (Progress.DirectMini && levelIndex == 0 && !inBonus && !bonusDone && playTime > 0.6f)
        {
            Progress.DirectMini = false;          // repetir la alacena desde el mapa
            DebugGoBonus();
        }
        if (!paused && !won && !lost) playTime += Time.deltaTime;
        if (energy < MaxEnergy) energy = Mathf.Min(MaxEnergy, energy + Time.deltaTime / energyRegenSeconds);
        if (inBonus && bonusRunning && !won && !paused)
        {
            bonusTime -= Time.deltaTime;
            if (bonusTime <= 0f) { bonusTime = 0f; EndBonus(false); }
        }
        if (Inp.PauseDown()) SetPause(!paused);
        if (Inp.BonusCheatDown() && !inBonus && !bonusDone && !won)
        {
            DebugGoBonus();                                              // atajo de prueba (solo editor)
        }
        if (Inp.RestartDown() && !paused) Restart();
    }

    public void SetPause(bool p)
    {
        if (lost) return;
        paused = p;
        Time.timeScale = p ? 0f : 1f;
        AudioManager.Duck(p);
        Analytics.Event(p ? "pause" : "resume");
    }

    public void Restart()
    {
        Analytics.Event("restart");
        Analytics.EndAndReset();
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void ToMenu()
    {
        Analytics.Event("to_menu");
        AudioManager.Duck(false);
        Analytics.EndAndReset();
        Time.timeScale = 1f;
        SceneManager.LoadScene(menuScene);
    }

    public void Say(string s, float t = 2.2f)
    {
        msg = s;
        msgUntil = Time.time + t;
    }

    public void AddStress(int n, string why)
    {
        if (won || losing || lost) return;
        if (inBonus)
        {
            // en la alacena no hay estrés: un golpe o una caída cuestan puntos
            bonusScore = Mathf.Max(0, bonusScore - 50);
            Analytics.Event("bonus_golpe", why);
            if (player != null) player.Flash(1.1f);
            Say("¡Ay! -50 puntos", 1.2f);
            return;
        }
        stress = Mathf.Min(MaxStress, stress + n);
        Analytics.Event("stress", why);
        if (player != null) player.Flash(1.1f);
        Say(why);
        if (stress >= MaxStress) StartCoroutine(Lose());
    }

    public void Relax()
    {
        if (won) return;
        energy = Mathf.Min(MaxEnergy, energy + 1f);
        Analytics.Event("rest");
        if (stress <= 0) { Say("Descansas un momento: +1 energía"); return; }
        stress--;
        Say("Descansas un momento: -1 estrés, +1 energía");
    }

    /// <summary>El dash cuesta 1 punto de energía.</summary>
    public bool TryUseEnergy()
    {
        if (energy >= 1f) { energy -= 1f; everDashed = true; Analytics.Event("dash"); return true; }
        if (Time.time > noEnergyMsgAt) { Analytics.Event("dash_sin_energia"); Say("Sin energía: descansa o come croquetas", 1.5f); noEnergyMsgAt = Time.time + 1.5f; }
        return false;
    }

    public void AddEnergy(float n)
    {
        energy = Mathf.Min(MaxEnergy, energy + n);
        if (inBonus) { bonusCroq++; bonusScore += 100; Say("¡Croqueta! +100 puntos", 1.0f); return; }
        Say("¡Croqueta! +1 energía", 1.2f);
    }

    IEnumerator Lose()
    {
        losing = true;
        lives--;
        Analytics.Event("lose_estres", "vidas=" + lives);
        if (lives <= 0)
        {
            Say("¡Sin vidas!", 1.5f);
            yield return new WaitForSeconds(0.8f);
            lost = true;
            Analytics.Event("game_over");
            if (Analytics.I != null) Analytics.I.SetResult("derrota");
            AudioManager.Sfx("derrota");
            Time.timeScale = 0f;
            losing = false;
            yield break;
        }
        Say("¡Demasiado estrés! Pierdes una vida (te quedan " + lives + ")", 3f);
        yield return new WaitForSeconds(1.0f);
        stress = 0;
        energy = MaxEnergy;
        respawnPoint = startPoint;
        RespawnPlayer();
        losing = false;
    }

    public void RespawnPlayer()
    {
        if (player != null) player.TeleportTo(respawnPoint);
    }

    public void CollectLetter(int i)
    {
        if (i < 0 || i >= letters.Length) return;
        letters[i] = true;
        Analytics.Event("letter", "SURIE"[i].ToString());
        int c = 0;
        foreach (bool b in letters) if (b) c++;
        if (c == 5) Say("¡S-U-R-I-E COMPLETO! Toma el juguete para abrir la ALACENA SECRETA", 5f);
        else Say("Letra \"" + "SURIE"[i] + "\" encontrada (" + c + "/5)");
    }

    public void CollectBell()
    {
        hasBell = true;
        Analytics.Event("bell");
        Say("¡Cascabel! Ahora puedes abrir la puerta de gato", 3f);
    }

    public void Win()
    {
        if (won || inBonus) return;
        int nl = 0;
        foreach (bool b in letters) if (b) nl++;
        if (levelIndex > 0)
        {
            if (nl == 5 && !won && Progress.HasMini(levelIndex)) { won = true; StartCoroutine(GoMiniGame(nl)); return; }
            FinishWin();
            return;
        }
        if (nl == 5 && !bonusDone) { StartCoroutine(StartBonus()); return; }
        FinishWin();
    }

    /// <summary>Prueba: junta las 5 letras y entra al bonus (menú Surie ▸ Probar nivel bonus, o F9).</summary>
    public void DebugGoBonus()
    {
        if (inBonus || bonusDone || won) { Say("El bonus ya se usó en esta partida. Pulsa R para reiniciar.", 3f); return; }
        for (int i = 0; i < letters.Length; i++) letters[i] = true;
        Win();
    }

    /// <summary>Niveles 2+: con las 5 letras y el juguete, se entra al minijuego del nivel.</summary>
    IEnumerator GoMiniGame(int nl)
    {
        Analytics.Event("win", "nivel=" + (levelIndex + 1));
        if (Analytics.I != null) Analytics.I.SetResult("victoria");
        Progress.Complete(levelIndex, nl, playTime);
        Say("¡S-U-R-I-E completo y juguete recuperado! Entras al minijuego: " + Progress.Levels[levelIndex].miniName, 3f);
        AudioManager.Sfx("victoria");
        yield return new WaitForSeconds(2.2f);
        Progress.GoMini(levelIndex);
    }

    IEnumerator StartBonus()
    {
        if (bonusStart == Vector3.zero || GameObject.Find("Bonus_Alacena") == null)
        {
            Say("El nivel bonus no está en esta escena: ejecuta Surie ▸ Construir nivel completo y vuelve a jugar", 6f);
            Debug.LogWarning("[Surie] Falta el nivel bonus: reconstruye con Surie > Construir nivel completo.");
            yield break;
        }
        inBonus = true;
        bonusRunning = false;
        bonusTime = BonusSeconds; bonusScore = 0; bonusCroq = 0;
        Analytics.Event("bonus_start");
        Debug.Log("[Surie] Nivel bonus: teleport a " + bonusStart);
        Say("¡S-U-R-I-E completo! Se abre la ALACENA SECRETA...", 3f);
        yield return new WaitForSeconds(1.2f);
        stress = 0; energy = MaxEnergy;
        respawnPoint = bonusStart;
        var cf = Camera.main != null ? Camera.main.GetComponent<CameraFollow>() : null;
        if (cf != null) { cf.minX = bonusCamMin; cf.maxX = bonusCamMax; }
        if (player != null) player.TeleportTo(bonusStart);
        if (Camera.main != null) Camera.main.transform.position = new Vector3(bonusStart.x, 2f, -10f);
        bonusRunning = true;
        Say("BONUS: junta croquetas (+100) y llega al frasco antes de que se acabe el tiempo. Los golpes y caídas restan 50", 6f);
    }

    public void EndBonus(bool reached)
    {
        if (!inBonus) return;
        inBonus = false; bonusRunning = false; bonusDone = true;
        int timeBonus = reached ? Mathf.CeilToInt(bonusTime) * 10 : 0;
        bonusScore += timeBonus;
        Analytics.Event("bonus_fin", (reached ? "frasco" : "tiempo") + " puntos=" + bonusScore + " croquetas=" + bonusCroq);
        altEnding = reached;     // final alterno: solo si llegas al frasco
        if (reached)
        {
            PlayerPrefs.SetInt("surie_sello", 1);
            PlayerPrefs.SetInt("surie_vida_extra", 1);
            PlayerPrefs.Save();
            bonusSummary = "\nBONUS: " + bonusScore + " pts · sello SURIE ★ · +1 vida para tu próxima partida";
        }
        else bonusSummary = "\nBONUS: se acabó el tiempo · " + bonusScore + " pts";
        FinishWin();
    }

    void FinishWin()
    {
        won = true;
        winAt = Time.time;
        Analytics.Event("win", "nivel=" + (levelIndex + 1));
        int c = 0;
        foreach (bool b in letters) if (b) c++;
        Progress.Complete(levelIndex, c, playTime);
        if (levelIndex == 0 && bonusDone) PlayerPrefs.SetInt("surie_mini0", 1);
        Say((c == 5 ? "¡JUGUETE RECUPERADO y nombre completo S-U-R-I-E!" : "¡JUGUETE RECUPERADO! (" + c + "/5 letras)") + bonusSummary + "\nPulsa R para reiniciar", 999f);
    }

    Texture2D vig;
    void MakeVignette()
    {
        int n = 64; vig = new Texture2D(n, n, TextureFormat.RGBA32, false);
        vig.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float dx = (x / (n - 1f) - 0.5f) * 2f, dy = (y / (n - 1f) - 0.5f) * 2f;
                float d = Mathf.Sqrt(dx * dx + dy * dy);
                float a = Mathf.Clamp01((d - 0.55f) / 0.8f); a = a * a;
                vig.SetPixel(x, y, new Color(1f, 1f, 1f, a));
            }
        vig.Apply();
    }

    void OnGUI()
    {
        if (big == null)
        {
            big = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold };
            small = new GUIStyle(GUI.skin.label);
            center = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold, wordWrap = true };
        }
        float k = Screen.height / 720f;
        big.fontSize = Mathf.RoundToInt(20 * k);
        small.fontSize = Mathf.RoundToInt(16 * k);
        center.fontSize = Mathf.RoundToInt(22 * k);

        // ---------- el estrés se ve: viñeta roja pulsante en los bordes
        if (stress > 0)
        {
            if (vig == null) MakeVignette();
            float sN = stress / (float)MaxStress;
            float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * (2.5f + stress * 1.6f));
            GUI.color = new Color(1f, 0.1f, 0.1f, Mathf.Clamp01(sN * (0.35f + 0.45f * pulse)));
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), vig);
            GUI.color = Color.white;
        }

        // ---------- persecución: viñeta roja y aviso
        if (chaseDanger > 0.02f && !won && !lost)
        {
            if (vig == null) MakeVignette();
            float pu = 0.6f + 0.4f * Mathf.Sin(Time.time * 12f);
            GUI.color = new Color(1f, 0.05f, 0.05f, Mathf.Clamp01(chaseDanger * 0.8f * pu));
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), vig);
            if (chaseDanger > 0.35f)
            {
                var cs = new GUIStyle(center); cs.fontSize = Mathf.RoundToInt((30 + 14 * chaseDanger) * k);
                GUI.color = new Color(1f, 0.85f, 0.3f, pu);
                GUI.Label(new Rect(0, Screen.height * 0.18f, Screen.width, 60 * k), "¡CORRE!", cs);
            }
            GUI.color = Color.white;
        }

        // ---------- HUD horizontal (barra superior)
        if (UiKit.iconStress == null) UiKit.Load();
        float hk = Mathf.Min(k, Screen.width / 1280f);
        if (hudL == null)
        {
            hudL = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, wordWrap = false, clipping = TextClipping.Overflow };
            hudL.normal.textColor = Color.white;
        }
        hudL.fontSize = Mathf.Max(8, Mathf.RoundToInt(15 * hk));
        float barH = 40 * hk;
        Color c0 = GUI.color;
        GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.78f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, barH), Texture2D.whiteTexture);
        GUI.color = new Color(1f, 0.8f, 0.5f, 0.9f);
        GUI.DrawTexture(new Rect(0, barH - 2 * hk, Screen.width, 2 * hk), Texture2D.whiteTexture);
        GUI.color = c0;
        float hx = 12 * hk, hy = 8 * hk, hh = 22 * hk;

        // estrés
        if (UiKit.iconStress != null) GUI.DrawTexture(new Rect(hx, hy - 1 * hk, 24 * hk, 24 * hk), UiKit.iconStress);
        GUI.Label(new Rect(hx + 28 * hk, 0, 64 * hk, barH), "ESTRÉS", hudL);
        for (int i = 0; i < MaxStress; i++)
        {
            Rect r = new Rect(hx + 92 * hk + i * 21 * hk, hy, 17 * hk, hh);
            GUI.color = new Color(0f, 0f, 0f, 0.7f);
            GUI.DrawTexture(new Rect(r.x - 1.5f, r.y - 1.5f, r.width + 3, r.height + 3), Texture2D.whiteTexture);
            GUI.color = i < stress ? new Color(0.9f, 0.25f, 0.25f) : new Color(1f, 1f, 1f, 0.9f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = c0;
        }
        hx += 92 * hk + 5 * 21 * hk + 30 * hk;

        // energía (dash)
        if (UiKit.iconEnergy != null) GUI.DrawTexture(new Rect(hx, hy - 1 * hk, 24 * hk, 24 * hk), UiKit.iconEnergy);
        GUI.Label(new Rect(hx + 28 * hk, 0, 70 * hk, barH), "ENERGÍA", hudL);
        for (int i = 0; i < MaxEnergy; i++)
        {
            Rect r = new Rect(hx + 100 * hk + i * 30 * hk, hy + 2 * hk, 26 * hk, hh - 4 * hk);
            GUI.color = new Color(0f, 0f, 0f, 0.7f);
            GUI.DrawTexture(new Rect(r.x - 1.5f, r.y - 1.5f, r.width + 3, r.height + 3), Texture2D.whiteTexture);
            GUI.color = new Color(1f, 1f, 1f, 0.25f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = new Color(0.2f, 0.75f, 0.95f);
            GUI.DrawTexture(new Rect(r.x, r.y, r.width * Mathf.Clamp01(energy - i), r.height), Texture2D.whiteTexture);
            GUI.color = c0;
        }
        hx += 100 * hk + 3 * 30 * hk + 30 * hk;

        // vidas: cara de Surie  x N (como en Crash)
        {
            float fs = 32 * hk;
            float sh = stress >= 3 ? Mathf.Sin(Time.time * 45f) * (stress - 2) * 0.8f * hk : 0f;
            Color fc = GUI.color;
            GUI.color = Color.Lerp(Color.white, new Color(1f, 0.45f, 0.4f), stress / (float)MaxStress);
            if (UiKit.iconFace != null) GUI.DrawTexture(new Rect(hx + sh, (barH - fs) * 0.5f, fs, fs), UiKit.iconFace, ScaleMode.ScaleToFit, true);
            GUI.color = fc;
            Color pc = GUI.color;
            GUI.color = lives <= 1 ? new Color(1f, 0.45f, 0.4f) : Color.white;
            var lv = new GUIStyle(hudL); lv.fontSize = Mathf.Max(12, Mathf.RoundToInt(22 * hk));
            GUI.Label(new Rect(hx + fs + 4 * hk, 0, 56 * hk, barH), "× " + lives, lv);
            GUI.color = pc;
        }
        hx += 32 * hk + 64 * hk + 30 * hk;

        // letras S U R I E
        for (int i = 0; i < 5; i++)
        {
            Rect r = new Rect(hx + i * 25 * hk, hy, 22 * hk, hh);
            GUI.color = letters[i] ? new Color(0.96f, 0.77f, 0.19f) : new Color(1f, 1f, 1f, 0.22f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = letters[i] ? new Color(0.15f, 0.1f, 0.2f) : new Color(1f, 1f, 1f, 0.6f);
            GUI.Label(new Rect(r.x + 5 * hk, 0, 20 * hk, barH), "" + "SURIE"[i], hudL);
            GUI.color = c0;
        }
        hx += 5 * 25 * hk + 30 * hk;

        // cascabel y TV (o marcador del bonus)
        if (inBonus)
        {
            GUI.color = bonusTime < 15f ? new Color(1f, 0.45f, 0.4f) : new Color(1f, 0.9f, 0.4f);
            GUI.Label(new Rect(hx, 0, 260 * hk, barH), "BONUS  " + Mathf.CeilToInt(bonusTime) + " s   ★ " + bonusScore + " pts", hudL);
        }
        else {
        GUI.color = hasBell ? new Color(1f, 0.85f, 0.3f) : new Color(1f, 1f, 1f, 0.55f);
        GUI.Label(new Rect(hx, 0, 110 * hk, barH), "Cascabel " + (hasBell ? "✓" : "–"), hudL);
        GUI.color = TvOn ? new Color(1f, 0.45f, 0.45f) : new Color(1f, 1f, 1f, 0.7f);
        GUI.Label(new Rect(hx + 112 * hk, 0, 140 * hk, barH), "TV " + (TvOn ? "ENCENDIDA" : "apagada"), hudL);
        }
        GUI.color = c0;

        // jugador y base de datos (derecha)
        GUI.color = CloudSync.Online ? new Color(0.5f, 1f, 0.7f) : new Color(1f, 0.8f, 0.5f);
        GUI.Label(new Rect(Screen.width - 128 * hk, 0, 124 * hk, barH), (CloudSync.Online ? "● " : "○ ") + "BD " + (CloudSync.Online ? "en línea" : "sin red"), hudL);
        GUI.color = new Color(1f, 0.93f, 0.75f);
        GUI.Label(new Rect(Screen.width - 128 * hk - 150 * hk, 0, 146 * hk, barH), PlayerName.Current + (Sello ? " ★" : ""), hudL);
        GUI.color = c0;

        {
            bool stale = sceneStamp != BuildInfo.Stamp;
            var vs = new GUIStyle(small); vs.fontSize = Mathf.Max(9, Mathf.RoundToInt(12 * k)); vs.wordWrap = false;
            GUI.color = stale ? new Color(1f, 0.35f, 0.3f) : new Color(1f, 1f, 1f, 0.35f);
            GUI.Label(new Rect(8 * k, Screen.height - 24 * k, Screen.width, 22 * k),
                stale ? "ESCENA DESACTUALIZADA (nivel: " + (sceneStamp == "" ? "viejo" : sceneStamp) + " / scripts: " + BuildInfo.Stamp + ") → ejecuta Surie > Construir nivel completo"
                      : "versión " + BuildInfo.Stamp, vs);
            GUI.color = Color.white;
        }

        if (Time.time < msgUntil)
        {
            Color old = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, 0.55f);
            GUI.DrawTexture(new Rect(Screen.width * 0.1f, Screen.height - 120 * k, Screen.width * 0.8f, 80 * k), Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUI.Label(new Rect(Screen.width * 0.1f, Screen.height - 120 * k, Screen.width * 0.8f, 80 * k), msg, center);
            GUI.color = old;
        }

        DrawGuide(k);

        bool showWin = won && winAt > 0f && Time.time > winAt + 1.2f;
        if (lost || showWin)
        {
            var img = lost ? endLose : (altEnding && endWinAlt != null ? endWinAlt : endWin);
            if (img != null) GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), img, ScaleMode.ScaleAndCrop);
            if (!lost && altEnding)
            {
                var sc = new GUIStyle(center); sc.fontSize = Mathf.RoundToInt(26 * k);
                GUI.color = new Color(1f, 0.95f, 0.6f);
                GUI.Label(new Rect(0, Screen.height * 0.70f, Screen.width, 40 * k), "BONUS: " + bonusScore + " pts   ·   croquetas: " + bonusCroq + "   ·   sello ★ + vida extra guardados", sc);
                GUI.color = Color.white;
            }
            bool fin = !lost && levelIndex == Progress.Levels.Length - 1;
            if (fin)
            {
                var fs = new GUIStyle(center); fs.fontSize = Mathf.RoundToInt(34 * k);
                GUI.color = new Color(1f, 0.95f, 0.6f);
                GUI.Label(new Rect(0, Screen.height * 0.08f, Screen.width, 60 * k), "¡FIN! Surie recuperó su juguete", fs);
                GUI.color = Color.white;
            }
            bool world = Progress.SceneExists(Progress.WorldScene);
            int nb = world ? 3 : 2;
            float ebw = 400 * k, ebh = (nb == 3 ? 64 : 88) * k, ebx = Screen.width * 0.5f - ebw * 0.5f, eby = Screen.height - (nb * (ebh + 6 * k)) - 36 * k;
            int bi = 0;
            if (world)
            {
                if (UiKit.Button(new Rect(ebx, eby, ebw, ebh), lost ? "VOLVER AL MAPA" : (fin ? "VER EL MAPA" : "SEGUIR AL MAPA"))) Progress.GoWorld();
                bi++;
            }
            if (UiKit.Button(new Rect(ebx, eby + bi * (ebh + 6 * k), ebw, ebh), lost ? "REINTENTAR" : "JUGAR OTRA VEZ")) Restart();
            bi++;
            if (UiKit.Button(new Rect(ebx, eby + bi * (ebh + 6 * k), ebw, ebh), "MENÚ PRINCIPAL")) ToMenu();
        }
        if (paused)
        {
            UiKit.PauseBackground();
            Rect pr = new Rect(Screen.width * 0.5f - 230 * k, Screen.height * 0.5f - 235 * k, 460 * k, 470 * k);
            UiKit.Panel(pr);
            GUI.Label(new Rect(pr.x, pr.y + 16 * k, pr.width, 44 * k), "PAUSA", UiKit.Title);
            bool wd = Progress.SceneExists(Progress.WorldScene);
            float bw = 400 * k, bh = (wd ? 66 : 88) * k, bx = pr.x + (pr.width - bw) * 0.5f, by = pr.y + (wd ? 66 : 72) * k;
            if (UiKit.Button(new Rect(bx, by, bw, bh), "REANUDAR")) SetPause(false);
            if (UiKit.Button(new Rect(bx, by + (bh + 6 * k), bw, bh), "REINICIAR")) Restart();
            int pi = 2;
            if (wd) { if (UiKit.Button(new Rect(bx, by + pi * (bh + 6 * k), bw, bh), "VOLVER AL MAPA")) Progress.GoWorld(); pi++; }
            if (UiKit.Button(new Rect(bx, by + pi * (bh + 6 * k), bw, bh), "MENÚ PRINCIPAL")) ToMenu();
        }
    }

    // ---------- v2: tutorial en pantalla y avisos de ayuda (hallazgos: 22 % sin acción, dash descubierto tarde)
    void DrawGuide(float k)
    {
        if (won || lost || paused || inBonus) return;
        float pulse = 0.65f + 0.35f * Mathf.Sin(Time.unscaledTime * 5f);
        var st = new GUIStyle(center); st.fontSize = Mathf.RoundToInt(24 * k);
        Color c0 = GUI.color;
        // 1) tarjeta de controles durante los primeros 15 s
        if (playTime < 15f)
        {
            float a = Mathf.Clamp01((15f - playTime) / 2f);
            Rect r = new Rect(Screen.width * 0.5f - 300 * k, 62 * k, 600 * k, 74 * k);
            GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.82f * a);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = new Color(1f, 0.93f, 0.75f, a);
            GUI.Label(r, "A / D mover   ·   ESPACIO saltar   ·   SHIFT dash", st);
        }
        // 2) si no ha saltado, aviso grande y pulsante
        if (playTime > 5f && !everJumped)
        {
            if (!hintJumpLogged) { hintJumpLogged = true; Analytics.Event("hint_salto"); }
            Rect r = new Rect(Screen.width * 0.5f - 280 * k, Screen.height * 0.30f, 560 * k, 80 * k);
            GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.85f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = new Color(1f, 0.85f, 0.3f, pulse);
            GUI.Label(r, "Pulsa ESPACIO para saltar", st);
        }
        // 3) si tras 20 s no ha usado el dash, lo enseña (solo en el nivel 1)
        else if (playTime > 20f && !everDashed && levelIndex == 0)
        {
            if (!hintDashLogged) { hintDashLogged = true; Analytics.Event("hint_dash"); }
            Rect r = new Rect(Screen.width * 0.5f - 330 * k, Screen.height * 0.30f, 660 * k, 100 * k);
            GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.85f);
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = new Color(0.4f, 0.85f, 1f, pulse);
            GUI.Label(r, "Prueba SHIFT: el dash te lanza hacia adelante\ny atraviesa a la Roomba (gasta 1 energía)", st);
        }
        GUI.color = c0;
    }
}
