using UnityEngine;

/// <summary>Benito roba el juguete: cuando Surie empieza a moverse, huye por la sala hasta el mueble de la TV.</summary>
public class BenitoRun : MonoBehaviour
{
    public Transform player;
    public Vector3[] waypoints;
    public float speed = 6f;
    public float triggerX = 1.2f;
    int idx;
    bool running;
    bool arrived;
    float yaw = 90f;
    Vector3 home;

    void Start() { home = transform.position; }

    void Update()
    {
        if (!running && !arrived && player != null && player.position.x > triggerX)
        {
            running = true;
            GameManager.I.Say("¡Benito se llevó tu juguete! Síguelo hasta la derecha", 4f);
        }
        if (running)
        {
            if (waypoints == null || idx >= waypoints.Length) { running = false; arrived = true; return; }
            Vector3 target = waypoints[idx];
            Vector3 d = target - transform.position;
            if (d.magnitude < 0.1f) { idx++; return; }
            transform.position += d.normalized * speed * Time.deltaTime;
            if (Mathf.Abs(d.x) > 0.05f) yaw = d.x > 0f ? 90f : -90f;
        }
        else if (arrived)
        {
            yaw = -90f;   // mira hacia Surie
        }
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0f, yaw, 0f), 1f - Mathf.Exp(-12f * Time.deltaTime));
    }
}
