using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

/// <summary>Envía las métricas a la base de datos (Supabase REST) por lotes. Si no hay internet, reintenta y los CSV locales quedan de respaldo.</summary>
public class CloudSync : MonoBehaviour
{
    static CloudSync inst;
    readonly List<string> events = new List<string>(), positions = new List<string>(), sessions = new List<string>();
    bool busy;
    float nextTry;
    public static bool Online;
    public static string Status = "sin comprobar";

    static CloudSync I
    {
        get
        {
            if (inst == null)
            {
                var go = new GameObject("CloudSync");
                DontDestroyOnLoad(go);
                inst = go.AddComponent<CloudSync>();
            }
            return inst;
        }
    }

    public static string Esc(string s)
    {
        if (s == null) return "";
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", " ").Replace("\r", " ");
    }

    static string N(float v) { return v.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture); }

    public static void AddEvent(string session, float t, string ev, float x, float y, int sec, string extra)
    {
        if (!CloudConfig.Enabled) return;
        I.events.Add("{\"session\":\"" + session + "\",\"t\":" + N(t) + ",\"event\":\"" + Esc(ev) + "\",\"x_cm\":" + N(x) + ",\"y_cm\":" + N(y) + ",\"section\":" + sec + ",\"extra\":\"" + Esc(extra) + "\"}");
    }

    public static void AddPosition(string session, float t, float x, float y, int sec, string state)
    {
        if (!CloudConfig.Enabled) return;
        I.positions.Add("{\"session\":\"" + session + "\",\"t\":" + N(t) + ",\"x_cm\":" + N(x) + ",\"y_cm\":" + N(y) + ",\"section\":" + sec + ",\"state\":\"" + state + "\"}");
    }

    public static void AddSession(string session, float dur, string result, int maxSec, int jumps, int dashes, int falls, int stress, int letters, int croq, int rests, float lastX, string player)
    {
        if (!CloudConfig.Enabled) return;
        I.sessions.Add("{\"session\":\"" + session + "\",\"duration_s\":" + N(dur) + ",\"result\":\"" + Esc(result) + "\",\"max_section\":" + maxSec + ",\"jumps\":" + jumps + ",\"dashes\":" + dashes + ",\"falls\":" + falls + ",\"stress_hits\":" + stress + ",\"letters\":" + letters + ",\"croquetas\":" + croq + ",\"rests\":" + rests + ",\"last_x_cm\":" + N(lastX) + ",\"player_name\":\"" + Esc(player) + "\"}");
        Flush();
    }

    /// <summary>Envía lo pendiente (máx. 400 filas por tabla y por vez).</summary>
    public static void Flush() { I.nextTry = 0f; }

    void Update()
    {
        if (!CloudConfig.Enabled || busy) return;
        int pending = events.Count + positions.Count + sessions.Count;
        if (pending == 0) return;
        if (Time.realtimeSinceStartup < nextTry) return;
        StartCoroutine(Send());
    }

    IEnumerator Send()
    {
        busy = true;
        yield return Post("sessions", sessions);
        yield return Post("events", events);
        yield return Post("positions", positions);
        nextTry = Time.realtimeSinceStartup + (Online ? 10f : 30f);
        busy = false;
    }

    IEnumerator Post(string table, List<string> rows)
    {
        while (rows.Count > 0)
        {
            int n = Math.Min(400, rows.Count);
            var sb = new StringBuilder("[");
            for (int i = 0; i < n; i++) { if (i > 0) sb.Append(','); sb.Append(rows[i]); }
            sb.Append(']');
            var req = new UnityWebRequest(CloudConfig.Url + "/rest/v1/" + table, "POST");
            req.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(sb.ToString()));
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("apikey", CloudConfig.Key);
            req.SetRequestHeader("Authorization", "Bearer " + CloudConfig.Key);
            req.SetRequestHeader("Content-Type", "application/json");
            req.SetRequestHeader("Prefer", "return=minimal");
            req.timeout = 15;
            yield return req.SendWebRequest();
            bool ok = req.result == UnityWebRequest.Result.Success;
            if (ok) { rows.RemoveRange(0, n); Online = true; Status = "en línea"; }
            else
            {
                Online = false; Status = "sin conexión (se reintenta)";
                if (rows.Count > 20000) rows.RemoveRange(0, rows.Count - 20000);
                req.Dispose();
                yield break;
            }
            req.Dispose();
        }
    }

    /// <summary>Lee estadísticas globales (todas las partidas de todos los jugadores) para el menú.</summary>
    public static void FetchGlobal(Action<string> done) { I.StartCoroutine(I.Fetch(done)); }

    IEnumerator Fetch(Action<string> done)
    {
        var req = UnityWebRequest.Get(CloudConfig.Url + "/rest/v1/sessions?select=result,duration_s,max_section&limit=5000");
        req.SetRequestHeader("apikey", CloudConfig.Key);
        req.SetRequestHeader("Authorization", "Bearer " + CloudConfig.Key);
        req.timeout = 10;
        yield return req.SendWebRequest();
        if (req.result != UnityWebRequest.Result.Success) { Online = false; Status = "sin conexión"; done("Sin conexión a la base de datos en línea."); req.Dispose(); yield break; }
        Online = true; Status = "en línea";
        string t = req.downloadHandler.text;
        req.Dispose();
        int n = 0, wins = 0; float dur = 0;
        int i = 0;
        while ((i = t.IndexOf("\"result\":\"", i, StringComparison.Ordinal)) >= 0)
        {
            n++;
            if (t.Substring(i + 10, 8) == "victoria") wins++;
            int d = t.IndexOf("\"duration_s\":", i, StringComparison.Ordinal);
            if (d >= 0)
            {
                int e = t.IndexOfAny(new[] { ',', '}' }, d + 13);
                float v; float.TryParse(t.Substring(d + 13, e - d - 13), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v);
                dur += v;
            }
            i += 10;
        }
        done(n == 0 ? "Aún no hay partidas en la base de datos en línea." :
            "Partidas de todos los jugadores: <b>" + n + "</b>\nVictorias: <b>" + wins + "</b> (" + Mathf.RoundToInt(100f * wins / n) + " %)\nDuración media: <b>" + Mathf.RoundToInt(dur / n / 60f * 10f) / 10f + " min</b>");
    }

    /// <summary>Comprueba la conexión (para el indicador del menú).</summary>
    public static void Ping() { I.StartCoroutine(I.PingRoutine()); }
    IEnumerator PingRoutine()
    {
        var req = UnityWebRequest.Get(CloudConfig.Url + "/rest/v1/sessions?select=session&limit=1");
        req.SetRequestHeader("apikey", CloudConfig.Key);
        req.SetRequestHeader("Authorization", "Bearer " + CloudConfig.Key);
        req.timeout = 8;
        yield return req.SendWebRequest();
        Online = req.result == UnityWebRequest.Result.Success;
        Status = Online ? "en línea" : "sin conexión";
        req.Dispose();
    }
}
