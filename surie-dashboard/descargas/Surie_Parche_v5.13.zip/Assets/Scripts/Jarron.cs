using UnityEngine;

/// <summary>Jarrón de la mesa: si Surie lo toca, se cae (+1 estrés).</summary>
[RequireComponent(typeof(Rigidbody))]
public class Jarron : MonoBehaviour
{
    bool fallen;

    void Awake()
    {
        var rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.constraints = RigidbodyConstraints.FreezePositionZ;
    }

    void OnCollisionEnter(Collision c)
    {
        if (fallen || c.collider.GetComponentInParent<PlayerController2D>() == null) return;
        fallen = true;
        var rb = GetComponent<Rigidbody>();
        rb.isKinematic = false;
        float dir = c.transform.position.x < transform.position.x ? 1f : -1f;
        rb.AddForce(new Vector3(dir * 3f, 2f, 0f), ForceMode.Impulse);
        rb.AddTorque(new Vector3(0f, 0f, -dir * 2f), ForceMode.Impulse);
        GameManager.I.AddStress(1, "¡Se cayó el jarrón! +1 estrés");
        Destroy(gameObject, 4f);
    }
}
