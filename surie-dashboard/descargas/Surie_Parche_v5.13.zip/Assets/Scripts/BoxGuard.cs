using UnityEngine;

/// <summary>Evita que la caja empujable estorbe: si se sale de su zona o se atora, vuelve a su sitio.</summary>
public class BoxGuard : MonoBehaviour
{
    public float minX, maxX, homeX;
    Vector3 home;
    void Start() { home = transform.position; }
    void FixedUpdate()
    {
        Vector3 p = transform.position;
        if (p.x < minX || p.x > maxX || p.y < -3f) { ResetBox(); return; }
    }
    void ResetBox()
    {
        transform.position = home;
        var rb = GetComponent<Rigidbody>(); if (rb != null) { rb.SetVel(Vector3.zero); }
    }
}
