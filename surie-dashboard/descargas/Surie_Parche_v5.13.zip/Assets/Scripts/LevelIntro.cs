using UnityEngine;

/// <summary>
/// Escena corta al inicio de los niveles 2-6: Benito aparece con el juguete de Surie, se ríe y sale corriendo.
/// Mientras dura, Surie no se puede mover (Espacio/Enter la salta).
/// </summary>
public class LevelIntro : MonoBehaviour
{
    public Transform benito;          // raíz (el modelo ya mira a +X con yaw 0)
    public GameObject toy;            // juguete en la boca de Benito
    public string[] lines;
    public float runUntilX = 30f;
    float t;
    bool unlocked, finished;
    GUIStyle st;

    void Start()
    {
        Inp.Locked = true;
        if (benito != null) benito.rotation = Quaternion.Euler(0f, 180f, 0f);   // mira a Surie
    }

    void OnDestroy() { Inp.Locked = false; }

    void Update()
    {
        if (finished) return;
        t += Time.deltaTime;
        if (t > 6.5f && benito != null) benito.gameObject.SetActive(false);
        if (Inp.ConfirmDown() && t > 0.5f && t < 3.2f) t = 3.2f;       // saltar la parte de diálogo
        if (benito != null)
        {
            if (t < 3.2f)
            {
                float hop = t > 0.7f && t < 2.6f ? Mathf.Abs(Mathf.Sin((t - 0.7f) * 9f)) * 0.22f : 0f;   // se ríe a saltitos
                var p = benito.position; p.y = hop; benito.position = p;
            }
            else
            {
                benito.rotation = Quaternion.Euler(0f, 0f, 0f);
                var p = benito.position; p.y = 0f; p.x += 7.5f * Time.deltaTime; benito.position = p;
                if (p.x > runUntilX || t > 5.4f) { benito.gameObject.SetActive(false); }
            }
        }
        if (t >= 3.2f && !unlocked) { unlocked = true; Inp.Locked = false; }
        if (t > 6.5f) finished = true;
    }

    void OnGUI()
    {
        if (finished || lines == null || lines.Length == 0) return;
        if (st == null) st = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold, wordWrap = true };
        float k = Screen.height / 720f;
        st.fontSize = Mathf.RoundToInt(24 * k);
        int i = Mathf.Min(t < 1.6f ? 0 : (t < 3.2f ? 1 : 2), lines.Length - 1);
        float a = t > 5.6f ? Mathf.Clamp01((6.5f - t) / 0.9f) : 1f;
        Rect r = new Rect(Screen.width * 0.12f, Screen.height * 0.64f, Screen.width * 0.76f, 96 * k);
        GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.85f * a);
        GUI.DrawTexture(r, Texture2D.whiteTexture);
        GUI.color = new Color(1f, 0.93f, 0.75f, a);
        GUI.Label(r, lines[i], st);
        if (t < 3.2f)
        {
            var s2 = new GUIStyle(st); s2.fontSize = Mathf.RoundToInt(14 * k);
            GUI.color = new Color(1f, 1f, 1f, 0.6f);
            GUI.Label(new Rect(r.x, r.yMax - 22 * k, r.width, 20 * k), "ESPACIO = saltar", s2);
        }
        GUI.color = Color.white;
    }
}
