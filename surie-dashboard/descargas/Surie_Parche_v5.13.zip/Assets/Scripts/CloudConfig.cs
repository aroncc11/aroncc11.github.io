/// <summary>Conexión a la base de datos en línea (Supabase). La clave "anon" solo permite insertar y leer métricas.</summary>
public static class CloudConfig
{
    public const string Url = "https://wzgnpnqiwmcfhyhcfsqq.supabase.co";
    public const string Key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind6Z25wbnFpd21jZmh5aGNmc3FxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxNTA2MTAsImV4cCI6MjEwODcyNjYxMH0._AUwSOMBcNXwPrEquszhehFiKJdFybID2m98bQiccXs";
    public static bool Enabled = true;
}
