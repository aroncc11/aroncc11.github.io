using UnityEngine;

/// <summary>Nombre del jugador (estilo arcade, hasta 6 caracteres). Se guarda y se envía con las métricas.</summary>
public static class PlayerName
{
    public const string Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
    public const int Len = 6;
    public static string Current
    {
        get
        {
            string s = PlayerPrefs.GetString("surie_nombre", "").Trim();
            return s.Length == 0 ? "JUGADOR" : s;
        }
    }
    public static void Save(string s) { PlayerPrefs.SetString("surie_nombre", s.Trim()); }
    public static string Raw { get { return PlayerPrefs.GetString("surie_nombre", ""); } }
}
