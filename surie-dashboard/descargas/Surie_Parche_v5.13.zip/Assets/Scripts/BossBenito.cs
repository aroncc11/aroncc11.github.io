using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Jefe final: Benito (nivel 6). 6 puntos de vida, 3 fases. Cada ciclo de ataques termina con Benito MAREADO:
/// ahí se le hace daño pisándolo o con el dash.
///   Salto aplastante: aterriza y lanza 2 ondas por el piso (hay que saltarlas).
///   Lluvia de ovillos: caen ovillos donde aparece una marca roja.
///   Rodar: se hace bolita y cruza la arena; al chocar con la pared queda mareado.
/// El dash da invulnerabilidad corta. Al perder una vida se reaparece en la entrada de la arena (el jefe conserva su vida).
/// </summary>
public class BossBenito : MonoBehaviour
{
    public float triggerX, arenaMin, arenaMax;
    public Transform spin, visual;
    public GameObject toy, wallLeft;
    public Vector3 toyAt;
    public int maxHp = 6;

    enum S { Sleep, Intro, Idle, TeleJump, Air, TeleRain, Rain, TeleRoll, Roll, Stun, Hurt, Dead }
    S s = S.Sleep;
    int hp, pat;
    float tt, x, hurtCd, airFrom, airTo, rollDir, restUntil;
    Vector3 spinBase; float spinY0;
    bool init;
    Rigidbody prb;
    Material baseMat;
    readonly Dictionary<int, Material> cache = new Dictionary<int, Material>();
    class Wave { public Transform t; public float dir, speed; }
    class Ball { public Transform o, m; public float x, delay, fall, y; public bool falling; }
    readonly List<Wave> waves = new List<Wave>();
    readonly List<Ball> balls = new List<Ball>();
    readonly List<Transform> stars = new List<Transform>();
    GUIStyle gs;

    int Phase() { return hp > 4 ? 1 : (hp > 2 ? 2 : 3); }

    void Init()
    {
        init = true;
        hp = maxHp;
        x = transform.position.x;
        spinBase = spin.localScale; spinY0 = spin.localPosition.y;
        var r = visual != null ? visual.GetComponentInChildren<Renderer>() : null;
        if (r != null) baseMat = r.sharedMaterial;
        var gm = GameManager.I;
        if (gm != null && gm.player != null) prb = gm.player.GetComponent<Rigidbody>();
        if (wallLeft != null) wallLeft.SetActive(false);
    }

    Material MatOf(Color c)
    {
        int key = c.GetHashCode();
        Material m;
        if (cache.TryGetValue(key, out m)) return m;
        m = baseMat != null ? new Material(baseMat) : new Material(Shader.Find("Standard"));
        m.mainTexture = null;
        if (m.HasProperty("_BaseMap")) m.SetTexture("_BaseMap", null);
        m.color = c;
        cache[key] = m;
        return m;
    }

    Transform Make(PrimitiveType pt, Vector3 pos, Vector3 scale, Color c)
    {
        var g = GameObject.CreatePrimitive(pt);
        var col = g.GetComponent<Collider>(); if (col != null) Destroy(col);
        g.transform.position = pos; g.transform.localScale = scale;
        g.GetComponent<Renderer>().sharedMaterial = MatOf(c);
        return g.transform;
    }

    void Go(S n) { s = n; tt = 0f; }

    void Face(float dx)
    {
        if (visual != null && s != S.Stun && s != S.Hurt && s != S.Dead) visual.localRotation = Quaternion.Euler(0f, dx >= 0f ? 90f : -90f, 0f);
    }

    void HitPlayer(string why, float side)
    {
        var gm = GameManager.I;
        if (hurtCd > 0f || gm.player.IsDashing || gm.won) return;
        hurtCd = 1.3f;
        gm.AddStress(1, why);
        gm.player.Knock(new Vector2(side * 4f, 6f));
    }

    void Update()
    {
        var gm = GameManager.I;
        if (gm == null || gm.player == null) return;
        if (!init) Init();
        if (gm.paused || gm.won || gm.lost) return;
        float dt = Time.deltaTime;
        tt += dt; hurtCd -= dt;
        Vector3 pp = gm.player.transform.position;
        float pvy = prb != null ? prb.GetVel().y : 0f;
        UpdateWaves(dt, pp);
        UpdateBalls(dt, pp);
        float toP = pp.x - x;

        switch (s)
        {
            case S.Sleep:
                if (pp.x > triggerX) Begin(gm);
                break;
            case S.Intro:
                Face(toP);
                if (tt > 2.6f) Go(S.Idle);
                break;
            case S.Idle:
                Face(toP);
                spin.localScale = Vector3.Lerp(spin.localScale, spinBase, 1f - Mathf.Exp(-10f * dt));
                spin.localRotation = Quaternion.Slerp(spin.localRotation, Quaternion.identity, 1f - Mathf.Exp(-10f * dt));
                spin.localPosition = new Vector3(0f, spinY0, 0f);
                if (tt > 0.55f) NextAttack(gm);
                break;
            case S.TeleJump:
                Face(toP);
                spin.localScale = new Vector3(spinBase.x, spinBase.y * (1f - 0.2f * Mathf.Min(1f, tt / 0.5f)), spinBase.z);
                if (tt > 0.45f) { airFrom = x; airTo = Mathf.Clamp(pp.x, arenaMin + 1.6f, arenaMax - 1.6f); Go(S.Air); }
                break;
            case S.Air:
                {
                    float dur = Phase() == 3 ? 0.55f : 0.68f;
                    float f = Mathf.Clamp01(tt / dur);
                    x = Mathf.Lerp(airFrom, airTo, f);
                    float y = 2.2f * 4f * f * (1f - f);
                    transform.position = new Vector3(x, y, 0f);
                    spin.localScale = Vector3.Lerp(spin.localScale, spinBase, 1f - Mathf.Exp(-12f * dt));
                    Face(airTo - airFrom);
                    if (f >= 1f)
                    {
                        transform.position = new Vector3(x, 0f, 0f);
                        float sp = Phase() == 3 ? 7.4f : 6.2f;
                        SpawnWave(x - 0.6f, -1f, sp); SpawnWave(x + 0.6f, 1f, sp);
                        if (Mathf.Abs(pp.x - x) < 0.8f && pp.y < 0.9f) HitPlayer("¡Benito te aplastó! +1 estrés", pp.x >= x ? 1f : -1f);
                        Go(S.Idle);
                    }
                    break;
                }
            case S.TeleRain:
                Face(toP);
                if (tt > 0.4f)
                {
                    int n = Phase() == 2 ? 3 : 5;
                    for (int i = 0; i < n; i++)
                        SpawnBall(Mathf.Clamp(pp.x + Random.Range(-3.8f, 3.8f), arenaMin + 0.8f, arenaMax - 0.8f), i * 0.42f);
                    Go(S.Rain);
                }
                break;
            case S.Rain:
                Face(toP);
                if (balls.Count == 0 && tt > 0.8f) Go(S.Idle);
                break;
            case S.TeleRoll:
                {
                    if (tt < 0.05f) rollDir = (x > (arenaMin + arenaMax) * 0.5f) ? -1f : 1f;
                    float k = Mathf.Min(1f, tt / 0.55f);
                    spin.localScale = Vector3.Lerp(spinBase, spinBase * 0.5f, k);
                    spin.localPosition = new Vector3(Random.Range(-0.03f, 0.03f), Mathf.Lerp(spinY0, 0.24f, k), 0f);
                    Face(rollDir);
                    if (tt > 0.7f) Go(S.Roll);
                    break;
                }
            case S.Roll:
                {
                    float sp = Phase() == 3 ? 7.8f : 6.6f;
                    x += rollDir * sp * dt;
                    float lim = rollDir > 0f ? arenaMax - 1.1f : arenaMin + 1.1f;
                    bool end = rollDir > 0f ? x >= lim : x <= lim;
                    if (end) x = lim;
                    transform.position = new Vector3(x, 0f, 0f);
                    spin.localRotation = Quaternion.Euler(0f, 0f, spin.localEulerAngles.z - rollDir * sp / 0.25f * Mathf.Rad2Deg * dt);
                    if (Mathf.Abs(pp.x - x) < 0.6f && pp.y < 0.6f) HitPlayer("¡Benito te atropelló! +1 estrés", pp.x >= x ? 1f : -1f);
                    if (end)
                    {
                        Go(S.Stun);
                        spin.localScale = spinBase;
                        spin.localPosition = new Vector3(0f, spinY0, 0f);
                        spin.localRotation = Quaternion.Euler(180f, 0f, 0f);       // patas arriba
                        for (int i = 0; i < 3; i++) stars.Add(Make(PrimitiveType.Sphere, transform.position, Vector3.one * 0.22f, new Color(1f, 0.9f, 0.2f)));
                        gm.Say("¡Benito quedó mareado! ¡Písalo desde arriba o usa el dash!", 3.2f);
                        Analytics.Event("boss_mareado", "vida=" + hp);
                    }
                    break;
                }
            case S.Stun:
                {
                    for (int i = 0; i < stars.Count; i++)
                    {
                        float a = Time.time * 4f + i * 2.1f;
                        stars[i].position = transform.position + new Vector3(Mathf.Cos(a) * 0.55f, 1.1f + Mathf.Sin(a * 0.5f) * 0.08f, Mathf.Sin(a) * 0.3f);
                    }
                    if (Mathf.Abs(toP) < 0.95f && pp.y < 1.0f)
                    {
                        bool stomp = pp.y > 0.3f && pvy <= 1.5f;
                        if (stomp || gm.player.IsDashing) { Damage(gm, stomp); break; }
                    }
                    if (tt > 4.2f) { ClearStars(); Go(S.Idle); gm.Say("¡Benito se recuperó!", 1.5f); }
                    break;
                }
            case S.Hurt:
                {
                    float sh = Mathf.Sin(tt * 60f) * 0.08f * (1f - tt / 1.0f);
                    spin.localPosition = new Vector3(sh, spinY0, 0f);
                    if (tt > 1.0f) { ClearStars(); Go(S.Idle); }
                    break;
                }
            case S.Dead:
                {
                    spin.localPosition = new Vector3(0f, spinY0 + Mathf.Sin(Time.time * 2f) * 0.03f, 0f);
                    break;
                }
        }

        // contacto con el cuerpo de pie
        if ((s == S.Idle || s == S.TeleJump || s == S.TeleRain || s == S.Rain || s == S.TeleRoll || s == S.Intro) && Mathf.Abs(toP) < 0.6f && pp.y < 0.9f)
            HitPlayer("¡Benito te golpeó! +1 estrés", pp.x >= x ? 1f : -1f);
    }

    void Begin(GameManager gm)
    {
        Go(S.Intro);
        if (wallLeft != null) wallLeft.SetActive(true);
        gm.startPoint = new Vector3(arenaMin + 2.2f, 1.0f, 0f);
        gm.respawnPoint = gm.startPoint;
        gm.Say("BENITO: ¡El juguete es MÍO! Aguántalo: ¡pisa o usa el dash cuando se maree!", 3.4f);
        Analytics.Event("boss_inicio");
        AudioManager.PlayMusic("musica_jefe");
        AudioManager.Sfx("estres");
    }

    void NextAttack(GameManager gm)
    {
        S[] a;
        int ph = Phase();
        if (ph == 1) a = new[] { S.TeleJump, S.TeleRoll };
        else if (ph == 2) a = new[] { S.TeleRain, S.TeleRoll };
        else a = new[] { S.TeleJump, S.TeleRain, S.TeleRoll };
        S n = a[pat % a.Length]; pat++;
        if (n == S.TeleJump) gm.Say("¡MIAU! Va a saltar: ¡salta sus ondas!", 1.6f);
        if (n == S.TeleRain) gm.Say("¡Ovillos! Huye de las marcas rojas", 1.6f);
        if (n == S.TeleRoll) gm.Say("Se hace bolita... ¡salta sobre él!", 1.6f);
        Go(n);
    }

    void Damage(GameManager gm, bool stomp)
    {
        hp--;
        Analytics.Event("boss_dano", "vida=" + hp);
        ClearStars();
        AudioManager.Sfx("letra");
        gm.AddEnergy(1f);
        if (stomp) gm.player.Knock(new Vector2(0f, 7.5f));
        if (hp <= 0) { Die(gm); return; }
        Go(S.Hurt);
        gm.Say("¡Le diste! Benito: " + hp + " / " + maxHp, 2f);
    }

    void Die(GameManager gm)
    {
        Go(S.Dead);
        ClearStars();
        foreach (var w in waves) if (w.t != null) Destroy(w.t.gameObject);
        waves.Clear();
        foreach (var b in balls) { if (b.o != null) Destroy(b.o.gameObject); if (b.m != null) Destroy(b.m.gameObject); }
        balls.Clear();
        spin.localRotation = Quaternion.Euler(180f, 0f, 0f);
        Analytics.Event("boss_derrotado");
        AudioManager.PlayMusic("musica_nivel6");
        gm.Say("¡Benito se rinde! Suelta el juguete: ¡recógelo!", 4f);
        if (wallLeft != null) wallLeft.SetActive(false);
        if (toy != null) { toy.transform.position = toyAt; toy.SetActive(true); }
        gm.chaseDanger = 0f;
    }

    void ClearStars() { foreach (var t in stars) if (t != null) Destroy(t.gameObject); stars.Clear(); }

    void SpawnWave(float wx, float dir, float speed)
    {
        var t = Make(PrimitiveType.Cube, new Vector3(wx, 0.2f, 0f), new Vector3(0.4f, 0.4f, 1.0f), new Color(1f, 0.55f, 0.15f));
        waves.Add(new Wave { t = t, dir = dir, speed = speed });
    }

    void UpdateWaves(float dt, Vector3 pp)
    {
        for (int i = waves.Count - 1; i >= 0; i--)
        {
            var w = waves[i];
            var p = w.t.position; p.x += w.dir * w.speed * dt; w.t.position = p;
            w.t.localScale = new Vector3(0.55f, 0.56f * (0.85f + 0.15f * Mathf.Sin(Time.time * 30f)), 1f);
            if (Mathf.Abs(pp.x - p.x) < 0.5f && pp.y < 0.45f) HitPlayer("¡Onda de choque! +1 estrés", pp.x >= p.x ? 1f : -1f);
            if (p.x < arenaMin - 1f || p.x > arenaMax + 1f) { Destroy(w.t.gameObject); waves.RemoveAt(i); }
        }
    }

    void SpawnBall(float bx, float delay)
    {
        var m = Make(PrimitiveType.Cylinder, new Vector3(bx, 0.03f, 0f), new Vector3(1.0f, 0.01f, 1.0f), new Color(0.9f, 0.1f, 0.1f));
        var o = Make(PrimitiveType.Sphere, new Vector3(bx, 7.5f, 0f), Vector3.one * 1.0f, new Color(0.85f, 0.25f, 0.45f));
        balls.Add(new Ball { o = o, m = m, x = bx, delay = delay, y = 7.5f });
        o.gameObject.SetActive(false); m.gameObject.SetActive(false);
    }

    void UpdateBalls(float dt, Vector3 pp)
    {
        for (int i = balls.Count - 1; i >= 0; i--)
        {
            var b = balls[i];
            b.delay -= dt;
            if (b.delay > 0f) continue;
            if (!b.o.gameObject.activeSelf) { b.o.gameObject.SetActive(true); b.m.gameObject.SetActive(true); b.fall = 0f; }
            b.fall += dt;
            float pulse = 0.8f + 0.25f * Mathf.Sin(Time.time * 18f);
            b.m.localScale = new Vector3(1.0f * pulse, 0.01f, 1.0f * pulse);
            if (b.fall > 1.0f)
            {
                b.falling = true;
                b.y -= 16f * dt;
                b.o.position = new Vector3(b.x, b.y, 0f);
                if (b.y <= 0.55f)
                {
                    if (Mathf.Abs(pp.x - b.x) < 0.8f && pp.y < 1.2f) HitPlayer("¡Te cayó un ovillo! +1 estrés", pp.x >= b.x ? 1f : -1f);
                    Destroy(b.o.gameObject); Destroy(b.m.gameObject); balls.RemoveAt(i);
                }
            }
            else b.o.position = new Vector3(b.x, b.y, 0f);
        }
    }

    void OnGUI()
    {
        var gm = GameManager.I;
        if (!init || gm == null || s == S.Sleep || s == S.Dead || gm.lost) return;
        if (gs == null) gs = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
        float k = Screen.height / 720f;
        gs.fontSize = Mathf.RoundToInt(18 * k);
        float w = 360 * k, h = 30 * k, x0 = Screen.width * 0.5f - w * 0.5f, y0 = 50 * k;
        GUI.color = new Color(0.08f, 0.04f, 0.16f, 0.85f);
        GUI.DrawTexture(new Rect(x0 - 6 * k, y0 - 4 * k, w + 12 * k, h + 8 * k), Texture2D.whiteTexture);
        float sw = (w - 70 * k) / maxHp;
        for (int i = 0; i < maxHp; i++)
        {
            GUI.color = i < hp ? new Color(0.9f, 0.3f, 0.3f) : new Color(1f, 1f, 1f, 0.18f);
            GUI.DrawTexture(new Rect(x0 + 68 * k + i * sw, y0 + 4 * k, sw - 4 * k, h - 8 * k), Texture2D.whiteTexture);
        }
        GUI.color = new Color(1f, 0.93f, 0.75f);
        GUI.Label(new Rect(x0, y0, 66 * k, h), "BENITO", gs);
        GUI.color = Color.white;
    }
}
