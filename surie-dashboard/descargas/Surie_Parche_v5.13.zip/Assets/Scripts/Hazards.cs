using UnityEngine;

/// <summary>
/// Peligro que se enciende y se apaga con aviso (llamas de la estufa, chorros de aspersor, tapa del inodoro...).
/// Va en un objeto con un Collider "Is Trigger". Mientras está ENCENDIDO: +1 estrés y empujón. Antes de encenderse, avisa (parpadea).
/// </summary>
public class TimedHazard : MonoBehaviour
{
    public float onTime = 1.6f, offTime = 2.2f, warnTime = 0.6f, phase;
    public string message = "¡Ouch! +1 estrés";
    public Transform fx;                       // efecto visual (llama, chorro, agua del inodoro)
    public Transform lid;                      // tapa del inodoro (opcional): se levanta cuando está encendido
    public float lidAngle = -100f;
    public Vector2 knock = new Vector2(3.5f, 6f);
    public bool IsOn { get; private set; }
    float cd, open;
    Vector3 fxScale;
    bool init;

    void Update()
    {
        if (!init) { init = true; if (fx != null) fxScale = fx.localScale; }
        float cyc = onTime + offTime;
        float t = Mathf.Repeat(Time.time + phase, cyc);
        IsOn = t < onTime;
        bool warn = !IsOn && t > cyc - warnTime;
        cd -= Time.deltaTime;
        float k = IsOn ? 1f : (warn ? 0.22f + 0.1f * Mathf.Sin(Time.time * 40f) : 0f);
        if (fx != null)
        {
            fx.gameObject.SetActive(k > 0.01f);
            float fl = IsOn ? 1f + 0.12f * Mathf.Sin(Time.time * 28f) : 1f;
            fx.localScale = new Vector3(fxScale.x * (0.55f + 0.45f * k), fxScale.y * k * fl, fxScale.z * (0.55f + 0.45f * k));
        }
        if (lid != null)
        {
            float goal = IsOn ? 1f : (warn ? 0.1f + 0.08f * Mathf.Sin(Time.time * 35f) : 0f);
            open = Mathf.Lerp(open, goal, 1f - Mathf.Exp(-14f * Time.deltaTime));
            lid.localRotation = Quaternion.Euler(0f, 0f, lidAngle * open);
        }
    }

    Collider col;

    // Se revisa cada cuadro si Surie está dentro de la zona (más confiable que OnTriggerStay, que deja de llamarse si el cuerpo "duerme").
    void LateUpdate()
    {
        if (!IsOn || cd > 0f) return;
        var gm = GameManager.I;
        if (gm == null || gm.player == null || gm.won) return;
        if (col == null) col = GetComponent<Collider>();
        if (col == null) return;
        Bounds b = col.bounds;
        Vector3 c = gm.player.transform.position + new Vector3(0f, 0.25f, 0f);
        if (Mathf.Abs(c.x - b.center.x) > b.extents.x + 0.25f || Mathf.Abs(c.y - b.center.y) > b.extents.y + 0.3f) return;
        cd = 1.3f;
        gm.AddStress(1, message);
        float side = c.x >= b.center.x ? 1f : -1f;
        gm.player.Knock(new Vector2(side * knock.x, knock.y));
    }
}

/// <summary>
/// Objeto que cuelga, avisa temblando (con una sombra en el piso) y cae: ramas, gotas, tazas...
/// Solo se activa cuando Surie está cerca. Si le cae encima: +1 estrés.
/// </summary>
public class FallingHazard : MonoBehaviour
{
    public Transform obj;
    public Transform marker;
    public float groundY = 0.2f, radius = 0.6f;
    public float interval = 3.4f, warn = 0.9f, activeRange = 9f, phase;   // activeRange ya no se usa: siempre cicla
    public string message = "¡Te cayó encima! +1 estrés";
    const float Grav = 26f;
    float cd, prevY, fallTime, cycle, hang;
    Vector3 top, markScale, objScale;
    bool init;
    Renderer[] rends;

    void Show(bool on)
    {
        if (rends == null) rends = obj.GetComponentsInChildren<Renderer>(true);
        foreach (var r in rends) if (r != null && r.enabled != on) r.enabled = on;
    }

    // Ciclo fijo en función del reloj (igual que las llamas): cuelga → tiembla con sombra → cae → salpica → vuelve a formarse.
    void Update()
    {
        if (obj == null) return;
        if (!init)
        {
            init = true;
            top = obj.position; objScale = obj.localScale; prevY = top.y;
            if (marker != null) markScale = marker.localScale;
            fallTime = Mathf.Sqrt(2f * Mathf.Max(0.1f, top.y - groundY) / Grav);
            hang = Mathf.Max(0.5f, interval - warn);
            cycle = hang + warn + fallTime + 0.35f;
        }
        cd -= Time.deltaTime;
        float u = Mathf.Repeat(Time.time + phase, cycle);
        float y = top.y;
        if (u < hang)
        {
            Show(true);
            obj.localScale = objScale * Mathf.Clamp01(0.15f + u / 0.45f);
            obj.position = top;
            if (marker != null) marker.gameObject.SetActive(false);
        }
        else if (u < hang + warn)
        {
            Show(true);
            obj.localScale = objScale;
            obj.position = top + new Vector3(Mathf.Sin(Time.time * 55f) * 0.05f, 0f, 0f);
            if (marker != null) { marker.gameObject.SetActive(true); marker.localScale = markScale * (0.5f + 0.5f * (u - hang) / warn); }
        }
        else if (u < hang + warn + fallTime)
        {
            float tf = u - hang - warn;
            y = Mathf.Max(groundY, top.y - 0.5f * Grav * tf * tf);
            Show(true);
            obj.localScale = objScale;
            obj.position = new Vector3(top.x, y, top.z);
            if (marker != null) { marker.gameObject.SetActive(true); marker.localScale = markScale; }
            var gm = GameManager.I;
            if (gm != null && gm.player != null && cd <= 0f && !gm.won)
            {
                Vector3 pp = gm.player.transform.position;
                float hi = Mathf.Max(prevY, y), lo = Mathf.Min(prevY, y);      // tramo recorrido en este cuadro
                if (Mathf.Abs(pp.x - top.x) < radius && lo < pp.y + 0.95f && hi > pp.y - 0.1f)
                {
                    cd = 1.2f;
                    gm.AddStress(1, message);
                    gm.player.Knock(new Vector2(pp.x >= top.x ? 3.5f : -3.5f, 5f));
                }
            }
        }
        else
        {
            Show(false);
            if (marker != null) { marker.gameObject.SetActive(true); marker.localScale = markScale * (1f + 2f * (u - hang - warn - fallTime)); }
        }
        prevY = y;
    }
}

/// <summary>Movimiento decorativo: flota, se mece o gira.</summary>
public class Wobble : MonoBehaviour
{
    public Vector3 posAmp, rotAmp, spin;
    public float speed = 1f, phase;
    Vector3 p0; Quaternion r0; bool init;

    void Update()
    {
        if (!init) { init = true; p0 = transform.localPosition; r0 = transform.localRotation; }
        float s = Mathf.Sin((Time.time + phase) * speed * 2f);
        transform.localPosition = p0 + posAmp * s;
        transform.localRotation = r0 * Quaternion.Euler(rotAmp * s) * Quaternion.Euler(spin * (Time.time + phase));
    }
}

/// <summary>
/// Apagón del sótano: cada cierto tiempo la luz parpadea y se va. Solo se ve un círculo de luz alrededor de Surie.
/// </summary>
public class LightsOut : MonoBehaviour
{
    public float litTime = 10f, darkTime = 5f, fade = 0.8f;      // segundos con luz, segundos a oscuras, duración del cambio
    enum Ph { Lit, Flicker, Dark, Back }
    Ph ph = Ph.Lit;
    float t, nextAt, a;
    Texture2D tex;
    bool told;

    void Start() { nextAt = 5f; }      // el primer apagón llega pronto para que se note

    // Textura blanca con transparencia circular (igual que la viñeta roja del estrés, que sí se dibuja bien):
    // transparente en el centro (lo que Surie alcanza a ver) y opaca alrededor. El color oscuro lo pone GUI.color.
    const float HoleIn = 0.09f, HoleOut = 0.2f;
    void MakeTex()
    {
        int n = 256;
        tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                float dx = (x + 0.5f - n * 0.5f) / (n * 0.5f), dy = (y + 0.5f - n * 0.5f) / (n * 0.5f);
                float r = Mathf.Sqrt(dx * dx + dy * dy);
                float k = Mathf.Clamp01((r - HoleIn) / (HoleOut - HoleIn));        // 0 dentro del círculo, 1 fuera
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, k * k * (3f - 2f * k)));
            }
        tex.Apply();
    }

    // Ciclo sin parpadeo: luz encendida (litTime) → se apaga suave → oscuro (darkTime) → vuelve suave → se repite.
    void Update()
    {
        var gm = GameManager.I;
        if (gm == null || gm.won || gm.lost || gm.paused) return;
        t += Time.deltaTime;
        switch (ph)
        {
            case Ph.Lit:
                a = Mathf.MoveTowards(a, 0f, Time.deltaTime / fade);
                if (t >= nextAt) { ph = Ph.Dark; t = 0f; gm.Say("¡Se fue la luz! Solo ves alrededor de Surie", 2.4f); Analytics.Event("apagon"); }
                break;
            default:
                a = Mathf.MoveTowards(a, 0.93f, Time.deltaTime / fade);
                if (t >= darkTime) { ph = Ph.Lit; t = 0f; nextAt = litTime; }
                break;
        }
    }

    void OnGUI()
    {
        if (a < 0.01f) return;
        var gm = GameManager.I;
        var cam = Camera.main;
        if (gm == null || gm.player == null || cam == null) return;
        if (tex == null) MakeTex();
        GUI.depth = 5;
        Vector3 c = cam.WorldToScreenPoint(gm.player.transform.position + Vector3.up * 0.3f);
        float W = Screen.width, H = Screen.height;
        float cx = Mathf.Clamp(c.x, 0f, W), cy = Mathf.Clamp(H - c.y, 0f, H);
        // Se dibuja SOLO el rectángulo de la pantalla; con las coordenadas de textura se centra el círculo en Surie.
        // El círculo de luz mide ~28% del alto de la pantalla. Fuera de la textura se repite su borde (opaco).
        float size = 2f * (H * 0.28f) / HoleOut;
        Rect uv = new Rect(0.5f - cx / size, 0.5f - (H - cy) / size, W / size, H / size);   // (v crece hacia arriba)
        Color old = GUI.color;
        GUI.color = new Color(0.01f, 0.01f, 0.05f, a);
        GUI.DrawTextureWithTexCoords(new Rect(0f, 0f, W, H), tex, uv, true);
        GUI.color = old;
    }
}


/// <summary>
/// Obstáculo que el perseguidor destruye al pasar (cajas, macetas). Se rompe en pedazos y se restaura si Surie reaparece antes de él.
/// El objeto lleva el collider (invisible); "visual" es el modelo 3D.
/// </summary>
public class Smashable : MonoBehaviour
{
    public static readonly System.Collections.Generic.List<Smashable> All = new System.Collections.Generic.List<Smashable>();
    public Transform visual;
    public bool broken;
    Collider col;

    void OnEnable() { All.Add(this); }
    void OnDisable() { All.Remove(this); }
    void Start() { col = GetComponent<Collider>(); }

    void Update()
    {
        var gm = GameManager.I;
        if (!broken || gm == null || gm.player == null) return;
        if (gm.player.transform.position.x < transform.position.x - 4f) Restore();
    }

    void Restore()
    {
        broken = false;
        if (col != null) col.enabled = true;
        if (visual != null) visual.gameObject.SetActive(true);
    }

    public void Smash(float dir)
    {
        if (broken) return;
        broken = true;
        if (col == null) col = GetComponent<Collider>();
        if (col != null) col.enabled = false;
        Material m = null;
        if (visual != null)
        {
            var rs = visual.GetComponentsInChildren<Renderer>();
            if (rs.Length > 0) m = rs[0].sharedMaterial;
            visual.gameObject.SetActive(false);
        }
        Vector3 c = visual != null ? visual.position + Vector3.up * 0.3f : transform.position;
        for (int i = 0; i < 9; i++)
        {
            var d = GameObject.CreatePrimitive(PrimitiveType.Cube);
            var dc = d.GetComponent<Collider>(); if (dc != null) Destroy(dc);
            if (m != null) d.GetComponent<Renderer>().sharedMaterial = m;
            d.transform.position = c + new Vector3(Random.Range(-0.2f, 0.2f), Random.Range(-0.2f, 0.3f), Random.Range(-0.2f, 0.2f));
            d.transform.localScale = Vector3.one * Random.Range(0.1f, 0.22f);
            d.AddComponent<Debris>().vel = new Vector3(dir * Random.Range(2f, 6f), Random.Range(3f, 7f), Random.Range(-1f, 1f));
        }
        AudioManager.Sfx("estres");
    }
}

public class Debris : MonoBehaviour
{
    public Vector3 vel;
    float t;
    void Update()
    {
        t += Time.deltaTime;
        vel.y -= 22f * Time.deltaTime;
        transform.position += vel * Time.deltaTime;
        transform.Rotate(vel.x * 90f * Time.deltaTime, 200f * Time.deltaTime, 0f);
        if (transform.position.y < 0.08f) { var p = transform.position; p.y = 0.08f; transform.position = p; vel.y = 0f; vel.x *= 0.9f; }
        if (t > 1.3f) transform.localScale *= 1f - 4f * Time.deltaTime;
        if (t > 1.8f) Destroy(gameObject);
    }
}
