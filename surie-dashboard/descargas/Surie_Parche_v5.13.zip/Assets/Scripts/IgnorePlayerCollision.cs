using UnityEngine;

/// <summary>Los colliders sólidos de este objeto chocan con cajas y muebles pero no con Surie
/// (a Surie la Roomba solo la toca por el trigger: +1 estrés).</summary>
public class IgnorePlayerCollision : MonoBehaviour
{
    void Start()
    {
        var pl = GameManager.I != null ? GameManager.I.player : null;
        var pc = pl != null ? pl.GetComponent<Collider>() : null;
        // la Roomba tampoco empuja ni se atora con la caja empujable (antes la arrastraba y la dejaba trabada)
        var boxGo = GameObject.Find("Caja_Empujable");
        var bc = boxGo != null ? boxGo.GetComponent<Collider>() : null;
        foreach (var c in GetComponents<Collider>())
        {
            if (c.isTrigger) continue;
            if (pc != null) Physics.IgnoreCollision(c, pc);
            if (bc != null) Physics.IgnoreCollision(c, bc);
        }
    }
}
