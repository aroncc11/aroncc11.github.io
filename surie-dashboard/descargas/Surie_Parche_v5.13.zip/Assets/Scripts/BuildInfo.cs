/// <summary>Marca de versión: el nivel construido la guarda; si no coincide con los scripts, el juego avisa que la escena está desactualizada.</summary>
public static class BuildInfo
{
    public const string Stamp = "2026-10-29-F";
    /// <summary>Versión de diseño (para comparar antes/después en el dashboard).</summary>
    public const string Version = "v5.0";
    public const string Patch = "parche v5.13";   // se muestra en el menú para comprobar que los scripts nuevos sí están cargados
}
