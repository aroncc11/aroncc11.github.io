using UnityEngine;

/// <summary>Plataforma que oscila en línea recta (horizontal o vertical). El jugador copia su desplazamiento.</summary>
[RequireComponent(typeof(Rigidbody))]
public class SlidePlatform : MovingBase
{
    public Vector3 amplitude = new Vector3(0.6f, 0f, 0f);
    public float period = 3.5f;
    public float phase;
    Vector3 origin;
    Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
        origin = transform.position;
    }

    void FixedUpdate()
    {
        Vector3 np = origin + amplitude * Mathf.Sin((Time.fixedTime / period + phase) * 2f * Mathf.PI);
        Delta = np - rb.position;
        rb.MovePosition(np);
    }
}
