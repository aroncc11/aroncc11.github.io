using UnityEngine;

/// <summary>
/// Enemigos del juego (v5). Se les puede dañar: pisándolos desde arriba (caer sobre ellos) o con el dash.
/// Si Surie los toca de lado (en el piso) → +1 estrés y empujón. Si pasa por ENCIMA subiendo, no pasa nada.
///   Raton: patrulla.   Mosca: vuela con vaivén.   Cucaracha: rápida y pequeña.   Arana: patrulla y da saltitos.
/// Las patas (hijos llamados "Pata*") se mueven al caminar.
/// </summary>
public class Enemy : MonoBehaviour
{
    public enum Kind { Raton, Mosca, Cucaracha, Arana }
    public Kind kind = Kind.Raton;
    public float xMin, xMax, speed = 1.3f;
    public float baseY, bob = 0.35f;
    public float stompHeight = 0.12f;          // el jugador cuenta como "arriba" si sus pies pasan de baseY + esto
    float dir = 1f, cooldown, dyingT = -1f, t0, hopT, hopCd;
    Vector3 baseScale;
    Transform[] legs;

    void Start()
    {
        baseScale = transform.localScale; baseY = transform.position.y; t0 = Random.value * 6f; hopCd = 1.5f + Random.value * 1.5f;
        var l = new System.Collections.Generic.List<Transform>();
        foreach (var t in GetComponentsInChildren<Transform>()) if (t != transform && t.name.StartsWith("Pata")) l.Add(t);
        legs = l.ToArray();
    }

    void Update()
    {
        if (dyingT >= 0f)
        {
            dyingT += Time.deltaTime;
            float f = Mathf.Clamp01(1f - dyingT / 0.35f);
            transform.localScale = new Vector3(baseScale.x * (1f + (1f - f) * 0.6f), baseScale.y * f, baseScale.z);
            if (dyingT > 0.4f) Destroy(gameObject);
            return;
        }
        cooldown -= Time.deltaTime;
        Vector3 p = transform.position;
        p.x += dir * speed * Time.deltaTime;
        if (p.x > xMax) { p.x = xMax; dir = -1f; }
        if (p.x < xMin) { p.x = xMin; dir = 1f; }
        if (kind == Kind.Mosca) p.y = baseY + Mathf.Sin((Time.time + t0) * 3.2f) * bob;
        if (kind == Kind.Arana)
        {
            hopCd -= Time.deltaTime;
            if (hopCd <= 0f && hopT <= 0f) { hopT = 0.0001f; hopCd = 2f + Random.value * 1.5f; }
            if (hopT > 0f)
            {
                hopT += Time.deltaTime;
                float f = hopT / 0.55f;
                p.y = baseY + Mathf.Sin(Mathf.Clamp01(f) * Mathf.PI) * 0.75f;
                p.x += dir * speed * 1.2f * Time.deltaTime;
                if (f >= 1f) { hopT = 0f; p.y = baseY; }
            }
        }
        transform.position = p;
        transform.rotation = Quaternion.Euler(0f, dir > 0f ? 0f : 180f, 0f);
        // patitas
        if (legs != null)
        {
            float w = (kind == Kind.Cucaracha ? 26f : 16f) * speed;
            for (int i = 0; i < legs.Length; i++)
            {
                float a = Mathf.Sin(Time.time * w + i * 1.9f) * (kind == Kind.Mosca ? 8f : 28f);
                legs[i].localRotation = Quaternion.Euler(0f, 0f, a);
            }
        }
        if (kind == Kind.Mosca)
        {
            var wing = transform.Find("Ala1");
            var wing2 = transform.Find("Ala2");
            float fl = Mathf.Sin(Time.time * 45f) * 18f;
            if (wing != null) wing.localRotation = Quaternion.Euler(fl, 0f, 0f);
            if (wing2 != null) wing2.localRotation = Quaternion.Euler(-fl, 0f, 0f);
        }
    }

    void OnTriggerStay(Collider o) { Touch(o); }
    void OnTriggerEnter(Collider o) { Touch(o); }

    void Touch(Collider o)
    {
        if (dyingT >= 0f) return;
        var pl = o.GetComponentInParent<PlayerController2D>();
        if (pl == null || GameManager.I == null) return;
        var rb = pl.GetComponent<Rigidbody>();
        float vy = rb != null ? rb.GetVel().y : 0f;
        bool above = pl.transform.position.y > transform.position.y + stompHeight;
        bool stomp = above && vy <= 1.2f;
        if (stomp || pl.IsDashing)
        {
            dyingT = 0f;
            Analytics.Event("enemigo_derrotado", kind + (stomp ? " pisotón" : " dash"));
            GameManager.I.EnemyDefeated(kind.ToString());
            if (stomp) pl.Knock(new Vector2(0f, 7f));      // rebote, como en los juegos clásicos
            return;
        }
        if (above) return;                                   // pasa por encima subiendo: sin daño
        if (cooldown > 0f) return;
        cooldown = 1.5f;
        string nm = kind == Kind.Raton ? "el ratón" : kind == Kind.Mosca ? "la mosca" : kind == Kind.Cucaracha ? "la cucaracha" : "la araña";
        GameManager.I.AddStress(1, "¡Te atacó " + nm + "! +1 estrés");
        float side = pl.transform.position.x >= transform.position.x ? 1f : -1f;
        pl.Knock(new Vector2(side * 4f, 5f));
    }
}
