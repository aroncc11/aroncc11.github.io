using UnityEngine;

/// <summary>Cámara fija lateral en tercera persona (2.5D): sigue a Surie en X y un poco en Y.</summary>
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float distance = 10f;
    public float minX = 5.5f;
    public float maxX = 17.0f;
    public float baseY = 2.0f;
    public float smooth = 6f;

    void LateUpdate()
    {
        if (target == null) return;
        float x = Mathf.Clamp(target.position.x, minX, maxX);
        float y = Mathf.Clamp(target.position.y * 0.5f + 1.2f, baseY, baseY + 1.2f);
        Vector3 goal = new Vector3(x, y, -distance);
        transform.position = Vector3.Lerp(transform.position, goal, 1f - Mathf.Exp(-smooth * Time.deltaTime));
        transform.rotation = Quaternion.Euler(2f, 0f, 0f);
    }
}
