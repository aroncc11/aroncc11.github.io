using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Historieta de inicio: 6 viñetas con transición. Espacio/Enter/clic = siguiente; Saltar = ir directo al nivel.</summary>
public class ComicIntro : MonoBehaviour
{
    public string nextScene = "Nivel_Surie";
    public string menuScene = "Menu_Surie";
    public float secondsPerPanel = 4.5f;
    Texture2D[] panels = new Texture2D[6];
    int cur;
    float t0, shown;
    bool leaving;

    void Start()
    {
        Time.timeScale = 1f;
        for (int i = 0; i < panels.Length; i++) panels[i] = Resources.Load<Texture2D>("UI/comic_" + (i + 1));
        AudioManager.PlayMusic("musica_historieta");
        t0 = Time.realtimeSinceStartup;
        AudioManager.Sfx("pagina");
    }

    void Next()
    {
        if (leaving) return;
        if (cur >= panels.Length - 1) { Finish(); return; }
        cur++;
        t0 = Time.realtimeSinceStartup;
        AudioManager.Sfx("pagina");
    }

    void Finish()
    {
        if (leaving) return;
        leaving = true;
        PlayerPrefs.SetInt("surie_comic_visto", 1);
        SceneManager.LoadScene(Progress.SceneExists(Progress.WorldScene) ? Progress.WorldScene : nextScene);
    }

    void OnGUI()
    {
        float k = UiKit.K;
        float t = Time.realtimeSinceStartup - t0;
        GUI.color = new Color(0.1f, 0.06f, 0.16f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // viñeta actual con "pop" de entrada
        float pop = Mathf.Clamp01(t / 0.35f);
        float sc = 0.88f + 0.12f * (1f - Mathf.Pow(1f - pop, 3f));
        float ph = Screen.height * 0.84f * sc, pw = ph * 16f / 9f;
        if (pw > Screen.width * 0.95f) { pw = Screen.width * 0.95f * sc; ph = pw * 9f / 16f; }
        var tex = panels[Mathf.Clamp(cur, 0, panels.Length - 1)];
        float dx = (1f - pop) * 120f * k;
        Rect r = new Rect(Screen.width * 0.5f - pw * 0.5f + dx, Screen.height * 0.5f - ph * 0.5f - 10 * k, pw, ph);
        GUI.color = new Color(1f, 1f, 1f, pop);
        if (tex != null) GUI.DrawTexture(r, tex, ScaleMode.ScaleToFit, true);
        GUI.color = Color.white;

        // puntos de progreso
        for (int i = 0; i < panels.Length; i++)
        {
            GUI.color = i == cur ? new Color(1f, 0.85f, 0.4f) : new Color(1f, 1f, 1f, 0.35f);
            float s = (i == cur ? 16 : 11) * k;
            GUI.DrawTexture(new Rect(Screen.width * 0.5f - panels.Length * 14 * k * 0.5f + i * 14 * k, Screen.height - 26 * k, s * 0.8f, s * 0.8f), Texture2D.whiteTexture);
        }
        GUI.color = Color.white;
        GUI.Label(new Rect(Screen.width * 0.5f - 200 * k, Screen.height - 52 * k, 400 * k, 24 * k), "Espacio / clic = siguiente", UiKit.Small);

        if (UiKit.Button(new Rect(Screen.width - 250 * k, Screen.height - 82 * k, 230 * k, 70 * k), "SALTAR ▶")) Finish();

        var e = Event.current;
        if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.Space || e.keyCode == KeyCode.Return)) { Next(); e.Use(); }
        else if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape) { SceneManager.LoadScene(menuScene); }
        else if (e.type == EventType.MouseDown && !new Rect(Screen.width - 250 * k, Screen.height - 82 * k, 230 * k, 70 * k).Contains(e.mousePosition)) Next();
    }

    void Update()
    {
        if (!leaving && Time.realtimeSinceStartup - t0 > secondsPerPanel + (cur == panels.Length - 1 ? 2.5f : 0f)) Next();
    }
}
