using UnityEngine;

/// <summary>
/// Perseguidor estilo Crash Bandicoot / clásicos de PS1 (v5): sale de una CASA (perro) o una CAJA (ovillo gigante),
/// ladra/avisa y corre detrás de Surie moviendo las patas. De vez en cuando se agacha (aviso) y se lanza (embestida).
/// Si la alcanza: +1 estrés y regresa al último punto de control; el perseguidor reaparece más atrás.
/// </summary>
public class Chaser : MonoBehaviour
{
    public float startX;                 // Surie lo activa al pasar por aquí (metros)
    public float homeX;                  // dónde está la casa (metros)
    public float homeZ = 0f;             // profundidad de la casa (el perro sale de ahí hacia el carril)
    public float speed = 2.2f;           // menor que la velocidad de Surie (2.6)
    public float behind = 6f;            // distancia de referencia detrás de Surie (m)
    public float catchUp = 0.22f;
    public string label = "¡CORRE!";
    public bool roll;                    // true = ovillo/pelota que rueda
    public float rollRadius = 1.2f;
    public float stopX = -1f;            // si > 0: al pasar Surie esta X el perseguidor se cae/desaparece (antes del jefe)
    public Transform visual, house, eyes, bodyT, tail, jaw, rollT;
    public Transform[] legs;             // 0 = del. izq, 1 = del. der, 2 = tras. izq, 3 = tras. der (pivote en la cadera)

    enum St { Hidden, Emerge, Chase, Gone }
    St st = St.Hidden;
    float goneT;
    float x, z, cooldown, emT, phase, lungeCd = 5f, lungeT;
    int lunge;                            // 0 normal, 1 aviso, 2 embestida
    Vector3 houseBase, bodyBase;
    float baseY;
    bool init;

    void Place(float nx) { x = nx; transform.position = new Vector3(x, baseY, z); }

    void Init()
    {
        init = true;
        baseY = transform.position.y;
        if (house != null) houseBase = house.position;
        if (bodyT != null) bodyBase = bodyT.localPosition;
        Hide();
    }

    void Hide()
    {
        st = St.Hidden; lunge = 0; z = homeZ;
        Place(homeX);
        if (visual != null) { visual.gameObject.SetActive(false); visual.localScale = Vector3.one; }
        if (house != null) house.position = houseBase;
    }

    void Update()
    {
        var gm = GameManager.I;
        if (gm == null || gm.player == null) return;
        if (!init) Init();
        if (gm.won || gm.lost || gm.paused) { gm.chaseDanger = 0f; return; }
        float dt = Time.deltaTime;
        float px = gm.player.transform.position.x;
        cooldown -= dt;

        if (st == St.Gone)
        {
            gm.chaseDanger = 0f;
            if (visual != null && visual.gameObject.activeSelf)
            {
                goneT += dt;
                x += speed * 0.6f * Mathf.Max(0f, 1f - goneT) * dt;
                transform.position = new Vector3(x, baseY - goneT * goneT * 6f, z);
                if (rollT != null) rollT.Rotate(0f, 0f, -300f * dt, Space.World);
                if (goneT > 1.3f) visual.gameObject.SetActive(false);
            }
            return;
        }
        if (stopX > 0f && px > stopX && st != St.Hidden)
        {
            st = St.Gone; goneT = 0f; lunge = 0;
            gm.Say("¡Se cayó el perseguidor! Prepárate para Benito", 2.8f);
            return;
        }

        if (st == St.Hidden)
        {
            gm.chaseDanger = 0f;
            if (eyes != null) eyes.gameObject.SetActive(px > homeX - 16f && px < startX && Mathf.Sin(Time.time * 3f) > -0.4f);
            if (px >= startX && px < startX + 9f)
            {
                st = St.Emerge; emT = 0f;
                if (eyes != null) eyes.gameObject.SetActive(false);
                if (visual != null) { visual.gameObject.SetActive(true); visual.localScale = Vector3.one * 0.4f; }
                gm.Say(label + " Algo te persigue: no te detengas", 3.5f);
                Analytics.Event("persecucion_inicio");
                AudioManager.Sfx("estres");
            }
            return;
        }

        if (st == St.Emerge)
        {
            emT += dt;
            float f = Mathf.Clamp01(emT / 1.15f);
            float e = f * f * (3f - 2f * f);
            if (visual != null) visual.localScale = Vector3.one * Mathf.Lerp(0.4f, 1f, e);
            if (house != null) house.position = houseBase + new Vector3(Mathf.Sin(Time.time * 60f) * 0.06f * (1f - f), 0f, 0f);
            x += speed * 0.45f * f * dt;
            z = Mathf.Lerp(homeZ, 0f, e);
            transform.position = new Vector3(x, baseY, z);
            Animate(speed * 0.5f, dt, 0f);
            gm.chaseDanger = Mathf.Clamp01(1f - (px - x - 1f) / 5f) * 0.6f;
            if (emT >= 1.15f) { st = St.Chase; z = 0f; lungeCd = 4.5f; if (house != null) house.position = houseBase; }
            return;
        }

        // ----- persecución
        if (px < x - 1.5f)
        {
            // Surie volvió atrás (reinicio o derrota)
            if (px < startX) { gm.chaseDanger = 0f; Hide(); return; }
            Place(px - behind - 2f);
        }
        float dist = px - x;
        float v = speed + Mathf.Max(0f, dist - behind) * catchUp;
        // embestida: se agacha (aviso) y se lanza
        lungeCd -= dt;
        if (lunge == 0 && lungeCd <= 0f && dist > 3.4f && !roll) { lunge = 1; lungeT = 0f; gm.Say("¡GRRR! Se agacha... ¡va a embestir!", 1.6f); }
        if (lunge == 1) { lungeT += dt; v *= 0.35f; if (lungeT >= 0.7f) { lunge = 2; lungeT = 0f; } }
        else if (lunge == 2) { lungeT += dt; v *= 1.9f; if (lungeT >= 1.0f) { lunge = 0; lungeCd = Random.Range(5f, 7.5f); } }
        x += v * dt;
        SmashAhead();
        transform.position = new Vector3(x, baseY, z);
        Animate(v, dt, lunge == 1 ? 1f : (lunge == 2 ? 2f : 0f));
        gm.chaseDanger = Mathf.Clamp01(1f - (dist - 1f) / 5f);
        if (dist < 1.1f && cooldown <= 0f)
        {
            cooldown = 2f;
            Analytics.Event("perseguidor_alcanzo");
            gm.AddStress(1, "¡Te alcanzó! +1 estrés");
            gm.RespawnPlayer();
            Place(gm.respawnPoint.x - behind - 1f);
            lunge = 0; lungeCd = 5f;
        }
    }

    void SmashAhead()
    {
        for (int i = Smashable.All.Count - 1; i >= 0; i--)
        {
            var sm = Smashable.All[i];
            if (sm == null || sm.broken) continue;
            float sx = sm.transform.position.x;
            if (sx < x + 1.2f && sx > x - 3f) sm.Smash(1f);
        }
    }

    void Animate(float v, float dt, float mode)
    {
        phase += v * dt * (roll ? 1f : 2.3f);
        if (roll)
        {
            if (rollT != null) rollT.Rotate(0f, 0f, -v / rollRadius * Mathf.Rad2Deg * dt, Space.World);
            if (visual != null) visual.localPosition = new Vector3(0f, Mathf.Abs(Mathf.Sin(phase * 0.6f)) * 0.12f, 0f);
            return;
        }
        float amp = mode == 1f ? 6f : 50f;
        if (legs != null)
            for (int i = 0; i < legs.Length; i++)
            {
                if (legs[i] == null) continue;
                float a = Mathf.Sin(phase + ((i == 0 || i == 3) ? 0f : Mathf.PI)) * amp;
                legs[i].localRotation = Quaternion.Euler(0f, 0f, a);
            }
        if (bodyT != null)
        {
            float bob = mode == 1f ? -0.28f : Mathf.Abs(Mathf.Sin(phase)) * 0.14f;
            bodyT.localPosition = bodyBase + new Vector3(0f, bob, 0f);
            bodyT.localRotation = Quaternion.Euler(0f, 0f, mode == 1f ? -6f : Mathf.Sin(phase * 2f) * 3f);
        }
        if (tail != null) tail.localRotation = Quaternion.Euler(Mathf.Sin(Time.time * 14f) * 22f, 0f, 45f);
        if (jaw != null) jaw.localRotation = Quaternion.Euler(0f, 0f, -(mode == 2f ? 28f : 6f + Mathf.Sin(phase * 2f) * 4f));
    }
}
