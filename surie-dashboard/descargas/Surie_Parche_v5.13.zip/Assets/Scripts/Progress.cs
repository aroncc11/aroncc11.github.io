using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Collections.Generic;

/// <summary>Progreso del jugador entre niveles (mapa del mundo, minijuegos, mejores puntajes). Se guarda en PlayerPrefs.</summary>
public static class Progress
{
    public class Lv
    {
        public string scene, name, room, mini, miniName, blurb;
        public Lv(string scene, string name, string room, string mini, string miniName, string blurb)
        { this.scene = scene; this.name = name; this.room = room; this.mini = mini; this.miniName = miniName; this.blurb = blurb; }
    }

    public const string WorldScene = "Mundo_Surie";
    public const string MiniScene = "Mini_Surie";

    public static readonly Lv[] Levels =
    {
        new Lv("Nivel_Surie",     "1 · La sala",           "Sala",     "alacena",    "La alacena de croquetas", "Aprende a saltar, trepar y usar el dash."),
        new Lv("Nivel_2_Cocina",  "2 · La cocina",         "Cocina",   "pescado",    "Atrapa el pescado",       "Charcos, estantes y la Roomba."),
        new Lv("Nivel_3_Bano",    "3 · Baño y pasillo",    "Baño",     "luz",        "Persigue la luz",         "Fosos largos y plataformas que se mueven."),
        new Lv("Nivel_4_Patio",   "4 · El patio",          "Patio",    "mariposas",  "Caza de mariposas",       "Torres, saltos largos y mucha Roomba."),
        new Lv("Nivel_5_Sotano",  "5 · El sótano",         "Sótano",   "huellas",    "Memoria de huellas",      "Todo lo anterior, sin descanso."),
        new Lv("Nivel_6_Benito",  "6 · El cuarto de Benito","Cuarto",  "",           "",                        "El gran final: recupera tu juguete.")
    };

    // nivel que se está jugando o al que se va a entrar
    public static int Current;
    // true = al entrar a la sala, ir directo a la alacena (repetir el minijuego del nivel 1 desde el mapa)
    public static bool DirectMini;

    // ---- v5: cada vez que se abre el juego es un usuario NUEVO (progreso en cero). Los puntajes quedan en el marcador.
    public static string RunId = "";

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void FreshStart()
    {
        ResetAll();
        foreach (var k in new[] { "surie_sello", "surie_vida_extra", "surie_mini0", "surie_comic_visto", "surie_mundo_visto", "surie_nombre" }) PlayerPrefs.DeleteKey(k);
        RunId = DateTime.Now.Ticks.ToString();
        PlayerPrefs.Save();
    }

    static string K(string a, int i) { return "surie_" + a + i; }

    public static bool Done(int i) { return PlayerPrefs.GetInt(K("done", i), 0) == 1; }
    public static bool Unlocked(int i) { return i == 0 || Done(i - 1); }
    public static bool HasMini(int i) { return i >= 0 && i < Levels.Length && Levels[i].mini != ""; }
    /// <summary>El minijuego se gana con las 5 letras S-U-R-I-E y el juguete del nivel.</summary>
    public static bool MiniUnlocked(int i) { return HasMini(i) && PlayerPrefs.GetInt(K("mini", i), 0) == 1; }
    public static int Letters(int i) { return PlayerPrefs.GetInt(K("letters", i), 0); }
    public static int Best(int i) { return PlayerPrefs.GetInt(K("best", i), 0); }
    public static float BestTime(int i) { return PlayerPrefs.GetFloat(K("time", i), 0f); }

    public static int DoneCount() { int n = 0; for (int i = 0; i < Levels.Length; i++) if (Done(i)) n++; return n; }
    public static bool AllDone() { return DoneCount() == Levels.Length; }
    public static int TotalLetters() { int n = 0; for (int i = 0; i < Levels.Length; i++) n += Letters(i); return n; }

    /// <summary>Marca el nivel como superado. Con 5 letras se gana el minijuego del nivel.</summary>
    public static void Complete(int i, int letters, float seconds)
    {
        PlayerPrefs.SetInt(K("done", i), 1);
        if (letters > Letters(i)) PlayerPrefs.SetInt(K("letters", i), letters);
        if (letters >= 5 && HasMini(i)) PlayerPrefs.SetInt(K("mini", i), 1);
        float bt = BestTime(i);
        if (bt <= 0f || seconds < bt) PlayerPrefs.SetFloat(K("time", i), seconds);
        PlayerPrefs.Save();
        UpdateBoard();
    }

    public static void SaveBest(int i, int score)
    {
        if (score > Best(i)) PlayerPrefs.SetInt(K("best", i), score);
        PlayerPrefs.Save();
        UpdateBoard();
    }

    // ---------------- marcador de puntajes (se conserva entre partidas)
    public class Entry { public string id, name, detail; public int total, done; }

    /// <summary>Puntaje de la partida actual: minijuegos + 500 por nivel + 100 por letra.</summary>
    public static int RunTotal()
    {
        int n = 0;
        for (int i = 0; i < Levels.Length; i++) n += Best(i) + (Done(i) ? 500 : 0) + 100 * Letters(i);
        return n;
    }

    public static string RunDetail()
    {
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < Levels.Length; i++)
        {
            if (!Done(i) && Best(i) == 0) continue;
            sb.Append("N" + (i + 1) + (Done(i) ? " " + Mathf.RoundToInt(BestTime(i)) + "s " + Letters(i) + "/5" : ""));
            if (HasMini(i) && Best(i) > 0) sb.Append(" mini " + Best(i));
            sb.Append("  ");
        }
        return sb.ToString().Trim();
    }

    public static List<Entry> Board()
    {
        var list = new List<Entry>();
        foreach (var line in PlayerPrefs.GetString("surie_board", "").Split('\n'))
        {
            var f = line.Split('|');
            if (f.Length < 5) continue;
            int t, d; int.TryParse(f[2], out t); int.TryParse(f[3], out d);
            list.Add(new Entry { id = f[0], name = f[1], total = t, done = d, detail = f[4] });
        }
        return list;
    }

    public static void UpdateBoard()
    {
        if (RunId == "") RunId = DateTime.Now.Ticks.ToString();
        var list = Board();
        list.RemoveAll(e => e.id == RunId);
        list.Add(new Entry { id = RunId, name = PlayerName.Current.Replace("|", " "), total = RunTotal(), done = DoneCount(), detail = RunDetail().Replace("|", " ") });
        list.Sort((a, b) => b.total.CompareTo(a.total));
        if (list.Count > 15) list.RemoveRange(15, list.Count - 15);
        var sb = new System.Text.StringBuilder();
        foreach (var e in list) sb.Append(e.id + "|" + e.name + "|" + e.total + "|" + e.done + "|" + e.detail + "\n");
        PlayerPrefs.SetString("surie_board", sb.ToString());
        PlayerPrefs.Save();
    }

    public static void ResetAll()
    {
        for (int i = 0; i < Levels.Length; i++)
        {
            PlayerPrefs.DeleteKey(K("done", i)); PlayerPrefs.DeleteKey(K("mini", i));
            PlayerPrefs.DeleteKey(K("letters", i)); PlayerPrefs.DeleteKey(K("best", i)); PlayerPrefs.DeleteKey(K("time", i));
        }
        PlayerPrefs.Save();
    }

    public static bool SceneExists(string name) { return Application.CanStreamedLevelBeLoaded(name); }

    public static void GoWorld()
    {
        Time.timeScale = 1f;
        Analytics.EndAndReset();
        SceneManager.LoadScene(SceneExists(WorldScene) ? WorldScene : Levels[0].scene);
    }

    public static void GoLevel(int i)
    {
        Current = i;
        DirectMini = false;
        Time.timeScale = 1f;
        Analytics.EndAndReset();
        SceneManager.LoadScene(Levels[i].scene);
    }

    public static void GoMini(int i)
    {
        Current = i;
        Time.timeScale = 1f;
        Analytics.EndAndReset();
        if (i == 0) { DirectMini = true; SceneManager.LoadScene(Levels[0].scene); }
        else SceneManager.LoadScene(MiniScene);
    }
}
