using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>Entrada de teclado que funciona con el Input Manager viejo o con el nuevo Input System.</summary>
public static class Inp
{
    /// <summary>true = el jugador no puede moverse (escenas cinemáticas).</summary>
    public static bool Locked;

    public static float Horizontal()
    {
        if (Locked) return 0f;
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        if (k == null) return 0f;
        float h = 0f;
        if (k.aKey.isPressed || k.leftArrowKey.isPressed) h -= 1f;
        if (k.dKey.isPressed || k.rightArrowKey.isPressed) h += 1f;
        return h;
#else
        return Input.GetAxisRaw("Horizontal");
#endif
    }

    public static float Vertical()
    {
        if (Locked) return 0f;
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        if (k == null) return 0f;
        float v = 0f;
        if (k.wKey.isPressed || k.upArrowKey.isPressed) v += 1f;
        if (k.sKey.isPressed || k.downArrowKey.isPressed) v -= 1f;
        return v;
#else
        return Input.GetAxisRaw("Vertical");
#endif
    }

    public static bool JumpDown()
    {
        if (Locked) return false;
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && k.spaceKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.Space);
#endif
    }

    public static bool JumpHeld()
    {
        if (Locked) return false;
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && k.spaceKey.isPressed;
#else
        return Input.GetKey(KeyCode.Space);
#endif
    }

    /// <summary>Atajo de prueba (solo en el editor de Unity): F9 salta directo al nivel bonus.</summary>
    public static bool BonusCheatDown()
    {
#if UNITY_EDITOR
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && k.f9Key.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.F9);
#endif
#else
        return false;
#endif
    }

    public static bool RestartDown()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && k.rKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.R);
#endif
    }

    public static bool PauseDown()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && (k.escapeKey.wasPressedThisFrame || k.pKey.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P);
#endif
    }

    public static bool DashDown()
    {
        if (Locked) return false;
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && (k.leftShiftKey.wasPressedThisFrame || k.rightShiftKey.wasPressedThisFrame || k.kKey.wasPressedThisFrame || k.xKey.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift) || Input.GetKeyDown(KeyCode.K) || Input.GetKeyDown(KeyCode.X);
#endif
    }

    /// <summary>Enter o Espacio (confirmar en menús y en el mapa).</summary>
    public static bool ConfirmDown()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && (k.enterKey.wasPressedThisFrame || k.spaceKey.wasPressedThisFrame || k.numpadEnterKey.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.KeypadEnter);
#endif
    }

    /// <summary>Tecla M (minijuego desde el mapa).</summary>
    public static bool MiniDown()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        return k != null && k.mKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.M);
#endif
    }

    /// <summary>Teclas numéricas 1-9 (fila superior).</summary>
    public static bool NumberDown(int n)
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        if (k == null) return false;
        switch (n)
        {
            case 1: return k.digit1Key.wasPressedThisFrame; case 2: return k.digit2Key.wasPressedThisFrame;
            case 3: return k.digit3Key.wasPressedThisFrame; case 4: return k.digit4Key.wasPressedThisFrame;
            case 5: return k.digit5Key.wasPressedThisFrame; default: return false;
        }
#else
        return Input.GetKeyDown((KeyCode)((int)KeyCode.Alpha0 + n));
#endif
    }
}
