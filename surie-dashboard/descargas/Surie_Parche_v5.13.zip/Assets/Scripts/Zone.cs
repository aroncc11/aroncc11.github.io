using UnityEngine;

public enum ZoneType { Water, Fall, Rest, Noise, Checkpoint, Climb }

/// <summary>Zonas invisibles (triggers): agua, caída, descanso, ruido de TV, puntos de control y cortina trepable.</summary>
public class Zone : MonoBehaviour
{
    public ZoneType type;
    float timer;

    PlayerController2D P(Collider o) { return o.GetComponentInParent<PlayerController2D>(); }

    void OnTriggerEnter(Collider o)
    {
        var p = P(o);
        if (p == null) return;
        var gm = GameManager.I;
        switch (type)
        {
            case ZoneType.Water:
                Analytics.Event("water");
                gm.AddStress(1, "¡Agua! +1 estrés");
                gm.RespawnPlayer();
                break;
            case ZoneType.Fall:
                Analytics.Event("fall");
                gm.AddStress(1, "¡Te caíste! +1 estrés");
                gm.RespawnPlayer();
                break;
            case ZoneType.Checkpoint:
                if (gm.respawnPoint != transform.position) Analytics.Event("checkpoint", name);
                gm.respawnPoint = transform.position;
                break;
            case ZoneType.Climb:
                p.climbZones++;
                var zc = GetComponent<Collider>();
                if (zc != null) { p.climbCenterX = zc.bounds.center.x; p.climbTopY = zc.bounds.max.y; }
                break;
        }
    }

    void OnTriggerExit(Collider o)
    {
        var p = P(o);
        if (p == null) return;
        if (type == ZoneType.Climb) p.climbZones = Mathf.Max(0, p.climbZones - 1);
        timer = 0f;
    }

    void OnTriggerStay(Collider o)
    {
        var p = P(o);
        if (p == null) return;
        var gm = GameManager.I;
        if (type == ZoneType.Rest)
        {
            if (p.Grounded && Mathf.Abs(p.HorizontalSpeed) < 0.2f) timer += Time.deltaTime; else timer = 0f;
            if (timer >= 2f) { gm.Relax(); timer = 0f; }
        }
        else if (type == ZoneType.Noise)
        {
            if (gm.TvOn) timer += Time.deltaTime; else timer = 0f;
            if (timer >= gm.TurnSeconds) { Analytics.Event("tv_noise");
 gm.AddStress(1, "¡Ruido de la TV! +1 estrés"); timer = 0f; }
        }
    }
}
