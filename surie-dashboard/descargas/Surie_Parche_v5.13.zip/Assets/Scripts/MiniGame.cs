using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Minijuegos 3D (v5) que se ganan al terminar un nivel con las 5 letras S-U-R-I-E y el juguete.
/// Escena "Mini_Surie": un solo script arma el escenario 3D con primitivas y controla a Surie 3D en los 4 minijuegos:
///   pescado   → Surie en un muelle salta para atrapar los peces que brincan del mar (cuidado con los pez globo).
///   luz       → una luz FIJA aparece ~2 s sobre plataformas de madera flotantes (con cortinas); Surie debe llegar a tiempo.
///   mariposas → Surie corre y salta por el jardín cazando mariposas; con Shift da un zarpazo de red (las abejas pican).
///   huellas   → Surie en el sillón juega con un control; repite la secuencia y cada acierto deja una huellita.
/// </summary>
public class MiniGame : MonoBehaviour
{
    public Transform surie, surieModel;
    public Camera cam;
    public Material baseMat;

    enum St { Intro, Play, End }
    St st = St.Intro;
    int level;
    string kind = "";
    float timeLeft, total, score, introAt;
    int best;
    bool rewarded;
    float k, ox;
    const float W = 1280f, H = 720f;
    GUIStyle sTitle, sBig, sMid, sSmall;

    // metas (puntos para ganar la vida extra). Ajústalas aquí si quieres más/menos dificultad.
    const float TargetFish = 1800f, TargetLight = 2000f, TargetButter = 2400f, TargetPaws = 600f;

    // ---- Surie 3D
    float sx, sy, svy, surieZ, facing = 1f, prevSy, stun, swipeT, swipeCd;
    bool grounded;
    int airJumps;
    bool doubleJump = true;
    float gnd = 0f, xMin = -7.4f, xMax = 7.4f;
    const float G = 34f, JV = 13.5f, RunSpeed = 7.2f;
    readonly List<Vector3> plats = new List<Vector3>();   // x0, x1, top
    Transform env;
    readonly Dictionary<int, Material> matCache = new Dictionary<int, Material>();

    // ---- objetos del juego
    class Item { public Transform t; public float x, y, vx, vy, t0, base0; public int kind; public bool dead; }
    readonly List<Item> items = new List<Item>();
    float spawnT;
    float msgT; string msg = "";
    class Pop { public string s; public float wx, wy, t; public Color c; }
    readonly List<Pop> pops = new List<Pop>();
    int combo; float comboT; int bestCombo;
    int Mult() { return 1 + Mathf.Min(3, combo / 5); }

    void Gain(int pts, float wx, float wy)
    {
        if (pts < 0)
        {
            combo = 0; score = Mathf.Max(0f, score + pts);
            pops.Add(new Pop { s = pts.ToString(), wx = wx, wy = wy, t = 0f, c = new Color(1f, 0.45f, 0.4f) });
            AudioManager.Sfx("estres");
            return;
        }
        combo++; comboT = 2.0f; bestCombo = Mathf.Max(bestCombo, combo);
        int m = Mult();
        score += pts * m;
        pops.Add(new Pop { s = "+" + (pts * m) + (m > 1 ? "  x" + m : ""), wx = wx, wy = wy, t = 0f, c = pts >= 150 ? new Color(1f, 0.9f, 0.3f) : new Color(0.8f, 1f, 0.8f) });
        AudioManager.Sfx(pts >= 150 ? "letra" : "croqueta");
    }

    // ---- luz
    Transform dotRoot, dotRing, dotCore;
    Vector3 dotPos; float dotLife, dotWait; int dotSpot = -1; bool dotOn;
    readonly List<Vector3> spots = new List<Vector3>();
    const float DotTime = 2.4f;

    // ---- mariposas
    Transform swipeRing;

    // ---- huellas
    readonly List<int> seq = new List<int>();
    int showIdx, inputIdx; float showT; bool showing; int rounds; int lives = 3; float padLit; int litPad = -1;
    float prevH, prevV;
    Transform[] padT = new Transform[4];
    Color[] padCol = new Color[4];
    Transform[] ctrlBtn = new Transform[4];
    readonly List<Transform> slots = new List<Transform>();
    readonly List<Transform> prints = new List<Transform>();
    readonly List<float> printT = new List<float>();
    Transform pawL, pawR; float pawKick; int pawSide;
    Vector3 tvCenter = new Vector3(3.0f, 3.9f, 3.4f);

    void Start()
    {
        Time.timeScale = 1f;
        Inp.Locked = false;
        level = Mathf.Clamp(Progress.Current, 1, Progress.Levels.Length - 1);
        kind = Progress.Levels[level].mini;
        best = Progress.Best(level);
        total = kind == "huellas" ? 0f : (kind == "luz" ? 45f : 60f);
        timeLeft = total;
        Analytics.Level = level;
        Analytics.Ensure();
        AudioManager.PlayMusic("musica_minijuego");
        AudioManager.Duck(false);
        introAt = Time.time;
        Analytics.Event("mini_entrada", kind);
        BuildEnv();
    }

    string Target() { return Mathf.RoundToInt(TargetN()).ToString(); }
    float TargetN() { return kind == "pescado" ? TargetFish : kind == "luz" ? TargetLight : kind == "mariposas" ? TargetButter : TargetPaws; }

    string HowTo()
    {
        switch (kind)
        {
            case "pescado": return "Surie pesca en el muelle. A / D = correr, ESPACIO = saltar (dos veces en el aire). Toca los peces que brincan: +60, el dorado +200. ¡Evita el pez globo (-150)!";
            case "luz": return "Una luz aparece FIJA unos 2 segundos sobre las plataformas flotantes. Llega a ella antes de que se cierre el círculo. A / D = correr, ESPACIO = saltar (doble salto). ¡Encadena aciertos para el combo!";
            case "mariposas": return "Corre (A / D) y salta (ESPACIO, doble salto) por el jardín. Las mariposas que toques se atrapan (+40, doradas +150). SHIFT = zarpazo con red de alcance mayor. ¡Las abejas pican (-100)!";
            default: return "Surie juega con su control. Mira la secuencia de huellas en la tele y repítela con las flechas (o W A S D). Cada acierto deja una huellita. Cada ronda añade una más. Tienes 3 vidas.";
        }
    }

    // =====================================================================================
    // ESCENARIO 3D (primitivas en tiempo de ejecución)
    // =====================================================================================
    Material MatOf(Color c)
    {
        int key = ((int)(c.r * 255) << 16) | ((int)(c.g * 255) << 8) | (int)(c.b * 255);
        Material m;
        if (matCache.TryGetValue(key, out m)) return m;
        m = baseMat != null ? new Material(baseMat) : new Material(Shader.Find("Standard"));
        m.color = c;
        matCache[key] = m;
        return m;
    }

    static Color Hex(string h) { Color c; ColorUtility.TryParseHtmlString(h, out c); return c; }

    Transform P(PrimitiveType pt, string n, Transform par, float x, float y, float z, float sx_, float sy_, float sz_, string hex, float rz = 0f)
    {
        var g = GameObject.CreatePrimitive(pt);
        var col = g.GetComponent<Collider>(); if (col != null) Destroy(col);
        g.name = n;
        g.transform.SetParent(par, false);
        g.transform.localPosition = new Vector3(x, y, z);
        g.transform.localRotation = Quaternion.Euler(0f, 0f, rz);
        g.transform.localScale = new Vector3(sx_, sy_, sz_);
        g.GetComponent<Renderer>().sharedMaterial = MatOf(Hex(hex));
        return g.transform;
    }

    void SetCam(float x, float y, float z, float rx, string bg)
    {
        if (cam == null) return;
        cam.transform.position = new Vector3(x, y, z);
        cam.transform.rotation = Quaternion.Euler(rx, 0f, 0f);
        cam.backgroundColor = Hex(bg);
    }

    void ClearEnv()
    {
        if (env != null) Destroy(env.gameObject);
        env = new GameObject("Escenario").transform;
        items.Clear(); plats.Clear(); spots.Clear(); slots.Clear(); prints.Clear(); printT.Clear();
        dotRoot = null; swipeRing = null;
    }

    void BuildEnv()
    {
        ClearEnv();
        sx = 0f; sy = 0f; svy = 0f; grounded = true; stun = 0f; facing = 1f; swipeT = 0f; swipeCd = 0f;
        var ca = surieModel != null ? surieModel.GetComponent<CatAnimator>() : null;
        if (ca != null) ca.enabled = kind != "huellas";
        if (surieModel != null) surieModel.localScale = Vector3.one * 1.25f;
        switch (kind)
        {
            case "pescado": BuildFish(); break;
            case "luz": BuildLight(); break;
            case "mariposas": BuildButter(); break;
            default: BuildPaws(); break;
        }
        PlaceSurie();
    }

    // ---------------- pescado
    void BuildFish()
    {
        surieZ = -1.6f; xMin = -7.2f; xMax = 7.2f; doubleJump = true;
        SetCam(0f, 3.3f, -12.5f, 8f, "#9FD8F5");
        P(PrimitiveType.Cube, "Mar", env, 0f, -2.6f, 9f, 70f, 4.6f, 40f, "#3E9BD6");
        for (int i = 0; i < 14; i++) P(PrimitiveType.Sphere, "Espuma", env, -9f + i * 1.4f + (i % 3) * 0.3f, -0.28f, 0.5f + (i % 4) * 2.5f, 1.2f, 0.06f, 0.5f, "#DFF3FB");
        for (int i = -9; i <= 9; i++) P(PrimitiveType.Cube, "Tabla", env, i * 1.0f, -0.15f, -1.6f, 0.96f, 0.3f, 3.0f, i % 2 == 0 ? "#B07D48" : "#9A6B3C");
        for (int i = 0; i < 5; i++)
        {
            P(PrimitiveType.Cylinder, "Pilote", env, -8f + i * 4f, -1.6f, -2.8f, 0.5f, 1.6f, 0.5f, "#5E3A20");
            P(PrimitiveType.Cylinder, "PiloteFondo", env, -8f + i * 4f, -1.6f, -0.4f, 0.5f, 1.6f, 0.5f, "#5E3A20");
        }
        P(PrimitiveType.Cylinder, "Cubeta", env, -8.2f, 0.4f, -2.2f, 0.9f, 0.4f, 0.9f, "#4F9AE0");
        P(PrimitiveType.Cube, "Caja", env, 8.3f, 0.45f, -2.2f, 1.1f, 0.9f, 1.1f, "#C8935A");
        P(PrimitiveType.Cylinder, "Poste", env, 8.6f, 1.4f, -0.5f, 0.2f, 1.4f, 0.2f, "#7A4E2D");
        P(PrimitiveType.Sphere, "Farol", env, 8.6f, 2.9f, -0.5f, 0.4f, 0.5f, 0.4f, "#FFE680");
        P(PrimitiveType.Sphere, "Sol", env, -11f, 9f, 28f, 5f, 5f, 0.5f, "#FFE066");
        for (int i = 0; i < 6; i++)
        {
            float cx = -16f + i * 7f, cy = 8f + (i % 3) * 1.5f;
            P(PrimitiveType.Sphere, "Nube", env, cx, cy, 24f, 4f, 1.4f, 1f, "#FFFFFF");
            P(PrimitiveType.Sphere, "Nube", env, cx + 1.4f, cy - 0.2f, 24f, 2.6f, 1.1f, 1f, "#F4F8FB");
        }
        P(PrimitiveType.Cube, "Isla", env, 14f, 1.2f, 18f, 8f, 4f, 3f, "#7FB06A");
    }

    Transform MakeFish(int kind_)
    {
        var r = new GameObject(kind_ == 2 ? "PezGlobo" : "Pez").transform;
        r.SetParent(env, false);
        if (kind_ == 2)
        {
            P(PrimitiveType.Sphere, "Cuerpo", r, 0, 0, 0, 0.95f, 0.95f, 0.8f, "#C9D36B");
            P(PrimitiveType.Sphere, "Panza", r, 0, -0.18f, -0.1f, 0.7f, 0.5f, 0.6f, "#F2F2C8");
            for (int i = 0; i < 10; i++)
            {
                float a = i * 36f * Mathf.Deg2Rad;
                var s = P(PrimitiveType.Cube, "Espina", r, Mathf.Cos(a) * 0.5f, Mathf.Sin(a) * 0.5f, 0, 0.1f, 0.22f, 0.1f, "#7A8A2E", i * 36f - 90f);
            }
            P(PrimitiveType.Sphere, "Ojo", r, 0.28f, 0.12f, -0.36f, 0.2f, 0.2f, 0.1f, "#FFFFFF");
            P(PrimitiveType.Sphere, "Pupila", r, 0.32f, 0.12f, -0.4f, 0.1f, 0.1f, 0.06f, "#161616");
            P(PrimitiveType.Cube, "Ceja", r, 0.28f, 0.3f, -0.37f, 0.3f, 0.05f, 0.05f, "#3A3A10", -20f);
            P(PrimitiveType.Cube, "Cola", r, -0.55f, 0, 0, 0.3f, 0.35f, 0.1f, "#B8C25A", 45f);
        }
        else
        {
            string c = kind_ == 1 ? "#FFD84A" : "#F2874D", c2 = kind_ == 1 ? "#FFF0A0" : "#FFC59E";
            P(PrimitiveType.Sphere, "Cuerpo", r, 0, 0, 0, 1.0f, 0.5f, 0.38f, c);
            P(PrimitiveType.Sphere, "Panza", r, 0.02f, -0.1f, -0.04f, 0.8f, 0.24f, 0.32f, c2);
            P(PrimitiveType.Cube, "Cola", r, -0.62f, 0, 0, 0.36f, 0.42f, 0.08f, c, 45f);
            P(PrimitiveType.Cube, "AletaS", r, -0.05f, 0.3f, 0, 0.32f, 0.2f, 0.06f, c, 30f);
            P(PrimitiveType.Sphere, "Ojo", r, 0.32f, 0.08f, -0.18f, 0.14f, 0.14f, 0.08f, "#FFFFFF");
            P(PrimitiveType.Sphere, "Pupila", r, 0.35f, 0.08f, -0.22f, 0.07f, 0.07f, 0.05f, "#161616");
            if (kind_ == 1) P(PrimitiveType.Sphere, "Brillo", r, 0, 0.35f, -0.2f, 0.18f, 0.18f, 0.06f, "#FFFFFF");
        }
        return r;
    }

    // ---------------- luz
    void BuildLight()
    {
        surieZ = 0f; xMin = -7.4f; xMax = 7.4f; doubleJump = true;
        SetCam(0f, 3.7f, -12.5f, 6f, "#1C1238");
        P(PrimitiveType.Cube, "Piso", env, 0f, -0.2f, 0f, 24f, 0.4f, 8f, "#4A3A6E");
        P(PrimitiveType.Cube, "Pared", env, 0f, 5f, 4f, 26f, 14f, 0.4f, "#3A2E5C");
        P(PrimitiveType.Cube, "Zocalo", env, 0f, 0.3f, 3.7f, 26f, 0.6f, 0.2f, "#2C2248");
        string[][] pal = { new[] { "#E39AB0", "#C97B97" }, new[] { "#9C86C9", "#8068B3" }, new[] { "#79B4DA", "#5E9CC6" }, new[] { "#E8B86B", "#CF9F52" } };
        for (int c = 0; c < 4; c++)
        {
            float cx = -6.6f + c * 4.4f;
            P(PrimitiveType.Cube, "Ventana", env, cx, 4.6f, 3.7f, 2.6f, 3.4f, 0.1f, "#2F3F78");
            P(PrimitiveType.Sphere, "Luna", env, cx + 0.3f, 5.3f, 3.6f, 0.7f, 0.7f, 0.1f, "#FFF3C0");
            P(PrimitiveType.Cylinder, "Barra", env, cx, 7.0f, 2.7f, 0.1f, 1.7f, 0.1f, "#D9C27A", 90f);
            for (int s = 0; s < 8; s++)
                P(PrimitiveType.Cube, "Tela", env, cx - 1.3f + s * 0.37f, 4.0f, 2.7f + ((s % 2 == 0) ? 0.0f : 0.12f), 0.36f, 6.0f, 0.16f, pal[c][s % 2]);
            P(PrimitiveType.Sphere, "Nudo", env, cx, 2.2f, 2.55f, 0.35f, 0.35f, 0.35f, "#F4E3A8");
        }
        float[][] pl = { new[] { -5.6f, 2.3f, 2.8f }, new[] { -1.8f, 3.6f, 2.8f }, new[] { 2.4f, 2.4f, 2.8f }, new[] { 5.9f, 3.9f, 2.6f }, new[] { 0.3f, 5.5f, 3.0f } };
        for (int i = 0; i < pl.Length; i++)
        {
            float cx = pl[i][0], top = pl[i][1], w = pl[i][2];
            P(PrimitiveType.Cube, "Tabla", env, cx, top - 0.2f, 0f, w, 0.4f, 1.6f, "#A0714F");
            P(PrimitiveType.Cube, "Canto", env, cx, top - 0.38f, -0.78f, w + 0.04f, 0.1f, 0.06f, "#7A4E2D");
            P(PrimitiveType.Cube, "Veta", env, cx, top + 0.005f, -0.3f, w * 0.8f, 0.02f, 0.05f, "#8C5F3E");
            P(PrimitiveType.Sphere, "Brillito", env, cx, top - 0.6f, 0f, w * 0.7f, 0.14f, 0.7f, "#8E7AD6");
            plats.Add(new Vector3(cx - w * 0.5f, cx + w * 0.5f, top));
            spots.Add(new Vector3(cx, top, 0f));
        }
        for (int x = -6; x <= 6; x += 3) spots.Add(new Vector3(x, 0f, 0f));
        P(PrimitiveType.Cube, "Alfombra", env, 0f, 0.01f, -1.2f, 10f, 0.04f, 2.2f, "#7B5AA8");
    }

    void SpawnDot()
    {
        int n = spots.Count;
        int pick = Random.Range(0, n);
        if (n > 1 && pick == dotSpot) pick = (pick + 1 + Random.Range(0, n - 1)) % n;
        dotSpot = pick;
        dotPos = spots[pick] + new Vector3(0f, 0.75f, 0f);
        dotLife = DotTime; dotOn = true;
        if (dotRoot == null)
        {
            dotRoot = new GameObject("Luz").transform; dotRoot.SetParent(env, false);
            dotCore = P(PrimitiveType.Sphere, "Nucleo", dotRoot, 0, 0, 0, 0.5f, 0.5f, 0.5f, "#FF3B3B");
            P(PrimitiveType.Sphere, "Halo", dotRoot, 0, 0, 0, 0.9f, 0.9f, 0.9f, "#FF9A9A");
            dotRing = P(PrimitiveType.Cylinder, "Anillo", dotRoot, 0, 0, -0.1f, 2.8f, 0.02f, 2.8f, "#FFE066");
            dotRing.localRotation = Quaternion.Euler(90f, 0f, 0f);
        }
        dotRoot.gameObject.SetActive(true);
        dotRoot.position = dotPos;
        AudioManager.Sfx("salto");
    }

    // ---------------- mariposas
    void BuildButter()
    {
        surieZ = -0.5f; xMin = -7.4f; xMax = 7.4f; doubleJump = true;
        SetCam(0f, 3.2f, -12.5f, 7f, "#9ADBF6");
        P(PrimitiveType.Cube, "Pasto", env, 0f, -0.2f, 3f, 34f, 0.4f, 14f, "#6DBE5A");
        P(PrimitiveType.Cube, "Camino", env, 0f, 0.0f, -0.6f, 26f, 0.02f, 1.6f, "#78C464");
        for (int i = 0; i < 26; i++)
        {
            float x = -9.5f + i * 0.76f;
            float hh = 1.7f + (i % 2) * 0.12f;
            P(PrimitiveType.Cube, "Tabla", env, x, hh * 0.5f, 5.2f, 0.58f, hh, 0.1f, "#F2E4C4");
            P(PrimitiveType.Cube, "Punta", env, x, hh + 0.04f, 5.2f, 0.4f, 0.1f, 0.1f, "#F2E4C4", 45f);
        }
        P(PrimitiveType.Cube, "Riel", env, 0f, 0.7f, 5.1f, 22f, 0.1f, 0.08f, "#C9A26B");
        P(PrimitiveType.Cube, "Riel", env, 0f, 1.3f, 5.1f, 22f, 0.1f, 0.08f, "#C9A26B");
        for (int t = 0; t < 5; t++)
        {
            float tx = -12f + t * 6f;
            P(PrimitiveType.Cylinder, "Tronco", env, tx, 2.2f, 8.5f, 0.9f, 2.2f, 0.9f, "#6B4423");
            P(PrimitiveType.Sphere, "Copa", env, tx, 5.6f, 8.5f, 4.4f, 3.4f, 4.4f, t % 2 == 0 ? "#3F8F4A" : "#4BA057");
        }
        for (int f = 0; f < 34; f++)
        {
            float fx = Random.Range(-9f, 9f), fz = Random.Range(0.6f, 3.4f), fh = Random.Range(0.4f, 1.1f);
            P(PrimitiveType.Cylinder, "Tallo", env, fx, fh * 0.5f, fz, 0.05f, fh * 0.5f, 0.05f, "#4BA057");
            string c = new[] { "#F25C7A", "#F7D154", "#FFFFFF", "#B07AD8", "#FF9F40" }[f % 5];
            P(PrimitiveType.Sphere, "Flor", env, fx, fh, fz - 0.05f, 0.38f, 0.38f, 0.14f, c);
            P(PrimitiveType.Sphere, "Centro", env, fx, fh, fz - 0.13f, 0.16f, 0.16f, 0.08f, "#F7C623");
        }
        for (int b = 0; b < 5; b++) P(PrimitiveType.Sphere, "Arbusto", env, -9f + b * 4.6f, 0.7f, 4.2f, 2.6f, 1.6f, 1.6f, b % 2 == 0 ? "#4BA057" : "#3F8F4A");
        P(PrimitiveType.Sphere, "Sol", env, 9f, 9f, 28f, 5f, 5f, 0.5f, "#FFE066");
        for (int i = 0; i < 6; i++)
        {
            float cx = -16f + i * 7f, cy = 8.5f + (i % 3) * 1.4f;
            P(PrimitiveType.Sphere, "Nube", env, cx, cy, 24f, 4f, 1.4f, 1f, "#FFFFFF");
        }
        swipeRing = P(PrimitiveType.Cylinder, "Zarpazo", env, 0f, 0f, -0.9f, 3.4f, 0.02f, 3.4f, "#FFFFFF");
        swipeRing.localRotation = Quaternion.Euler(90f, 0f, 0f);
        swipeRing.gameObject.SetActive(false);
    }

    Transform MakeButterfly(int kind_)
    {
        var r = new GameObject(kind_ == 2 ? "Abeja" : "Mariposa").transform;
        r.SetParent(env, false);
        if (kind_ == 2)
        {
            P(PrimitiveType.Sphere, "Cuerpo", r, 0, 0, 0, 0.5f, 0.38f, 0.38f, "#F7D23A");
            P(PrimitiveType.Cube, "Raya1", r, -0.05f, 0, -0.01f, 0.07f, 0.38f, 0.4f, "#1B1B1B");
            P(PrimitiveType.Cube, "Raya2", r, 0.1f, 0, -0.01f, 0.07f, 0.34f, 0.38f, "#1B1B1B");
            P(PrimitiveType.Sphere, "Cabeza", r, 0.3f, 0.04f, 0, 0.24f, 0.24f, 0.24f, "#2A2A2A");
            P(PrimitiveType.Sphere, "Ojo", r, 0.38f, 0.08f, -0.1f, 0.07f, 0.07f, 0.05f, "#FF3030");
            P(PrimitiveType.Sphere, "Ala1", r, -0.05f, 0.28f, 0.0f, 0.3f, 0.06f, 0.22f, "#DDF3FF");
            P(PrimitiveType.Cube, "Aguijon", r, -0.3f, -0.02f, 0, 0.14f, 0.05f, 0.05f, "#1B1B1B");
        }
        else
        {
            string c = kind_ == 1 ? "#FFD84A" : "#F29EC1", c2 = kind_ == 1 ? "#FFF0A0" : "#FFC9DE";
            P(PrimitiveType.Cylinder, "Cuerpo", r, 0, 0, 0, 0.09f, 0.28f, 0.09f, "#3A2A2A");
            P(PrimitiveType.Sphere, "Cabeza", r, 0, 0.3f, 0, 0.14f, 0.14f, 0.14f, "#3A2A2A");
            P(PrimitiveType.Cylinder, "Antena1", r, -0.06f, 0.46f, 0, 0.015f, 0.12f, 0.015f, "#3A2A2A", 15f);
            P(PrimitiveType.Cylinder, "Antena2", r, 0.06f, 0.46f, 0, 0.015f, 0.12f, 0.015f, "#3A2A2A", -15f);
            P(PrimitiveType.Sphere, "AlaSI", r, -0.26f, 0.12f, 0, 0.5f, 0.42f, 0.04f, c);
            P(PrimitiveType.Sphere, "AlaSD", r, 0.26f, 0.12f, 0, 0.5f, 0.42f, 0.04f, c);
            P(PrimitiveType.Sphere, "AlaII", r, -0.2f, -0.18f, 0, 0.34f, 0.3f, 0.04f, c2);
            P(PrimitiveType.Sphere, "AlaID", r, 0.2f, -0.18f, 0, 0.34f, 0.3f, 0.04f, c2);
        }
        return r;
    }

    // ---------------- huellas
    void BuildPaws()
    {
        surieZ = -0.6f; xMin = -7f; xMax = 7f; doubleJump = false;
        SetCam(-0.2f, 3.5f, -12.5f, 5f, "#2A2040");
        P(PrimitiveType.Cube, "Piso", env, 0f, -0.2f, 1f, 26f, 0.4f, 12f, "#9A6B3C");
        for (int i = -6; i <= 6; i++) P(PrimitiveType.Cube, "Duela", env, i * 2f, 0.003f, 1f, 0.04f, 0.01f, 12f, "#7A4E2D");
        P(PrimitiveType.Cube, "Pared", env, 0f, 5f, 5f, 28f, 14f, 0.4f, "#5B4A86");
        P(PrimitiveType.Cube, "Zocalo", env, 0f, 0.35f, 4.7f, 28f, 0.7f, 0.2f, "#3E2F63");
        P(PrimitiveType.Cylinder, "Tapete", env, 0f, 0.01f, -0.6f, 11f, 0.02f, 4.2f, "#D9728F");
        P(PrimitiveType.Cylinder, "TapeteB", env, 0f, 0.02f, -0.6f, 9f, 0.02f, 3.3f, "#E79AB0");
        // sillón
        P(PrimitiveType.Cube, "Asiento", env, -4.4f, 0.4f, -0.5f, 4.2f, 0.8f, 2.2f, "#8C5B7A");
        P(PrimitiveType.Cube, "Respaldo", env, -4.4f, 1.6f, 0.65f, 4.2f, 2.0f, 0.7f, "#7A4B69");
        P(PrimitiveType.Cube, "BrazoI", env, -6.35f, 0.95f, -0.5f, 0.5f, 1.4f, 2.2f, "#7A4B69");
        P(PrimitiveType.Cube, "BrazoD", env, -2.45f, 0.95f, -0.5f, 0.5f, 1.4f, 2.2f, "#7A4B69");
        P(PrimitiveType.Sphere, "Cojin", env, -5.4f, 1.1f, 0.2f, 0.9f, 0.9f, 0.4f, "#F2C46B");
        // tele
        float tx = tvCenter.x, ty = tvCenter.y, tz = tvCenter.z;
        P(PrimitiveType.Cube, "Mueble", env, tx, 0.55f, tz - 0.2f, 7.4f, 1.1f, 1.4f, "#5E3A20");
        P(PrimitiveType.Cube, "Tele", env, tx, ty, tz, 7.2f, 4.4f, 0.4f, "#1B1B22");
        P(PrimitiveType.Cube, "Pantalla", env, tx, ty, tz - 0.22f, 6.8f, 4.0f, 0.06f, "#16224A");
        P(PrimitiveType.Cube, "BrilloPantalla", env, tx - 2.2f, ty + 1.4f, tz - 0.26f, 1.6f, 0.06f, 0.02f, "#2A3A70", 25f);
        string[] pc = { "#F28BA0", "#7FB4F2", "#F7D154", "#7FDC92" };
        Vector3[] pp = { new Vector3(0f, 1.2f, 0f), new Vector3(0f, -1.2f, 0f), new Vector3(-1.9f, 0f, 0f), new Vector3(1.9f, 0f, 0f) };
        for (int i = 0; i < 4; i++)
        {
            padCol[i] = Hex(pc[i]);
            var pad = new GameObject("Pad" + i).transform; pad.SetParent(env, false);
            pad.position = new Vector3(tx + pp[i].x, ty + pp[i].y, tz - 0.3f);
            var rr = P(PrimitiveType.Cube, "Base", pad, 0, 0, 0, 1.6f, 0.95f, 0.1f, pc[i]);
            rr.GetComponent<Renderer>().sharedMaterial = MatOf(padCol[i] * 0.45f);
            MakePaw(pad, new Vector3(0f, 0f, -0.08f), 0.9f, "#FFFFFF");
            padT[i] = pad;
        }
        // control (mando) de Surie
        var ctrl = new GameObject("Control").transform; ctrl.SetParent(env, false);
        ctrl.position = new Vector3(-3.55f, 1.32f, -1.15f);
        ctrl.rotation = Quaternion.Euler(-25f, 0f, 0f);
        ctrl.localScale = Vector3.one * 0.42f;
        P(PrimitiveType.Cube, "Cuerpo", ctrl, 0, 0, 0, 1.5f, 0.22f, 0.8f, "#2E2E38");
        P(PrimitiveType.Sphere, "AgarreI", ctrl, -0.7f, -0.05f, -0.1f, 0.5f, 0.4f, 0.7f, "#2E2E38");
        P(PrimitiveType.Sphere, "AgarreD", ctrl, 0.7f, -0.05f, -0.1f, 0.5f, 0.4f, 0.7f, "#2E2E38");
        // cruceta (izquierda) y 4 botones (derecha); cada uno corresponde a una flecha
        Vector3[] cp = { new Vector3(-0.5f, 0.13f, 0.18f), new Vector3(-0.5f, 0.13f, -0.18f), new Vector3(-0.68f, 0.13f, 0f), new Vector3(-0.32f, 0.13f, 0f) };
        for (int i = 0; i < 4; i++)
        {
            ctrlBtn[i] = P(PrimitiveType.Cube, "Dir" + i, ctrl, cp[i].x, cp[i].y, cp[i].z, 0.16f, 0.07f, 0.16f, "#8A8A99");
        }
        Vector3[] bp = { new Vector3(0.5f, 0.13f, 0.18f), new Vector3(0.5f, 0.13f, -0.18f), new Vector3(0.32f, 0.13f, 0f), new Vector3(0.68f, 0.13f, 0f) };
        for (int i = 0; i < 4; i++) P(PrimitiveType.Sphere, "Boton" + i, ctrl, bp[i].x, bp[i].y, bp[i].z, 0.13f, 0.06f, 0.13f, pc[i]);
        // lámpara y planta
        P(PrimitiveType.Cylinder, "PostLampara", env, 7.3f, 1.8f, 2.8f, 0.12f, 1.8f, 0.12f, "#B8BEC4");
        P(PrimitiveType.Sphere, "Lampara", env, 7.3f, 3.9f, 2.8f, 0.9f, 0.7f, 0.9f, "#FFE9A8");
        P(PrimitiveType.Cylinder, "Maceta", env, -8f, 0.5f, 2.8f, 0.9f, 0.5f, 0.9f, "#C46A3C");
        P(PrimitiveType.Sphere, "Planta", env, -8f, 1.5f, 2.8f, 1.5f, 1.3f, 1.5f, "#4FA05F");
        // tira de huellitas bajo la tele
        for (int i = 0; i < 12; i++)
        {
            var sl = P(PrimitiveType.Cylinder, "Casilla", env, tx + (i - 5.5f) * 0.58f, 1.2f, tz - 0.75f, 0.42f, 0.015f, 0.42f, "#3A2A55");
            sl.localRotation = Quaternion.Euler(90f, 0f, 0f);
            sl.gameObject.SetActive(false);
            slots.Add(sl);
        }
        // Surie sentada en el sillón
        sx = -4.1f; sy = 0.8f; surieZ = -0.5f;
        if (surieModel != null) surieModel.localScale = Vector3.one * 1.1f;
        var ca = surieModel != null ? surieModel.GetComponent<CatAnimator>() : null;
        if (ca != null) { pawL = ca.frontP; pawR = ca.frontN; }
    }

    void MakePaw(Transform par, Vector3 lp, float sc, string hex)
    {
        var r = new GameObject("Huella").transform; r.SetParent(par, false); r.localPosition = lp; r.localScale = Vector3.one * sc;
        P(PrimitiveType.Sphere, "Palma", r, 0, -0.12f, 0, 0.42f, 0.34f, 0.08f, hex);
        for (int i = 0; i < 4; i++)
        {
            float a = (-0.62f + i * 0.41f);
            P(PrimitiveType.Sphere, "Dedo", r, Mathf.Sin(a) * 0.34f, 0.12f + Mathf.Cos(a) * 0.1f, 0, 0.16f, 0.2f, 0.08f, hex);
        }
    }

    Transform MakePrint(int slot, Color c)
    {
        var r = new GameObject("HuellaPuesta").transform; r.SetParent(env, false);
        r.position = slots[slot].position + new Vector3(0f, 0f, -0.05f);
        var pm = P(PrimitiveType.Sphere, "Palma", r, 0, -0.1f, 0, 0.3f, 0.24f, 0.06f, "#FFFFFF");
        pm.GetComponent<Renderer>().sharedMaterial = MatOf(c);
        for (int i = 0; i < 4; i++)
        {
            float a = (-0.62f + i * 0.41f);
            var d = P(PrimitiveType.Sphere, "Dedo", r, Mathf.Sin(a) * 0.25f, 0.1f + Mathf.Cos(a) * 0.07f, 0, 0.12f, 0.15f, 0.06f, "#FFFFFF");
            d.GetComponent<Renderer>().sharedMaterial = MatOf(c);
        }
        r.localScale = Vector3.zero;
        return r;
    }

    // =====================================================================================
    // SURIE 3D
    // =====================================================================================
    void PlaceSurie()
    {
        if (surie == null) return;
        surie.position = new Vector3(sx, sy, surieZ);
        if (surieModel != null)
        {
            float yaw = kind == "huellas" ? 115f : (facing > 0f ? 90f : -90f);
            surieModel.localRotation = Quaternion.Slerp(surieModel.localRotation, Quaternion.Euler(0f, yaw, 0f), 0.35f);
        }
    }

    void MoveSurie(float dt, float speed)
    {
        float h = Inp.Horizontal();
        if (stun > 0f) { stun -= dt; h = 0f; }
        if (Mathf.Abs(h) > 0.1f) facing = Mathf.Sign(h);
        sx = Mathf.Clamp(sx + h * speed * dt, xMin, xMax);
        if (Inp.JumpDown() && stun <= 0f)
        {
            if (grounded) { svy = JV; grounded = false; AudioManager.Sfx("salto"); }
            else if (airJumps > 0) { svy = JV * 0.92f; airJumps--; AudioManager.Sfx("salto"); }
        }
        prevSy = sy;
        svy -= G * dt;
        sy += svy * dt;
        grounded = false;
        if (sy <= gnd) { sy = gnd; svy = 0f; grounded = true; }
        for (int i = 0; i < plats.Count; i++)
        {
            var p = plats[i];
            if (svy <= 0f && prevSy >= p.z - 0.04f && sy <= p.z && sx > p.x - 0.3f && sx < p.y + 0.3f) { sy = p.z; svy = 0f; grounded = true; }
        }
        if (grounded) airJumps = doubleJump ? 1 : 0;
        PlaceSurie();
    }

    // =====================================================================================
    // FLUJO
    // =====================================================================================
    void Begin()
    {
        st = St.Play; score = 0; spawnT = 0.4f;
        timeLeft = total; rewarded = false; combo = 0; comboT = 0f; bestCombo = 0; pops.Clear();
        BuildEnv();
        dotWait = 0.6f; dotOn = false; dotSpot = -1;
        if (kind == "huellas") { seq.Clear(); rounds = 0; lives = 3; NewRound(); }
        Analytics.Event("mini_inicio", kind);
    }

    void NewRound()
    {
        seq.Add(Random.Range(0, 4));
        showing = true; showIdx = 0; showT = 0.9f; inputIdx = 0; litPad = -1;
        foreach (var p in prints) if (p != null) Destroy(p.gameObject);
        prints.Clear(); printT.Clear();
        for (int i = 0; i < slots.Count; i++) slots[i].gameObject.SetActive(i < seq.Count);
    }

    void End()
    {
        st = St.End;
        int sc = Mathf.RoundToInt(score);
        bool rec = sc > best;
        Progress.SaveBest(level, sc);
        if (sc >= TargetN()) { PlayerPrefs.SetInt("surie_vida_extra", 1); PlayerPrefs.Save(); rewarded = true; }
        Analytics.Event("mini_fin", kind + " puntos=" + sc + (rec ? " record" : "") + (rewarded ? " premio" : ""));
        AudioManager.Sfx(rewarded ? "victoria" : "checkpoint");
    }

    void Update()
    {
        if (Inp.PauseDown() && st != St.Play) { Progress.GoWorld(); return; }
        if (st == St.Intro)
        {
            if (Time.time - introAt > 0.4f && Inp.JumpDown()) Begin();
            return;
        }
        if (st == St.End) { PlaceSurie(); return; }
        float dt = Time.deltaTime;
        msgT -= dt;
        comboT -= dt; if (comboT <= 0f) combo = 0;
        foreach (var pp in pops) pp.t += dt;
        pops.RemoveAll(q => q.t > 0.9f);
        if (kind != "huellas")
        {
            timeLeft -= dt;
            if (timeLeft <= 0f) { timeLeft = 0f; End(); return; }
        }
        switch (kind)
        {
            case "pescado": UpdFish(dt); break;
            case "luz": UpdLight(dt); break;
            case "mariposas": UpdButter(dt); break;
            default: UpdPaws(dt); break;
        }
    }

    void Toast(string s) { msg = s; msgT = 0.9f; }

    // ---------------------------------------------------------------- pescado
    void UpdFish(float dt)
    {
        MoveSurie(dt, RunSpeed);
        float elapsed = total - timeLeft;
        bool frenzy = timeLeft < 12f;
        spawnT -= dt;
        if (spawnT <= 0f)
        {
            spawnT = Mathf.Max(0.35f, 1.0f - elapsed * 0.011f) * (frenzy ? 0.5f : 1f);
            float r = Random.value;
            int kd = r < 0.16f ? 2 : (r < 0.30f ? 1 : 0);
            var it = new Item { kind = kd, x = Random.Range(-6.5f, 6.5f), y = -0.7f, vx = Random.Range(-2.6f, 2.6f), vy = Random.Range(12f, 15.5f) };
            it.t = MakeFish(kd);
            items.Add(it);
        }
        foreach (var it in items)
        {
            it.vy -= 26f * dt;
            it.x += it.vx * dt; it.y += it.vy * dt;
            it.t.position = new Vector3(it.x, it.y, -0.3f);
            float ang = Mathf.Atan2(it.vy, it.vx) * Mathf.Rad2Deg;
            it.t.rotation = Quaternion.Euler(0f, 0f, it.kind == 2 ? it.t0 + 90f * Time.time : ang);
            if (!it.dead && Mathf.Abs(it.x - sx) < 1.1f && Mathf.Abs(it.y - (sy + 0.75f)) < 1.05f)
            {
                it.dead = true;
                if (it.kind == 2) { Gain(-150, it.x, it.y); stun = 0.6f; }
                else if (it.kind == 1) Gain(200, it.x, it.y);
                else Gain(60, it.x, it.y);
            }
            if (it.y < -1.4f && it.vy < 0f) it.dead = true;
        }
        for (int i = items.Count - 1; i >= 0; i--) if (items[i].dead) { Destroy(items[i].t.gameObject); items.RemoveAt(i); }
    }

    // ---------------------------------------------------------------- luz (fija ~2 s sobre plataformas)
    void UpdLight(float dt)
    {
        MoveSurie(dt, RunSpeed);
        if (!dotOn)
        {
            dotWait -= dt;
            if (dotRoot != null) dotRoot.gameObject.SetActive(false);
            if (dotWait <= 0f) SpawnDot();
            return;
        }
        dotLife -= dt;
        float f = Mathf.Clamp01(dotLife / DotTime);
        if (dotRing != null)
        {
            float r = Mathf.Lerp(0.7f, 2.8f, f);
            dotRing.localScale = new Vector3(r, 0.02f, r);
        }
        if (dotCore != null) dotCore.localScale = Vector3.one * (0.5f + 0.08f * Mathf.Sin(Time.time * 14f));
        if (Vector2.Distance(new Vector2(sx, sy + 0.7f), new Vector2(dotPos.x, dotPos.y)) < 1.05f)
        {
            int pts = 100 + Mathf.RoundToInt(dotLife * 50f);
            Gain(pts, dotPos.x, dotPos.y + 0.6f);
            dotOn = false; dotWait = 0.55f;
        }
        else if (dotLife <= 0f)
        {
            combo = 0;
            pops.Add(new Pop { s = "¡se escapó!", wx = dotPos.x, wy = dotPos.y + 0.6f, c = new Color(1f, 0.6f, 0.5f) });
            AudioManager.Sfx("estres");
            dotOn = false; dotWait = 0.55f;
        }
    }

    // ---------------------------------------------------------------- mariposas
    void UpdButter(float dt)
    {
        MoveSurie(dt, RunSpeed);
        float elapsed = total - timeLeft;
        bool frenzy = timeLeft < 12f;
        swipeCd -= dt; swipeT -= dt;
        if (Inp.DashDown() && swipeCd <= 0f && stun <= 0f)
        {
            swipeT = 0.28f; swipeCd = 0.5f;
            AudioManager.Sfx("salto");
        }
        if (swipeRing != null)
        {
            swipeRing.gameObject.SetActive(swipeT > 0f);
            swipeRing.position = new Vector3(sx, sy + 0.7f, surieZ - 0.4f);
            float s = Mathf.Lerp(1.2f, 3.6f, 1f - Mathf.Clamp01(swipeT / 0.28f));
            swipeRing.localScale = new Vector3(s, 0.02f, s);
        }
        if (surieModel != null) surieModel.localScale = Vector3.one * (swipeT > 0f ? 1.42f : 1.25f);
        spawnT -= dt;
        if (spawnT <= 0f)
        {
            spawnT = Mathf.Max(0.3f, 0.65f - elapsed * 0.006f) * (frenzy ? 0.55f : 1f);
            float r = Random.value;
            bool left = Random.value < 0.5f;
            int kd = r < 0.17f ? 2 : (r < 0.30f ? 1 : 0);
            float y0 = Random.Range(1.0f, 6.4f);
            var it = new Item { kind = kd, x = left ? -9.5f : 9.5f, y = y0, base0 = y0, vx = (left ? 1f : -1f) * Random.Range(1.8f, 3.6f + elapsed * 0.02f), t0 = Random.value * 6f };
            it.t = MakeButterfly(kd);
            items.Add(it);
        }
        foreach (var it in items)
        {
            it.x += it.vx * dt; it.t0 += dt;
            it.y = it.base0 + Mathf.Sin(it.t0 * (it.kind == 2 ? 2.2f : 3.2f)) * (it.kind == 2 ? 0.5f : 0.9f);
            it.t.position = new Vector3(it.x, it.y, -0.3f);
            if (it.kind == 2)
            {
                it.t.rotation = Quaternion.Euler(0f, it.vx > 0f ? 0f : 180f, 0f);
            }
            else
            {
                float flap = 0.25f + 0.75f * Mathf.Abs(Mathf.Sin(it.t0 * 15f));
                foreach (Transform c in it.t) if (c.name.StartsWith("Ala")) c.localScale = new Vector3(c.name.EndsWith("I") || c.name.EndsWith("D") ? 0.5f * flap + 0.05f : 0.3f, c.localScale.y, c.localScale.z);
            }
            if (it.dead) continue;
            float rad = swipeT > 0f ? 1.9f : 0.85f;
            if (Vector2.Distance(new Vector2(it.x, it.y), new Vector2(sx, sy + 0.7f)) < rad)
            {
                it.dead = true;
                if (it.kind == 2) { Gain(-100, it.x, it.y); stun = 0.8f; }
                else if (it.kind == 1) Gain(150, it.x, it.y);
                else Gain(40, it.x, it.y);
            }
        }
        for (int i = items.Count - 1; i >= 0; i--)
            if (items[i].dead || items[i].x < -11f || items[i].x > 11f) { Destroy(items[i].t.gameObject); items.RemoveAt(i); }
    }

    // ---------------------------------------------------------------- huellas
    int PressedDir()
    {
        float h = Inp.Horizontal(), v = Inp.Vertical();
        int d = -1;
        if (v > 0.5f && prevV <= 0.5f) d = 0;
        else if (v < -0.5f && prevV >= -0.5f) d = 1;
        else if (h < -0.5f && prevH >= -0.5f) d = 2;
        else if (h > 0.5f && prevH <= 0.5f) d = 3;
        prevH = h; prevV = v;
        return d;
    }

    void PawPose(float dt)
    {
        pawKick = Mathf.Max(0f, pawKick - dt * 5f);
        if (pawL != null) pawL.localRotation = Quaternion.Euler(-38f - (pawSide == 0 ? 22f * pawKick : 0f), 0f, 0f);
        if (pawR != null) pawR.localRotation = Quaternion.Euler(-38f - (pawSide == 1 ? 22f * pawKick : 0f), 0f, 0f);
        if (surieModel != null) surieModel.localPosition = new Vector3(0f, 0f, 0f);
        // botones del control: se hunden y brillan
        for (int i = 0; i < 4; i++)
        {
            if (ctrlBtn[i] == null) continue;
            bool on = litPad == i && padLit > 0f;
            ctrlBtn[i].localScale = new Vector3(0.16f, on ? 0.03f : 0.07f, 0.16f);
            ctrlBtn[i].GetComponent<Renderer>().sharedMaterial = MatOf(on ? Color.white : Hex("#8A8A99"));
        }
        // pads de la tele
        for (int i = 0; i < 4; i++)
        {
            bool lit = litPad == i && padLit > 0f;
            var b = padT[i].Find("Base");
            if (b != null) b.GetComponent<Renderer>().sharedMaterial = MatOf(lit ? padCol[i] : padCol[i] * 0.45f);
            padT[i].localScale = Vector3.one * (lit ? 1.12f : 1f);
        }
        // huellitas que aparecen (pop)
        for (int i = 0; i < prints.Count; i++)
        {
            if (prints[i] == null) continue;
            printT[i] += dt;
            float f = Mathf.Clamp01(printT[i] / 0.25f);
            float s = f < 1f ? Mathf.Sin(f * Mathf.PI * 0.5f) * 1.25f : 1f;
            prints[i].localScale = Vector3.one * s;
        }
    }

    void UpdPaws(float dt)
    {
        padLit -= dt;
        PawPose(dt);
        if (showing)
        {
            showT -= dt;
            if (showT <= 0f)
            {
                if (showIdx < seq.Count) { litPad = seq[showIdx]; padLit = 0.45f; showIdx++; showT = 0.7f; AudioManager.Sfx("salto"); }
                else { showing = false; inputIdx = 0; }
            }
            PressedDir();
            return;
        }
        int d = PressedDir();
        if (d < 0) return;
        litPad = d; padLit = 0.25f; pawKick = 1f; pawSide = (pawSide + 1) % 2;
        if (d == seq[inputIdx])
        {
            AudioManager.Sfx("croqueta");
            if (inputIdx < slots.Count)
            {
                var p = MakePrint(inputIdx, padCol[d]);
                prints.Add(p); printT.Add(0f);
            }
            inputIdx++;
            if (inputIdx >= seq.Count)
            {
                rounds++; score = rounds * 100f; Toast("¡Ronda " + rounds + "!");
                if (rounds >= 12) { End(); return; }
                NewRound();
            }
        }
        else
        {
            AudioManager.Sfx("estres");
            lives--; Toast("¡Fallaste!");
            if (lives <= 0) { End(); return; }
            showing = true; showIdx = 0; showT = 1.0f; inputIdx = 0;     // repite la misma secuencia
            foreach (var p in prints) if (p != null) Destroy(p.gameObject);
            prints.Clear(); printT.Clear();
        }
    }

    // =====================================================================================
    // INTERFAZ (IMGUI sobre el 3D)
    // =====================================================================================
    Rect V(float x, float y, float w, float h) { return new Rect(ox + x * k, y * k, w * k, h * k); }
    void Fill(Rect r, Color c) { Color o = GUI.color; GUI.color = c; GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = o; }
    void Text(string s, float x, float y, float w, float h, GUIStyle st0, Color c) { Color o = GUI.color; GUI.color = c; GUI.Label(V(x, y, w, h), s, st0); GUI.color = o; }

    void Styles()
    {
        if (sTitle != null) return;
        sTitle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold, wordWrap = true };
        sBig = new GUIStyle(sTitle); sMid = new GUIStyle(sTitle); sSmall = new GUIStyle(sTitle);
    }

    void WorldLabel(string s, float wx, float wy, GUIStyle stl, Color c)
    {
        if (cam == null) return;
        Vector3 sp = cam.WorldToScreenPoint(new Vector3(wx, wy, 0f));
        if (sp.z < 0f) return;
        Color o = GUI.color; GUI.color = c;
        GUI.Label(new Rect(sp.x - 140f * k, Screen.height - sp.y - 24f * k, 280f * k, 48f * k), s, stl);
        GUI.color = o;
    }

    void OnGUI()
    {
        Styles();
        k = Screen.height / H; ox = (Screen.width - W * k) * 0.5f;
        sTitle.fontSize = Mathf.RoundToInt(48 * k); sBig.fontSize = Mathf.RoundToInt(34 * k); sMid.fontSize = Mathf.RoundToInt(24 * k); sSmall.fontSize = Mathf.RoundToInt(18 * k);

        if (st == St.Intro)
        {
            Panel();
            Text(Progress.Levels[level].miniName, 140, 150, 1000, 70, sTitle, new Color(1f, 0.9f, 0.5f));
            Text(HowTo(), 190, 250, 900, 170, sMid, Color.white);
            Text("Meta para ganar una vida extra: " + Target() + " puntos" + (best > 0 ? "   ·   Tu récord: " + best : ""), 190, 430, 900, 40, sSmall, new Color(1f, 0.85f, 0.6f));
            Text("Pulsa ESPACIO o haz clic para empezar", 190, 500, 900, 50, sBig, new Color(0.7f, 1f, 0.8f));
            if (GUI.Button(V(0, 0, W, H), "", GUIStyle.none) && Time.time - introAt > 0.4f) Begin();
            return;
        }

        // HUD
        Fill(V(0, 0, W, 54), new Color(0.08f, 0.04f, 0.16f, 0.85f));
        Text(Progress.Levels[level].miniName, 20, 4, 500, 46, sMid, Color.white);
        Text("Puntos: " + Mathf.RoundToInt(score) + "  /  meta " + Target(), 480, 4, 500, 46, sMid, new Color(1f, 0.9f, 0.5f));
        if (kind != "huellas") Text(Mathf.CeilToInt(timeLeft) + " s", 1060, 4, 200, 46, sMid, timeLeft < 10f ? new Color(1f, 0.5f, 0.45f) : Color.white);
        else Text("Vidas: " + lives + "   Ronda: " + (rounds + 1), 960, 4, 300, 46, sMid, Color.white);
        foreach (var pp in pops) WorldLabel(pp.s, pp.wx, pp.wy + pp.t * 1.2f, sBig, new Color(pp.c.r, pp.c.g, pp.c.b, 1f - pp.t / 0.9f));
        if (combo >= 2 && st == St.Play) Text("COMBO x" + Mult() + "  (" + combo + ")", 440, 62, 400, 40, sMid, new Color(1f, 0.9f, 0.3f, 0.7f + 0.3f * Mathf.Sin(Time.time * 10f)));
        if (st == St.Play && (kind == "pescado" || kind == "mariposas") && timeLeft < 12f && timeLeft > 0f)
            Text(kind == "pescado" ? "¡LLUVIA DE PECES!" : "¡ENJAMBRE!", 340, 110, 600, 50, sBig, new Color(1f, 0.85f, 0.3f, 0.6f + 0.4f * Mathf.Sin(Time.time * 8f)));
        if (st == St.Play && kind == "huellas")
            Text(showing ? "Mira la secuencia en la tele..." : "¡Tu turno! (" + inputIdx + "/" + seq.Count + ")  ← ↑ ↓ →", 340, 640, 600, 50, sBig, Color.white);
        if (st == St.Play && kind == "luz" && !dotOn && dotWait > 0f) Text("¡Prepárate!", 440, 110, 400, 50, sBig, new Color(1f, 1f, 1f, 0.7f));
        if (msgT > 0f) WorldLabel(msg, sx, sy + 2.3f, sBig, new Color(1f, 0.95f, 0.5f));

        if (st == St.End)
        {
            Panel();
            int sc = Mathf.RoundToInt(score);
            Text(sc >= TargetN() ? "¡Lo lograste!" : "¡Buen intento!", 140, 130, 1000, 70, sTitle, new Color(1f, 0.9f, 0.5f));
            Text("Puntos: " + sc + (sc >= best && sc > 0 ? "   ★ nuevo récord" : "   ·   récord: " + Progress.Best(level)), 190, 230, 900, 50, sBig, Color.white);
            if (bestCombo >= 2) Text("Mejor combo: " + bestCombo, 190, 270, 900, 30, sSmall, new Color(1f, 0.9f, 0.5f));
            Text(rewarded ? "Premio: +1 vida extra para tu próximo nivel" : "Necesitas " + Target() + " puntos para la vida extra. Puedes repetirlo desde el mapa.", 190, 300, 900, 80, sMid, rewarded ? new Color(0.7f, 1f, 0.8f) : new Color(1f, 0.85f, 0.6f));
            float bw = 400 * k, bh = 70 * k;
            if (UiKit.Button(new Rect(Screen.width * 0.5f - bw * 0.5f, 430 * k, bw, bh), "VOLVER AL MAPA")) Progress.GoWorld();
            if (UiKit.Button(new Rect(Screen.width * 0.5f - bw * 0.5f, 430 * k + bh + 8 * k, bw, bh), "JUGAR OTRA VEZ")) Begin();
        }
    }

    void Panel() { Fill(V(100, 90, 1080, 540), new Color(0.08f, 0.04f, 0.16f, 0.92f)); }
}
