using UnityEngine;

/// <summary>Movimiento 2.5D de Surie: un solo carril (X), salto, trepar cortina y plataformas móviles.</summary>
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(CapsuleCollider))]
public class PlayerController2D : MonoBehaviour
{
    [Header("Movimiento (ajústalo en el Inspector)")]
    public float moveSpeed = 2.6f;
    [Tooltip("Velocidad horizontal en el aire (menor = el hueco largo de 10 cm necesita el ovillo)")]
    public float airSpeedFactor = 0.8f;
    public float jumpHeight = 1.05f;      // ≈ 7 cm de la maqueta (escala 0.15 m por cm)
    public float climbSpeed = 2.0f;
    [Header("Dash (gasta 1 de energía)")]
    public float dashSpeed = 8.5f;
    public float dashTime = 0.25f;
    public float dashCooldown = 0.4f;
    public float coyoteTime = 0.1f;
    public float jumpBuffer = 0.12f;
    public Transform model;

    public int climbZones;
    public float climbCenterX;
    public float climbTopY = 999f;
    public bool Grounded { get; private set; }
    public bool Climbing { get { return climbing; } }
    public bool IsDashing { get { return dashT > 0f; } }
    public float HorizontalSpeed { get { return rb.GetVel().x; } }

    Rigidbody rb;
    CapsuleCollider col;
    float h, v, coyote, buffer;
    bool climbing, jumpHeld;
    float dashT, dashCd, dashBuf, dashDir = 1f;
    float facing = 1f;
    float knockUntil;
    Vector3 knockVel;
    MovingBase platform;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        col = GetComponent<CapsuleCollider>();
        rb.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionZ;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.sleepThreshold = 0f;
        col.ZeroFriction();
    }

    public void TeleportTo(Vector3 p)
    {
        rb.position = p;
        transform.position = p;
        rb.SetVel(Vector3.zero);
        climbing = false;
        dashT = 0f;
        rb.useGravity = true;
    }

    // Empuje asistido: al caminar contra la caja empujable, la caja avanza con Surie (no se atora ni frena de más)
    void OnCollisionStay(Collision c)
    {
        var body = c.rigidbody;
        if (body == null || body.isKinematic || !Grounded || climbing) return;
        if (c.gameObject.name != "Caja_Empujable") return;
        float dir = Mathf.Sign(body.position.x - rb.position.x);
        if (Mathf.Abs(h) < 0.1f || Mathf.Sign(h) != dir) return;
        if (Mathf.Abs(body.position.y - rb.position.y) > 1.2f) return;   // solo si está al nivel de Surie
        Vector3 v = body.GetVel();
        v.x = h * moveSpeed * 0.9f;
        body.SetVel(v);
    }

    public void Knock(Vector2 v)
    {
        knockUntil = Time.time + 0.25f;
        knockVel = new Vector3(v.x, v.y, 0f);
    }

    Renderer[] rends; float flashUntil;
    /// <summary>Parpadeo de daño (Surie no cambia de color, solo titila como en los juegos clásicos).</summary>
    public void Flash(float seconds) { flashUntil = Time.time + seconds; }
    void ApplyFlash()
    {
        if (model == null) return;
        if (rends == null) rends = model.GetComponentsInChildren<Renderer>();
        bool on = true;
        if (Time.time < flashUntil) on = ((int)(Time.time * 14f)) % 2 == 0;
        foreach (var r in rends) if (r != null && r.enabled != on) r.enabled = on;
    }

    void Update()
    {
        h = Inp.Horizontal();
        v = Inp.Vertical();
        jumpHeld = Inp.JumpHeld();
        if (Inp.JumpDown()) buffer = jumpBuffer;
        if (Inp.DashDown()) dashBuf = 0.15f;
        if (h != 0f) facing = Mathf.Sign(h);
        if (model != null)
        {
            // Al trepar, el gato se pone "de cabeza arriba" visto de perfil
            Quaternion target = Quaternion.Euler(0f, facing > 0f ? 90f : -90f, 0f);
            // al trepar: cabeza arriba, VIENTRE contra la cortina (la cámara ve su lomo y la cola colgando), un poco girada de 3/4
            if (climbing) target = Quaternion.Euler(-90f, 0f, 0f) * Quaternion.Euler(0f, facing > 0f ? 25f : -25f, 0f);
            float k = 1f - Mathf.Exp(-14f * Time.deltaTime);
            model.localRotation = Quaternion.Slerp(model.localRotation, target, k);
            Vector3 goalPos = climbing ? new Vector3(0f, 0.5f, 0f) : Vector3.zero;
            model.localPosition = Vector3.Lerp(model.localPosition, goalPos, k);
            ApplyFlash();
        }
    }

    void FixedUpdate()
    {
        CheckGround();
        Vector3 vel = rb.GetVel();
        buffer -= Time.fixedDeltaTime;
        coyote = Grounded ? coyoteTime : coyote - Time.fixedDeltaTime;

        if (Time.time < knockUntil)
        {
            vel.x = knockVel.x;
            if (knockVel.y > 0f) { vel.y = knockVel.y; knockVel.y = 0f; }
            rb.SetVel(vel);
            return;
        }

        // Dash
        dashCd -= Time.fixedDeltaTime;
        dashBuf -= Time.fixedDeltaTime;
        if (dashT > 0f)
        {
            dashT -= Time.fixedDeltaTime;
            vel.x = dashDir * dashSpeed;
            vel.y = 0f;
            rb.SetVel(vel);
            if (dashT <= 0f) rb.useGravity = true;
            return;
        }
        if (dashBuf > 0f && dashCd <= 0f && !climbing && GameManager.I != null && GameManager.I.TryUseEnergy())
        {
            dashT = dashTime;
            dashCd = dashCooldown;
            dashBuf = 0f;
            dashDir = h != 0f ? Mathf.Sign(h) : facing;
            rb.useGravity = false;
            vel.x = dashDir * dashSpeed;
            vel.y = 0f;
            rb.SetVel(vel);
            return;
        }

        // Trepar (cortina)
        if (climbZones > 0 && (v > 0.1f || climbing))
        {
            climbing = true;
            rb.useGravity = false;
            vel.y = v * climbSpeed;
            if (vel.y > 0f && rb.position.y >= climbTopY - 0.2f) vel.y = 0f;   // llega al tope de la cortina
            // se pega al centro de la cortina si no se mueve de lado
            vel.x = Mathf.Abs(h) > 0.1f ? h * moveSpeed * 0.6f : (climbCenterX - rb.position.x) * 10f;
            if (buffer > 0f)
            {
                climbing = false;
                rb.useGravity = true;
                vel.y = JumpVelocity();
                buffer = 0f;
                Analytics.Event("jump", "cortina");
                if (GameManager.I != null) GameManager.I.NoteJump();
            }
            rb.SetVel(vel);
            return;
        }
        if (climbing)
        {
            climbing = false;
        }
        rb.useGravity = true;

        vel.x = h * moveSpeed * (Grounded ? 1f : airSpeedFactor);
        if (buffer > 0f && coyote > 0f)
        {
            vel.y = JumpVelocity();
            buffer = 0f;
            coyote = 0f;
            Analytics.Event("jump");
            if (GameManager.I != null) GameManager.I.NoteJump();
        }
        else if (!jumpHeld && vel.y > 0.5f && !Grounded)
        {
            vel.y *= 0.9f; // salto corto si sueltas la tecla
        }
        // Gravedad extra al caer: salto más "snappy"
        rb.SetVel(vel);

        if (platform != null && Grounded)
            rb.position += platform.Delta;

        if (transform.position.y > 4.6f) { rb.position = new Vector3(rb.position.x, 3.0f, 0f); rb.SetVel(Vector3.zero); }   // nunca sale por el techo

        if (transform.position.y < -8f)
        {
            Analytics.Event("fall", "vacio");
            GameManager.I.AddStress(1, "¡Te caíste! +1 estrés");
            GameManager.I.RespawnPlayer();
        }
    }

    float JumpVelocity()
    {
        return Mathf.Sqrt(2f * Mathf.Abs(Physics.gravity.y) * jumpHeight);
    }

    void CheckGround()
    {
        Grounded = false;
        platform = null;
        Vector3 c = transform.TransformPoint(col.center);
        RaycastHit[] hits = Physics.SphereCastAll(c, 0.15f, Vector3.down, 0.2f, ~0, QueryTriggerInteraction.Ignore);
        foreach (var hit in hits)
        {
            if (hit.collider == col || hit.collider.attachedRigidbody == rb) continue;
            if (hit.normal.y > 0.5f && rb.GetVel().y <= 0.5f)
            {
                Grounded = true;
                platform = hit.collider.GetComponentInParent<MovingBase>();
                break;
            }
        }
    }
}
