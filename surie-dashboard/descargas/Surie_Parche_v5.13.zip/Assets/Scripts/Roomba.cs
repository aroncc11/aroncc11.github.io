using UnityEngine;

/// <summary>Robot aspiradora que patrulla de lado a lado. Si toca a Surie: +1 estrés y empujón.</summary>
public class Roomba : MonoBehaviour
{
    public float xMin = 10.5f;
    public float xMax = 12.3f;
    public float speed = 1.5f;
    public float pause = 0.5f;
    float dir = 1f;
    float wait;
    float cooldown;
    Rigidbody body;
    float warnAt;
    Renderer[] rends;
    Color[] baseCol;

    void Start()
    {
        body = GetComponent<Rigidbody>();
        rends = GetComponentsInChildren<Renderer>();
        baseCol = new Color[rends.Length];
        for (int i = 0; i < rends.Length; i++) baseCol[i] = rends[i].material.HasProperty("_Color") ? rends[i].material.color : Color.white;
    }

    void Update()
    {
        // v2: la Roomba avisa cuando Surie se acerca (parpadea en rojo y un mensaje, 1 vez cada 25 s)
        var gm = GameManager.I;
        if (gm == null || gm.player == null) return;
        float d = Mathf.Abs(gm.player.transform.position.x - transform.position.x);
        bool near = d < 3.2f && Mathf.Abs(gm.player.transform.position.y - transform.position.y) < 2.5f;
        if (rends != null)
        {
            float w = near ? 0.5f + 0.5f * Mathf.Sin(Time.time * 10f) : 0f;
            for (int i = 0; i < rends.Length; i++)
                if (rends[i] != null && rends[i].material.HasProperty("_Color"))
                    rends[i].material.color = Color.Lerp(baseCol[i], new Color(1f, 0.25f, 0.2f), w * 0.6f);
        }
        if (near && Time.time > warnAt)
        {
            warnAt = Time.time + 25f;
            Analytics.Event("aviso_roomba");
            gm.Say("¡Cuidado con la Roomba! Salta por encima o usa SHIFT para atravesarla", 3.5f);
        }
    }

    void FixedUpdate()
    {
        cooldown -= Time.fixedDeltaTime;
        if (wait > 0f) { wait -= Time.fixedDeltaTime; return; }
        Vector3 p = transform.position;
        p.x += dir * speed * Time.fixedDeltaTime;
        if (p.x > xMax) { p.x = xMax; dir = -1f; wait = pause; }
        if (p.x < xMin) { p.x = xMin; dir = 1f; wait = pause; }
        if (body != null) body.MovePosition(p); else transform.position = p;
    }

    void OnTriggerStay(Collider o)
    {
        var pl = o.GetComponentInParent<PlayerController2D>();
        if (pl == null || cooldown > 0f || pl.IsDashing) return;   // el dash atraviesa la Roomba
        cooldown = 1.5f;
        GameManager.I.AddStress(1, "¡La Roomba te tocó! +1 estrés");
        float side = pl.transform.position.x >= transform.position.x ? 1f : -1f;
        pl.Knock(new Vector2(side * 4f, 5f));
    }
}
