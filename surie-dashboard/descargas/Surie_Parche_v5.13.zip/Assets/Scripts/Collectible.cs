using UnityEngine;

public enum CollectType { Letter, Bell, Toy, Energy, BonusEnd }

/// <summary>Letras, cascabel y juguete: giran, flotan y se recogen al tocarlos.</summary>
public class Collectible : MonoBehaviour
{
    public CollectType type;
    public int index;
    Vector3 basePos;
    bool init;

    void Update()
    {
        if (!init) { basePos = transform.localPosition; init = true; }
        transform.localPosition = basePos + Vector3.up * Mathf.Sin(Time.time * 2.5f + index) * 0.05f;
        if (type != CollectType.Letter) transform.Rotate(0f, 90f * Time.deltaTime, 0f, Space.World);
    }

    void OnTriggerEnter(Collider o)
    {
        if (o.GetComponentInParent<PlayerController2D>() == null) return;
        var gm = GameManager.I;
        switch (type)
        {
            case CollectType.Letter: gm.CollectLetter(index); break;
            case CollectType.Bell: gm.CollectBell(); break;
            case CollectType.Toy: gm.Win(); break;
            case CollectType.BonusEnd: gm.EndBonus(true); break;
            case CollectType.Energy: gm.AddEnergy(1f); Analytics.Event("croqueta"); break;
        }
        if (type == CollectType.Toy || type == CollectType.BonusEnd) gameObject.SetActive(false); else Destroy(gameObject);
    }
}
