using UnityEngine;

/// <summary>Estilo propio de la interfaz de Surie: botones, logo, fondo e iconos diseñados a medida (Resources/UI).</summary>
public static class UiKit
{
    public static Texture2D pausaBg, huella, surieImg, benitoImg;
    public static Texture2D bg, logo, btnN, btnH, btnP, btnOff, iconEnergy, iconStress, iconFace;
    static GUIStyle btn, label, title, small;
    static int lastH;
    public static float K { get { return Screen.height / 720f; } }
    public static readonly Color Ink = new Color(0.36f, 0.19f, 0.27f);
    public static readonly Color Cream = new Color(1f, 0.96f, 0.88f);

    public static void Load()
    {
        if (bg != null) return;
        bg = Resources.Load<Texture2D>("UI/menu_fondo");
        logo = Resources.Load<Texture2D>("UI/logo");
        btnN = Resources.Load<Texture2D>("UI/btn_normal");
        btnH = Resources.Load<Texture2D>("UI/btn_hover");
        btnP = Resources.Load<Texture2D>("UI/btn_press");
        btnOff = Resources.Load<Texture2D>("UI/btn_off");
        iconEnergy = Resources.Load<Texture2D>("UI/icon_energia");
        iconStress = Resources.Load<Texture2D>("UI/icon_estres");
        iconFace = Resources.Load<Texture2D>("UI/icon_surie_cara");
        pausaBg = Resources.Load<Texture2D>("UI/pausa_fondo");
        huella = Resources.Load<Texture2D>("UI/huella");
        surieImg = Resources.Load<Texture2D>("UI/surie_frente34");
        benitoImg = Resources.Load<Texture2D>("UI/benito_frente34_izq");
    }

    static void Styles()
    {
        Load();
        if (btn != null && lastH == Screen.height) return;
        lastH = Screen.height;
        btn = new GUIStyle(GUI.skin.button);
        btn.normal.background = btnN; btn.hover.background = btnH; btn.active.background = btnP;
        btn.focused.background = btnH; btn.onNormal.background = btnN; btn.onHover.background = btnH; btn.onActive.background = btnP;
        btn.normal.textColor = btn.hover.textColor = btn.active.textColor = btn.focused.textColor = Ink;
        btn.border = new RectOffset(0, 0, 0, 0);
        btn.alignment = TextAnchor.MiddleCenter;
        btn.fontStyle = FontStyle.Bold;
        btn.fontSize = Mathf.RoundToInt(23 * K);
        btn.padding = new RectOffset(Mathf.RoundToInt(48 * K), 0, 0, Mathf.RoundToInt(8 * K));
        label = new GUIStyle(GUI.skin.label) { fontSize = Mathf.RoundToInt(22 * K), wordWrap = true, richText = true };
        label.normal.textColor = Cream;
        title = new GUIStyle(label) { fontSize = Mathf.RoundToInt(32 * K), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        small = new GUIStyle(label) { fontSize = Mathf.RoundToInt(17 * K) };
    }

    public static GUIStyle Label { get { Styles(); return label; } }
    public static GUIStyle Title { get { Styles(); return title; } }
    public static GUIStyle Small { get { Styles(); return small; } }

    /// <summary>Botón con arte propio. Ancho 400, alto ≈ 88 (en unidades de 720p).</summary>
    public static bool Button(Rect r, string text)
    {
        Styles();
        btn.fontSize = Mathf.RoundToInt(r.height * 0.36f);
        btn.padding = new RectOffset(Mathf.RoundToInt(r.height * 0.72f), 0, 0, Mathf.RoundToInt(r.height * 0.08f));
        bool c = GUI.Button(r, text, btn);
        if (c) AudioManager.Sfx("click");
        return c;
    }

    public static void Panel(Rect r)
    {
        Color o = GUI.color;
        GUI.color = new Color(0.12f, 0.07f, 0.2f, 0.88f);
        GUI.DrawTexture(r, Texture2D.whiteTexture, ScaleMode.StretchToFill, true, 0f, GUI.color, Vector4.zero, 28f * K);
        GUI.color = new Color(1f, 0.8f, 0.5f, 1f);
        GUI.DrawTexture(r, Texture2D.whiteTexture, ScaleMode.StretchToFill, true, 0f, GUI.color, new Vector4(3f * K, 3f * K, 3f * K, 3f * K), 28f * K);
        GUI.color = o;
    }

    /// <summary>Dibuja un sprite con su proporción, anclado abajo al centro (x,y), con un balanceo suave.</summary>
    public static void Sprite(Texture2D t, float cx, float bottom, float h, float bob)
    {
        if (t == null) return;
        float w = h * t.width / t.height;
        GUI.DrawTexture(new Rect(cx - w * 0.5f, bottom - h - bob, w, h), t, ScaleMode.ScaleToFit, true);
    }

    /// <summary>Pantalla de pausa: fondo de huellitas, Surie a la izquierda y Benito a la derecha.</summary>
    public static void PauseBackground()
    {
        Load();
        float k = K, t = Time.realtimeSinceStartup;
        if (pausaBg != null) GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), pausaBg, ScaleMode.ScaleAndCrop);
        // huellitas que flotan
        if (huella != null)
            for (int i = 0; i < 14; i++)
            {
                float x = (i * 173f) % Screen.width, y = ((i * 97f + t * (12f + i)) % (Screen.height + 80f)) - 40f;
                GUI.color = new Color(1f, 1f, 1f, 0.10f + 0.06f * Mathf.Sin(t + i));
                GUI.DrawTexture(new Rect(x, Screen.height - y, 40 * k, 40 * k), huella);
            }
        GUI.color = Color.white;
        float h = Screen.height * 0.62f;
        Sprite(surieImg, Screen.width * 0.17f, Screen.height * 0.93f, h, Mathf.Abs(Mathf.Sin(t * 2.2f)) * 12f * k);
        Sprite(benitoImg, Screen.width * 0.83f, Screen.height * 0.93f, h, Mathf.Abs(Mathf.Sin(t * 2.2f + 1.5f)) * 12f * k);
    }

    public static void Background()
    {
        Load();
        if (bg != null) GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), bg, ScaleMode.ScaleAndCrop);
        else { GUI.color = new Color(0.15f, 0.1f, 0.3f); GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture); GUI.color = Color.white; }
    }
}
