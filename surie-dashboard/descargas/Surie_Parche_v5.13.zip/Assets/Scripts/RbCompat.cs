using UnityEngine;

/// <summary>Compatibilidad entre versiones de Unity (velocity / linearVelocity, drag / linearDamping).</summary>
public static class RbCompat
{
    public static Vector3 GetVel(this Rigidbody rb)
    {
#if UNITY_6000_0_OR_NEWER
        return rb.linearVelocity;
#else
        return rb.velocity;
#endif
    }

    public static void SetVel(this Rigidbody rb, Vector3 v)
    {
#if UNITY_6000_0_OR_NEWER
        rb.linearVelocity = v;
#else
        rb.velocity = v;
#endif
    }

    public static void SetDamping(this Rigidbody rb, float d)
    {
#if UNITY_6000_0_OR_NEWER
        rb.linearDamping = d;
#else
        rb.drag = d;
#endif
    }

    public static Collider ZeroFriction(this Collider c)
    {
#if UNITY_6000_0_OR_NEWER
        var m = new PhysicsMaterial("ZeroFriction");
        m.frictionCombine = PhysicsMaterialCombine.Minimum;
#else
        var m = new PhysicMaterial("ZeroFriction");
        m.frictionCombine = PhysicMaterialCombine.Minimum;
#endif
        m.dynamicFriction = 0f;
        m.staticFriction = 0f;
        c.material = m;
        return c;
    }
}
