using UnityEngine;

/// <summary>Ovillo colgante: se balancea. El jugador se para en la plataforma superior del ovillo.</summary>
[RequireComponent(typeof(Rigidbody))]
public class PendulumPlatform : MovingBase
{
    public Vector3 pivot;
    public float length = 1.41f;
    public float amplitudeDeg = 14f;
    public float period = 2.6f;
    public LineRenderer string_;
    public Transform[] ropes;          // cuerdas (cilindros) del columpio
    public float[] ropeDx;             // desplazamiento en X de cada cuerda
    Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
    }

    Vector3 PosAt(float t)
    {
        float a = amplitudeDeg * Mathf.Deg2Rad * Mathf.Sin(2f * Mathf.PI * t / period);
        return pivot + new Vector3(Mathf.Sin(a), -Mathf.Cos(a), 0f) * length;
    }

    void FixedUpdate()
    {
        Vector3 np = PosAt(Time.fixedTime);
        Delta = np - rb.position;
        rb.MovePosition(np);
    }

    void LateUpdate()
    {
        if (string_ != null)
        {
            string_.SetPosition(0, pivot);
            string_.SetPosition(1, transform.position);
        }
        if (ropes != null)
            for (int i = 0; i < ropes.Length; i++)
            {
                if (ropes[i] == null) continue;
                float dx = (ropeDx != null && i < ropeDx.Length) ? ropeDx[i] : 0f;
                Vector3 a = pivot + new Vector3(dx, 0f, 0f), b = transform.position + new Vector3(dx, 0.05f, 0f);
                Vector3 d = b - a; float L = d.magnitude;
                if (L < 0.01f) continue;
                ropes[i].position = (a + b) * 0.5f;
                ropes[i].rotation = Quaternion.FromToRotation(Vector3.up, d / L);
                ropes[i].localScale = new Vector3(ropes[i].localScale.x, L * 0.5f, ropes[i].localScale.z);
            }
    }
}
