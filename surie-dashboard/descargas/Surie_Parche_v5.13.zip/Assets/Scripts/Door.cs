using UnityEngine;

/// <summary>Puerta de gato: solo se abre si Surie tiene el cascabel.</summary>
public class Door : MonoBehaviour
{
    public Transform panel;
    public Collider panelCollider;
    public float openHeight = 0.85f;
    float open;
    bool near;
    float warnCooldown;
    Vector3 startPos;
    bool init;

    void Update()
    {
        if (!init && panel != null) { startPos = panel.localPosition; init = true; }
        warnCooldown -= Time.deltaTime;
        if (near && GameManager.I.hasBell && open < 1f)
        {
            open = Mathf.Min(1f, open + Time.deltaTime * 2f);
            if (panel != null) panel.localPosition = startPos + Vector3.up * openHeight * open;
            if (open > 0.25f && panelCollider != null) panelCollider.enabled = false;   // ya se puede pasar
        }
    }

    void OnTriggerStay(Collider o)
    {
        if (o.GetComponentInParent<PlayerController2D>() != null) near = true;
    }

    void OnTriggerEnter(Collider o)
    {
        if (o.GetComponentInParent<PlayerController2D>() == null) return;
        near = true;
        if (!GameManager.I.hasBell) GameManager.I.Say("La puerta de gato está cerrada: necesitas el cascabel", 3f);
    }

    void OnTriggerExit(Collider o)
    {
        if (o.GetComponentInParent<PlayerController2D>() != null) near = false;
    }
}
