using UnityEngine;

/// <summary>
/// Demo de las animaciones hechas en Blender (FBX): Idle, Caminar, Estirarse_Bostezar, Buscar y Tomar_agua.
/// Automático: se queda en Idle y cada cierto tiempo hace un gesto. Teclas 1-5 para forzar cada animación.
/// </summary>
public class SurieAnimDemo : MonoBehaviour
{
    public Animator anim;
    public string[] clipNames = { "Idle_Respira", "Caminar", "Estirarse_Bostezar", "Buscar", "Tomar_agua" };
    public float[] clipSeconds = { 2f, 1f, 5.5f, 4.6f, 6f };
    float nextAt = 3f, endAt;
    int current;
    string label = "";

    void Play(int i)
    {
        current = i;
        label = clipNames[i];
        if (anim != null) anim.CrossFadeInFixedTime(clipNames[i], 0.15f);
        endAt = Time.time + clipSeconds[i];
        Analytics.Event("anim_demo", clipNames[i]);
    }

    void Start() { Play(0); }

    void Update()
    {
        if (anim == null) return;
        for (int i = 0; i < 5; i++) if (Inp.NumberDown(i + 1)) { Play(i); nextAt = Time.time + clipSeconds[i] + 2f; }
        if (current == 1 && Time.time > endAt) endAt = Time.time + 1f;                   // la caminata se repite
        if (current >= 2 && Time.time > endAt) { Play(0); nextAt = Time.time + Random.Range(2.5f, 4f); }
        if (current == 0 && Time.time > nextAt) Play(Random.Range(2, 5));
        if (current == 1) transform.position += transform.forward * 1.2f * Time.deltaTime;   // avanza mientras camina
    }

    void OnGUI()
    {
        float k = Screen.height / 720f;
        var st = new GUIStyle(GUI.skin.label) { fontSize = Mathf.RoundToInt(28 * k), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        GUI.color = new Color(0f, 0f, 0f, 0.55f);
        GUI.DrawTexture(new Rect(Screen.width * 0.5f - 260 * k, 20 * k, 520 * k, 56 * k), Texture2D.whiteTexture);
        GUI.color = new Color(1f, 0.93f, 0.7f);
        GUI.Label(new Rect(Screen.width * 0.5f - 260 * k, 20 * k, 520 * k, 56 * k), "Animación: " + label, st);
        var sm = new GUIStyle(st) { fontSize = Mathf.RoundToInt(16 * k), fontStyle = FontStyle.Normal };
        GUI.color = new Color(1f, 1f, 1f, 0.8f);
        GUI.Label(new Rect(0, Screen.height - 40 * k, Screen.width, 30 * k), "1 Idle · 2 Caminar · 3 Estirarse y bostezar · 4 Buscar · 5 Tomar agua", sm);
        GUI.color = Color.white;
    }
}
