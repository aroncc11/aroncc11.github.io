using UnityEngine;

/// <summary>TV de la pared: se enciende/apaga cada 3 turnos. Encendida = zona de ruido activa.</summary>
public class TVController : MonoBehaviour
{
    public Renderer screen;
    public TextMesh label;
    public Color onColor = new Color(0.55f, 0.76f, 0.95f);
    public Color offColor = new Color(0.12f, 0.13f, 0.15f);
    bool last;
    bool first = true;

    void Update()
    {
        bool on = GameManager.I != null && GameManager.I.TvOn;
        if (!first && on == last) return;
        first = false;
        last = on;
        if (screen != null) screen.material.color = on ? onColor : offColor;
        if (label != null) label.gameObject.SetActive(on);
    }
}
