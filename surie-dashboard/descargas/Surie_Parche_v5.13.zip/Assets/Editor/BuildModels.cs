#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Fábrica de modelos 3D "caseros" (armados con primitivas: cubos, esferas, cilindros) para los niveles 2-6:
/// cajas, libros, mesas, repisas, barriles, inodoros, tinas, árboles, casa del perro, perro, ovillo, etc.
/// Todos se crean con el origen en el centro-abajo del objeto (x, y = piso, z) y NO llevan collider
/// (el collider es el bloque invisible de la plataforma).
/// </summary>
public static partial class BuildSurieLevel
{
    static System.Random mrnd = new System.Random(7);

    static Material Cm(string hex) { return Mat("P" + hex.Replace("#", ""), hex); }

    static GameObject Pm(PrimitiveType pt, string n, Transform par, float x, float y, float z, float sx, float sy, float sz, string hex,
                         float rx = 0f, float ry = 0f, float rz = 0f)
    {
        var g = GameObject.CreatePrimitive(pt);
        g.name = n;
        g.transform.SetParent(par, false);
        g.transform.localPosition = new Vector3(x, y, z);
        g.transform.localRotation = Quaternion.Euler(rx, ry, rz);
        g.transform.localScale = new Vector3(sx, sy, sz);
        g.GetComponent<Renderer>().sharedMaterial = Cm(hex);
        var c = g.GetComponent<Collider>(); if (c != null) Object.DestroyImmediate(c);
        return g;
    }

    static Transform Root(string n, Transform par, Vector3 pos)
    {
        var g = new GameObject(n);
        g.transform.SetParent(par, false);
        g.transform.position = pos;
        return g.transform;
    }

    static string Pal(params string[] c) { return c[mrnd.Next(c.Length)]; }
    static float Rf(float a, float b) { return a + (float)mrnd.NextDouble() * (b - a); }
    const PrimitiveType CU = PrimitiveType.Cube, SP = PrimitiveType.Sphere, CY = PrimitiveType.Cylinder, CA = PrimitiveType.Capsule;

    // =====================================================================================
    // PLATAFORMAS (w = ancho, h = alto, en metros; el collider es el bloque)
    // =====================================================================================
    static Transform BuildStyle(string style, Transform par, Vector3 pos, float w, float h)
    {
        switch (style)
        {
            case "caja": return ModCrate(par, pos, w, h);
            case "libros": return ModBooks(par, pos, w, h);
            case "mueble": return ModCounter(par, pos, w, h);
            case "lata": return ModCan(par, pos, w, h);
            case "repisa": return ModShelf(par, pos, w, h);
            case "mesa": return ModTable(par, pos, w, h);
            case "cojin": return ModCushion(par, pos, w, h);
            case "barril": return ModBarrel(par, pos, w, h);
            case "tronco": return ModStump(par, pos, w, h);
            case "piedra": return ModRock(par, pos, w, h);
            case "maceta": return ModPot(par, pos, w, h);
            case "bloque": return ModToyBlock(par, pos, w, h);
            case "lego": return ModLego(par, pos, w, h);
            case "toalla": return ModTowels(par, pos, w, h);
            case "jabon": return ModSoap(par, pos, w, h);
            case "banquito": return ModStool(par, pos, w, h);
            case "maleta": return ModSuitcase(par, pos, w, h);
            default: return ModCrate(par, pos, w, h);
        }
    }

    static GameObject Plat(string name, float x0, float x1, float y0, float y1, string style, Transform geo, Transform deco)
    {
        var b = Box(name, x0, x1, y0, y1, Cm("#999999"), geo, true, D);
        b.GetComponent<Renderer>().enabled = false;
        BuildStyle(style, deco, new Vector3((x0 + x1) * 0.5f * S, y0 * S, 0f), (x1 - x0) * S, (y1 - y0) * S);
        return b;
    }

    static Transform ModCrate(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Caja3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, h * 0.5f, 0, w, h, 0.95f, "#C8935A");
        Pm(CU, "Tapa", r, 0, h - 0.035f, 0, w + 0.05f, 0.08f, 1.0f, "#B07D48");
        Pm(CU, "Base", r, 0, 0.03f, 0, w + 0.03f, 0.06f, 0.98f, "#A06B3A");
        Pm(CU, "Cinta", r, 0, h * 0.5f, -0.48f, Mathf.Min(0.16f, w * 0.25f), h * 0.97f, 0.03f, "#EBDFB5");
        Pm(CU, "Etiqueta", r, w * 0.27f, h * 0.42f, -0.485f, w * 0.24f, Mathf.Min(h * 0.3f, 0.4f), 0.02f, "#F6F2E8");
        return r;
    }

    static Transform ModBooks(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Libros3D", par, pos);
        float y = 0f;
        int guard = 0;
        while (y < h - 0.02f && guard++ < 12)
        {
            float bh = Mathf.Min(Rf(0.17f, 0.26f), h - y);
            float bw = w * Rf(0.9f, 1.0f);
            string col = Pal("#B5483F", "#3E6FB5", "#4F9A5F", "#D9A441", "#7A4FA3", "#2F7F86");
            Pm(CU, "Libro", r, Rf(-0.06f, 0.06f), y + bh * 0.5f, 0, bw, bh, 0.92f, col, 0f, 0f, Rf(-2.5f, 2.5f));
            Pm(CU, "Paginas", r, 0f, y + bh * 0.5f, -0.45f, bw * 0.96f, bh * 0.7f, 0.03f, "#F2EBD8");
            y += bh;
        }
        return r;
    }

    static Transform ModCounter(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Mueble3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, (h - 0.1f) * 0.5f, 0, w, h - 0.1f, 1.0f, "#E9F0F2");
        Pm(CU, "Cubierta", r, 0, h - 0.05f, -0.02f, w + 0.06f, 0.1f, 1.06f, "#7F8C96");
        int n = Mathf.Max(1, Mathf.RoundToInt(w / 0.9f));
        for (int i = 0; i < n; i++)
        {
            float cx = -w * 0.5f + (i + 0.5f) * w / n;
            Pm(CU, "Puerta", r, cx, (h - 0.1f) * 0.5f, -0.505f, w / n - 0.06f, h - 0.22f, 0.02f, "#D5DEE3");
            Pm(CU, "Manija", r, cx + (w / n) * 0.3f, (h - 0.1f) * 0.6f, -0.52f, 0.05f, 0.18f, 0.04f, "#555C63");
        }
        return r;
    }

    static Transform ModCan(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Lata3D", par, pos);
        string c = Pal("#D9534F", "#5BA55B", "#E3B23C");
        float d = Mathf.Min(w, 0.95f);
        int n = Mathf.Max(1, Mathf.RoundToInt(w / 0.9f));
        for (int i = 0; i < n; i++)
        {
            float cx = -w * 0.5f + (i + 0.5f) * w / n;
            float dw = w / n;
            Pm(CY, "Lata", r, cx, h * 0.5f, 0, dw * 0.96f, h * 0.5f, 0.9f, "#C9CED3");
            Pm(CY, "Etiqueta", r, cx, h * 0.5f, 0, dw * 0.975f, h * 0.3f, 0.92f, c);
            Pm(CY, "Tapa", r, cx, h - 0.01f, 0, dw * 0.9f, 0.02f, 0.84f, "#9AA1A8");
        }
        return r;
    }

    static Transform ModShelf(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Repisa3D", par, pos);
        float t = Mathf.Min(0.2f, h);
        Pm(CU, "Tabla", r, 0, h - t * 0.5f, 0, w, t, 1.0f, "#A0714F");
        Pm(CU, "Canto", r, 0, h - t * 0.5f, -0.505f, w, t * 0.9f, 0.02f, "#8C5F3E");
        if (h > 0.45f)
        {
            Pm(CU, "Soporte1", r, -w * 0.5f + 0.12f, (h - t) * 0.5f, 0, 0.14f, h - t, 0.8f, "#7A4E2D");
            Pm(CU, "Soporte2", r, w * 0.5f - 0.12f, (h - t) * 0.5f, 0, 0.14f, h - t, 0.8f, "#7A4E2D");
            Pm(CU, "Travesaño", r, 0, h * 0.35f, 0.3f, w - 0.2f, 0.1f, 0.1f, "#7A4E2D");
        }
        return r;
    }

    static Transform ModTable(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Mesa3D", par, pos);
        Pm(CU, "Tapa", r, 0, h - 0.09f, 0, w, 0.18f, 1.05f, "#7A4E2D");
        Pm(CU, "Mantel", r, 0, h - 0.0f, 0, w * 0.6f, 0.02f, 1.07f, "#C94F4F");
        for (int i = 0; i < 4; i++)
        {
            float lx = (i % 2 == 0 ? -1f : 1f) * (w * 0.5f - 0.14f), lz = (i < 2 ? -1f : 1f) * 0.38f;
            Pm(CU, "Pata", r, lx, (h - 0.18f) * 0.5f, lz, 0.13f, h - 0.18f, 0.13f, "#5E3A20");
        }
        return r;
    }

    static Transform ModCushion(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Cojin3D", par, pos);
        string c = Pal("#B98A66", "#C77D8F", "#7AA6C9", "#9C86C9");
        Pm(CU, "Base", r, 0, h * 0.4f, 0, w, h * 0.8f, 1.0f, c);
        Pm(SP, "Panza", r, 0, h * 0.78f, 0, w * 0.98f, h * 0.5f, 1.0f, c);
        Pm(SP, "Boton", r, 0, h * 0.99f, 0, 0.1f, 0.05f, 0.1f, "#4B3A2A");
        for (int i = 0; i < 2; i++) Pm(SP, "Borla", r, (i == 0 ? -1f : 1f) * (w * 0.5f), h * 0.15f, -0.45f, 0.14f, 0.14f, 0.14f, "#F4E3A8");
        return r;
    }

    static Transform ModBarrel(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Barril3D", par, pos);
        float d = Mathf.Min(w, 0.98f);
        Pm(CY, "Cuerpo", r, 0, h * 0.5f, 0, w * 0.96f, h * 0.5f, 0.96f, "#8A5A34");
        Pm(CY, "Aro1", r, 0, h * 0.18f, 0, w, 0.04f, 1.0f, "#3B3F44");
        Pm(CY, "Aro2", r, 0, h * 0.82f, 0, w, 0.04f, 1.0f, "#3B3F44");
        Pm(CY, "Tapa", r, 0, h - 0.005f, 0, w * 0.86f, 0.015f, 0.86f, "#A87646");
        return r;
    }

    static Transform ModStump(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Tronco3D", par, pos);
        Pm(CY, "Tronco", r, 0, h * 0.5f, 0, w * 0.95f, h * 0.5f, 0.95f, "#7A5130");
        Pm(CY, "Corte", r, 0, h - 0.005f, 0, w * 0.93f, 0.012f, 0.93f, "#C99C66");
        Pm(CY, "Anillo", r, 0, h + 0.002f, 0, w * 0.6f, 0.006f, 0.6f, "#A9794A");
        Pm(CY, "Anillo2", r, 0, h + 0.004f, 0, w * 0.3f, 0.006f, 0.3f, "#8B5E36");
        Pm(SP, "Musgo", r, -w * 0.38f, h * 0.15f, -0.35f, 0.4f, 0.22f, 0.3f, "#5C8F4B");
        return r;
    }

    static Transform ModRock(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Roca3D", par, pos);
        Pm(SP, "Roca", r, 0, h * 0.45f, 0, w * 1.05f, h * 1.25f, 1.05f, "#8C8F94");
        Pm(SP, "Roca2", r, -w * 0.22f, h * 0.55f, -0.1f, w * 0.6f, h * 0.9f, 0.8f, "#A3A6AB");
        Pm(SP, "Musgo", r, w * 0.2f, h * 0.9f, 0, w * 0.4f, h * 0.2f, 0.7f, "#6E9F58");
        return r;
    }

    static Transform ModPot(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Maceta3D", par, pos);
        Pm(CY, "Maceta", r, 0, h * 0.42f, 0, w * 0.96f, h * 0.42f, 0.96f, "#C46A3C");
        Pm(CY, "Borde", r, 0, h * 0.88f, 0, w, h * 0.12f, 1.0f, "#D97C4B");
        Pm(CY, "Tierra", r, 0, h * 0.98f, 0, w * 0.85f, 0.02f, 0.85f, "#4B3220");
        Pm(SP, "Planta1", r, -w * 0.2f, h + 0.15f, 0, 0.5f, 0.4f, 0.5f, "#4FA05F");
        Pm(SP, "Planta2", r, w * 0.22f, h + 0.1f, 0, 0.45f, 0.35f, 0.45f, "#5BB26B");
        Pm(SP, "Flor", r, 0f, h + 0.38f, -0.1f, 0.18f, 0.18f, 0.18f, Pal("#F25C7A", "#F7D154", "#FFFFFF"));
        return r;
    }

    static Transform ModToyBlock(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Bloque3D", par, pos);
        string c = Pal("#E8605A", "#F2C230", "#4F9AE0", "#5CBF7A", "#B07AD8");
        Pm(CU, "Bloque", r, 0, h * 0.5f, 0, w, h, 0.95f, c);
        Pm(CU, "Borde", r, 0, h - 0.025f, 0, w + 0.04f, 0.05f, 0.99f, "#FFFFFF");
        var tm = MakeText("" + "ABCDEFGHKLMNPRST"[mrnd.Next(16)], r, r.position + new Vector3(0f, h * 0.5f, -0.5f), Mathf.Clamp(h * 0.12f, 0.06f, 0.14f), Color.white, 48);
        return r;
    }

    static Transform ModLego(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Lego3D", par, pos);
        string c = Pal("#E8605A", "#F2C230", "#4F9AE0", "#5CBF7A");
        Pm(CU, "Pieza", r, 0, h * 0.5f, 0, w, h, 0.95f, c);
        int n = Mathf.Max(2, Mathf.RoundToInt(w / 0.4f));
        for (int i = 0; i < n; i++)
            Pm(CY, "Perno", r, -w * 0.5f + (i + 0.5f) * w / n, h + 0.04f, 0, Mathf.Min(0.26f, w / n * 0.7f), 0.04f, 0.26f, c);
        return r;
    }

    static Transform ModTowels(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Toallas3D", par, pos);
        float y = 0f; int i = 0;
        string[] cs = { "#F4A6B8", "#9FD3E8", "#FFFFFF", "#F7E08A" };
        while (y < h - 0.01f)
        {
            float th = Mathf.Min(0.2f, h - y);
            Pm(CU, "Toalla", r, Rf(-0.05f, 0.05f), y + th * 0.5f, 0, w * Rf(0.94f, 1.0f), th, 0.95f, cs[i % cs.Length]);
            Pm(SP, "Pliegue", r, w * 0.5f - 0.03f, y + th * 0.5f, 0, th * 0.9f, th * 0.95f, 0.95f, cs[i % cs.Length]);
            y += th; i++;
        }
        return r;
    }

    static Transform ModSoap(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Jabon3D", par, pos);
        string c = Pal("#F2A7C3", "#A8E0C8", "#B8CCF2");
        Pm(CU, "Pastilla", r, 0, h * 0.45f, 0, w, h * 0.9f, 0.9f, c);
        Pm(SP, "Pastilla2", r, 0, h * 0.85f, 0, w * 0.98f, h * 0.3f, 0.9f, c);
        for (int i = 0; i < 4; i++) Pm(SP, "Burbuja", r, Rf(-w * 0.45f, w * 0.45f), h + Rf(0.02f, 0.16f), Rf(-0.3f, 0.2f), 0.16f, 0.16f, 0.16f, "#E8F6FF");
        return r;
    }

    static Transform ModStool(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Banquito3D", par, pos);
        Pm(CY, "Asiento", r, 0, h - 0.06f, 0, w, 0.06f, 0.95f, "#C9A26B");
        for (int i = 0; i < 4; i++)
            Pm(CU, "Pata", r, (i % 2 == 0 ? -1f : 1f) * (w * 0.5f - 0.14f), (h - 0.12f) * 0.5f, (i < 2 ? -1f : 1f) * 0.3f, 0.1f, h - 0.12f, 0.1f, "#8B6B3E");
        Pm(CU, "Refuerzo", r, 0, h * 0.35f, 0, w - 0.3f, 0.06f, 0.06f, "#8B6B3E");
        return r;
    }

    static Transform ModSuitcase(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Maleta3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, h * 0.5f, 0, w, h, 0.95f, "#8A5B3B");
        Pm(CU, "Franja", r, 0, h * 0.5f, -0.48f, w, 0.06f, 0.03f, "#5E3A22");
        Pm(CU, "Cierre1", r, -w * 0.25f, h * 0.5f, -0.5f, 0.1f, 0.12f, 0.03f, "#D9C27A");
        Pm(CU, "Cierre2", r, w * 0.25f, h * 0.5f, -0.5f, 0.1f, 0.12f, 0.03f, "#D9C27A");
        Pm(CU, "Asa", r, 0, h + 0.03f, 0, w * 0.3f, 0.06f, 0.1f, "#3B2A1C");
        return r;
    }

    // =====================================================================================
    // OBJETOS ESPECIALES CON COMPORTAMIENTO
    // =====================================================================================
    /// <summary>Inodoro (mira a la derecha). Devuelve la tapa (pivote) y el agua; el collider lo crea el generador.</summary>
    static void ModToilet(Transform par, Vector3 pos, out Transform lid, out Transform water)
    {
        var r = Root("Inodoro3D", par, pos);
        Pm(CU, "Pedestal", r, -0.15f, 0.21f, 0, 0.62f, 0.42f, 0.8f, "#F2F4F5");
        Pm(SP, "Panza", r, -0.1f, 0.36f, 0, 0.78f, 0.34f, 0.9f, "#F2F4F5");
        Pm(CU, "Aro", r, 0f, 0.47f, 0, 0.9f, 0.07f, 0.98f, "#E2E8EC");
        Pm(CU, "Tanque", r, 0.67f, 0.5f, 0, 0.45f, 1.0f, 0.82f, "#F2F4F5");
        Pm(CU, "TanqueTapa", r, 0.67f, 1.015f, 0, 0.52f, 0.05f, 0.88f, "#DDE4E8");
        Pm(CY, "Palanca", r, 0.67f, 1.08f, -0.2f, 0.12f, 0.03f, 0.12f, "#B8C0C6");
        var w = Pm(CY, "Agua", r, 0f, 0.51f, 0, 0.62f, 0.012f, 0.66f, "#4FA3E0");
        w.name = "Agua_Inodoro";
        var pv = new GameObject("Tapa_Pivote").transform;
        pv.SetParent(r, false);
        pv.localPosition = new Vector3(0.43f, 0.5f, 0f);
        Pm(CU, "Tapa", pv, -0.43f, 0.03f, 0, 0.86f, 0.06f, 0.94f, "#E8EEF1");
        lid = pv; water = w.transform;
    }

    static GameObject ModDuck(Transform par, Vector3 pos)
    {
        var r = Root("Patito3D", par, pos);
        Pm(SP, "Cuerpo", r, 0, 0.3f, 0, 0.95f, 0.62f, 0.8f, "#F7D23A");
        Pm(SP, "Cola", r, -0.42f, 0.45f, 0, 0.3f, 0.3f, 0.3f, "#F7D23A");
        Pm(SP, "Cabeza", r, 0.28f, 0.7f, 0, 0.46f, 0.46f, 0.46f, "#F7D23A");
        Pm(CU, "Pico", r, 0.52f, 0.66f, 0, 0.2f, 0.07f, 0.22f, "#F28C28");
        Pm(SP, "Ojo", r, 0.4f, 0.78f, -0.18f, 0.07f, 0.07f, 0.07f, "#1B1B1B");
        Pm(SP, "Ala", r, -0.05f, 0.33f, -0.38f, 0.45f, 0.25f, 0.1f, "#E8BE20");
        return r.gameObject;
    }

    /// <summary>Estufa con 3 hornillas: devuelve las posiciones X locales de las hornillas.</summary>
    static Transform ModStove(Transform par, Vector3 pos, float w, float h)
    {
        var r = Root("Estufa3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, (h - 0.06f) * 0.5f, 0, w, h - 0.06f, 1.0f, "#9AA3AB");
        Pm(CU, "Plancha", r, 0, h - 0.03f, 0, w + 0.04f, 0.06f, 1.04f, "#2D3237");
        Pm(CU, "VentanaHorno", r, 0, h * 0.42f, -0.505f, w * 0.7f, h * 0.45f, 0.02f, "#2A2F34");
        Pm(CU, "Manija", r, 0, h * 0.72f, -0.52f, w * 0.6f, 0.05f, 0.04f, "#D6DBDF");
        for (int i = 0; i < 4; i++) Pm(CY, "Perilla", r, -w * 0.36f + i * w * 0.24f, h * 0.88f, -0.51f, 0.12f, 0.03f, 0.12f, "#3A4046", 90f, 0f, 0f);
        return r;
    }

    static void ModBurner(Transform par, Vector3 pos, out Transform flame)
    {
        var r = Root("Hornilla3D", par, pos);
        Pm(CY, "Aro", r, 0, 0.02f, 0, 0.62f, 0.02f, 0.62f, "#1A1D20");
        Pm(CY, "Centro", r, 0, 0.045f, 0, 0.3f, 0.02f, 0.3f, "#3A4046");
        var f = Pm(SP, "Llama", r, 0, 0.42f, 0, 0.5f, 0.8f, 0.5f, "#FF8A1E");
        Pm(SP, "LlamaInterna", f.transform, 0, -0.12f, 0, 0.55f, 0.6f, 0.55f, "#FFE066");
        Pm(SP, "Punta", f.transform, 0, 0.35f, 0, 0.35f, 0.5f, 0.35f, "#FF5A1E");
        f.transform.localPosition = new Vector3(0, 0.1f, 0);
        flame = f.transform;
    }

    static Transform ModSprinkler(Transform par, Vector3 pos, out Transform jet)
    {
        var r = Root("Aspersor3D", par, pos);
        Pm(CY, "Base", r, 0, 0.12f, 0, 0.5f, 0.12f, 0.5f, "#3F6FA8");
        Pm(CY, "Tubo", r, 0, 0.32f, 0, 0.12f, 0.2f, 0.12f, "#9AA3AB");
        Pm(SP, "Cabeza", r, 0, 0.55f, 0, 0.22f, 0.22f, 0.22f, "#2F4F7A");
        // chorro: abanico de 5 hilos de agua curvos + gotas (el padre se anima en altura)
        var j = Root("Chorro", r, pos + new Vector3(0f, 0.6f, 0f)).gameObject;
        float[] ang = { -50f, -25f, 0f, 25f, 50f };
        for (int i = 0; i < 5; i++)
        {
            float a2 = ang[i];
            float lenA = (i == 2) ? 1.5f : 1.1f;
            var st = Pm(CY, "Hilo" + i, j.transform, Mathf.Sin(a2 * Mathf.Deg2Rad) * lenA * 0.5f, Mathf.Cos(a2 * Mathf.Deg2Rad) * lenA * 0.5f, 0f, 0.07f, lenA * 0.5f, 0.07f, "#7EC8F0", 0f, 0f, -a2);
            Pm(SP, "Gota" + i, j.transform, Mathf.Sin(a2 * Mathf.Deg2Rad) * (lenA + 0.1f), Mathf.Cos(a2 * Mathf.Deg2Rad) * lenA - 0.15f, 0f, 0.2f, 0.26f, 0.2f, "#B7E4FA");
        }
        jet = j.transform;
        return r;
    }

    // =====================================================================================
    // DECORACIÓN DE FONDO (naturales, sin collider)
    // =====================================================================================
    static Transform ModFridge(Transform par, Vector3 pos)
    {
        var r = Root("Refri3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, 1.7f, 0, 1.5f, 3.4f, 1.1f, "#E4EBEE");
        Pm(CU, "Linea", r, 0, 2.3f, -0.56f, 1.5f, 0.05f, 0.02f, "#9AA3AB");
        Pm(CU, "Manija1", r, 0.55f, 2.9f, -0.58f, 0.06f, 0.6f, 0.06f, "#8C949A");
        Pm(CU, "Manija2", r, 0.55f, 1.6f, -0.58f, 0.06f, 1.0f, 0.06f, "#8C949A");
        Pm(CU, "Iman", r, -0.3f, 2.9f, -0.57f, 0.25f, 0.25f, 0.02f, "#E8605A");
        return r;
    }

    static Transform ModCabinets(Transform par, Vector3 pos, float w)
    {
        var r = Root("Alacenas3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, 2.55f, 0, w, 1.1f, 0.8f, "#C99A66");
        int n = Mathf.Max(1, Mathf.RoundToInt(w / 0.9f));
        for (int i = 0; i < n; i++)
        {
            float cx = -w * 0.5f + (i + 0.5f) * w / n;
            Pm(CU, "Puerta", r, cx, 2.55f, -0.405f, w / n - 0.06f, 1.0f, 0.02f, "#E0B67F");
            Pm(CU, "Perilla", r, cx + (w / n) * 0.35f, 2.3f, -0.43f, 0.07f, 0.07f, 0.05f, "#4A3A28");
        }
        return r;
    }

    static Transform ModKitchenWindow(Transform par, Vector3 pos)
    {
        var r = Root("Ventana3D", par, pos);
        Pm(CU, "Marco", r, 0, 2.3f, 0, 2.2f, 1.9f, 0.14f, "#F4F0E6");
        Pm(CU, "Vidrio", r, 0, 2.3f, -0.06f, 1.95f, 1.65f, 0.04f, "#A9D8F2");
        Pm(CU, "Cruz1", r, 0, 2.3f, -0.09f, 0.07f, 1.7f, 0.05f, "#F4F0E6");
        Pm(CU, "Cruz2", r, 0, 2.3f, -0.09f, 2.0f, 0.07f, 0.05f, "#F4F0E6");
        Pm(CU, "CortinaL", r, -0.95f, 2.3f, -0.14f, 0.45f, 1.9f, 0.08f, "#E39AB0");
        Pm(CU, "CortinaR", r, 0.95f, 2.3f, -0.14f, 0.45f, 1.9f, 0.08f, "#E39AB0");
        return r;
    }

    static Transform ModHangingPots(Transform par, Vector3 pos)
    {
        var r = Root("Ollas3D", par, pos);
        Pm(CY, "Barra", r, 0, 3.0f, 0, 0.05f, 0.7f, 0.05f, "#6E7378", 0f, 0f, 90f);
        for (int i = 0; i < 3; i++)
        {
            float x = -0.5f + i * 0.5f;
            Pm(CU, "Gancho", r, x, 2.85f, 0, 0.03f, 0.25f, 0.03f, "#6E7378");
            Pm(CY, "Olla", r, x, 2.55f, 0, 0.36f, 0.16f, 0.36f, i == 1 ? "#C94F4F" : "#B8BEC4");
            Pm(CU, "Asa", r, x + 0.28f, 2.58f, 0, 0.3f, 0.04f, 0.04f, "#2D3237");
        }
        return r;
    }

    static Transform ModMirror(Transform par, Vector3 pos)
    {
        var r = Root("Espejo3D", par, pos);
        Pm(CU, "Marco", r, 0, 2.3f, 0, 1.4f, 1.9f, 0.1f, "#D9C27A");
        Pm(CU, "Cristal", r, 0, 2.3f, -0.05f, 1.2f, 1.7f, 0.03f, "#CFE9F5");
        Pm(CU, "Brillo", r, -0.25f, 2.5f, -0.07f, 0.12f, 1.0f, 0.02f, "#F4FBFF", 0f, 0f, 20f);
        return r;
    }

    static Transform ModSink(Transform par, Vector3 pos)
    {
        var r = Root("Lavabo3D", par, pos);
        Pm(CY, "Pedestal", r, 0, 0.9f, 0, 0.5f, 0.9f, 0.5f, "#EEF2F4");
        Pm(CU, "Cuenco", r, 0, 1.85f, 0, 1.5f, 0.3f, 1.0f, "#F4F7F8");
        Pm(CU, "Agua", r, 0, 1.99f, 0, 1.2f, 0.02f, 0.8f, "#A9D8F2");
        Pm(CY, "Grifo", r, 0.0f, 2.3f, 0.35f, 0.1f, 0.25f, 0.1f, "#B8C0C6");
        Pm(CY, "GrifoBrazo", r, 0.0f, 2.55f, 0.2f, 0.08f, 0.2f, 0.08f, "#B8C0C6", 90f, 0f, 0f);
        return r;
    }

    static Transform ModBathtubDecor(Transform par, Vector3 pos)
    {
        var r = Root("TinaFondo3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, 0.65f, 0, 3.0f, 1.3f, 1.3f, "#F4F7F8");
        Pm(CU, "Borde", r, 0, 1.33f, 0, 3.1f, 0.1f, 1.4f, "#E2E8EC");
        Pm(CU, "Agua", r, 0, 1.2f, 0, 2.7f, 0.04f, 1.0f, "#7EC8F0");
        for (int i = 0; i < 4; i++) Pm(CY, "Pata", r, (i % 2 == 0 ? -1f : 1f) * 1.3f, 0.06f, (i < 2 ? -1f : 1f) * 0.5f, 0.2f, 0.06f, 0.2f, "#D9C27A");
        for (int i = 0; i < 6; i++) Pm(SP, "Burbuja", r, Rf(-1.1f, 1.1f), 1.3f + Rf(0f, 0.15f), Rf(-0.3f, 0.3f), 0.22f, 0.22f, 0.22f, "#FFFFFF");
        return r;
    }

    static Transform ModShowerDecor(Transform par, Vector3 pos)
    {
        var r = Root("Regadera3D", par, pos);
        Pm(CY, "Tubo", r, 0, 2.2f, 0, 0.09f, 1.2f, 0.09f, "#B8C0C6");
        Pm(CY, "Brazo", r, 0.35f, 3.4f, 0, 0.08f, 0.4f, 0.08f, "#B8C0C6", 0f, 0f, 90f);
        Pm(CY, "Cabezal", r, 0.7f, 3.35f, 0, 0.5f, 0.06f, 0.5f, "#D6DBDF", 0f, 0f, 20f);
        for (int i = 0; i < 4; i++) Pm(CY, "Gota", r, 0.7f + (i - 1.5f) * 0.12f, 2.9f - (i % 2) * 0.2f, 0, 0.04f, 0.12f, 0.04f, "#9ED8F5");
        Pm(CY, "Llave", r, 0, 1.4f, -0.1f, 0.14f, 0.05f, 0.14f, "#D9C27A", 90f, 0f, 0f);
        return r;
    }

    static Transform ModTowelRack(Transform par, Vector3 pos)
    {
        var r = Root("Toallero3D", par, pos);
        Pm(CY, "Barra", r, 0, 2.2f, 0, 0.05f, 0.7f, 0.05f, "#B8C0C6", 0f, 0f, 90f);
        Pm(CU, "Toalla", r, 0, 1.85f, 0, 0.8f, 0.8f, 0.07f, Pal("#F4A6B8", "#9FD3E8", "#F7E08A"));
        Pm(CU, "Franja", r, 0, 1.55f, -0.04f, 0.8f, 0.1f, 0.02f, "#FFFFFF");
        return r;
    }

    static Transform ModTree(Transform par, Vector3 pos, float h)
    {
        var r = Root("Arbol3D", par, pos);
        Pm(CY, "Tronco", r, 0, h * 0.28f, 0, 0.9f, h * 0.28f, 0.9f, "#6B4423");
        Pm(CY, "Base", r, 0, 0.12f, 0, 1.3f, 0.12f, 1.3f, "#6B4423");
        Pm(SP, "Copa1", r, 0, h * 0.7f, 0, h * 0.5f, h * 0.42f, h * 0.5f, "#3F8F4A");
        Pm(SP, "Copa2", r, -h * 0.22f, h * 0.6f, 0.2f, h * 0.36f, h * 0.3f, h * 0.36f, "#4BA057");
        Pm(SP, "Copa3", r, h * 0.22f, h * 0.62f, -0.2f, h * 0.38f, h * 0.32f, h * 0.38f, "#359047");
        Pm(SP, "Copa4", r, 0, h * 0.9f, 0, h * 0.3f, h * 0.24f, h * 0.3f, "#58B063");
        for (int i = 0; i < 5; i++) Pm(SP, "Fruta", r, Rf(-h * 0.25f, h * 0.25f), h * Rf(0.55f, 0.85f), -h * 0.2f, 0.16f, 0.16f, 0.16f, "#E8453C");
        return r;
    }

    static Transform ModBush(Transform par, Vector3 pos, float w)
    {
        var r = Root("Arbusto3D", par, pos);
        Pm(SP, "A", r, 0, w * 0.28f, 0, w * 0.6f, w * 0.5f, w * 0.5f, "#4BA057");
        Pm(SP, "B", r, -w * 0.25f, w * 0.22f, 0.1f, w * 0.45f, w * 0.4f, w * 0.4f, "#3F8F4A");
        Pm(SP, "C", r, w * 0.26f, w * 0.2f, -0.1f, w * 0.42f, w * 0.36f, w * 0.4f, "#58B063");
        for (int i = 0; i < 4; i++) Pm(SP, "Flor", r, Rf(-w * 0.3f, w * 0.3f), w * Rf(0.2f, 0.45f), -w * 0.22f, 0.14f, 0.14f, 0.14f, Pal("#F25C7A", "#F7D154", "#FFFFFF"));
        return r;
    }

    static Transform ModFence(Transform par, Vector3 pos, float w)
    {
        var r = Root("Cerca3D", par, pos);
        Pm(CU, "Riel1", r, 0, 0.7f, 0, w, 0.12f, 0.1f, "#C9A26B");
        Pm(CU, "Riel2", r, 0, 1.3f, 0, w, 0.12f, 0.1f, "#C9A26B");
        int n = Mathf.RoundToInt(w / 0.45f);
        for (int i = 0; i < n; i++)
        {
            float x = -w * 0.5f + (i + 0.5f) * w / n;
            float hh = 1.7f + (i % 2) * 0.1f;
            Pm(CU, "Tabla", r, x, hh * 0.5f, -0.06f, w / n * 0.78f, hh, 0.08f, "#F2E4C4");
            Pm(CU, "Punta", r, x, hh + 0.04f, -0.06f, w / n * 0.78f * 0.6f, 0.1f, 0.08f, "#F2E4C4", 0f, 0f, 45f);
        }
        return r;
    }

    static Transform ModFlowers(Transform par, Vector3 pos, float w)
    {
        var r = Root("Flores3D", par, pos);
        int n = Mathf.Max(3, Mathf.RoundToInt(w / 0.45f));
        for (int i = 0; i < n; i++)
        {
            float x = -w * 0.5f + (i + 0.5f) * w / n + Rf(-0.1f, 0.1f);
            float hh = Rf(0.4f, 0.9f);
            Pm(CY, "Tallo", r, x, hh * 0.5f, 0, 0.04f, hh * 0.5f, 0.04f, "#4BA057");
            string c = Pal("#F25C7A", "#F7D154", "#FFFFFF", "#B07AD8", "#FF9F40");
            for (int p = 0; p < 5; p++)
            {
                float a = p * 72f * Mathf.Deg2Rad;
                Pm(SP, "Petalo", r, x + Mathf.Cos(a) * 0.13f, hh + Mathf.Sin(a) * 0.13f, -0.02f, 0.14f, 0.14f, 0.06f, c);
            }
            Pm(SP, "Centro", r, x, hh, -0.04f, 0.12f, 0.12f, 0.07f, "#F7C623");
        }
        return r;
    }

    static Transform ModSun(Transform par, Vector3 pos)
    {
        var r = Root("Sol3D", par, pos);
        Pm(SP, "Disco", r, 0, 0, 0, 3.0f, 3.0f, 0.4f, "#FFE066");
        for (int i = 0; i < 12; i++)
        {
            float a = i * 30f;
            Pm(CU, "Rayo", r, Mathf.Cos(a * Mathf.Deg2Rad) * 2.2f, Mathf.Sin(a * Mathf.Deg2Rad) * 2.2f, 0, 0.35f, 0.9f, 0.1f, "#FFD24A", 0f, 0f, a - 90f);
        }
        return r;
    }

    static Transform ModCloud(Transform par, Vector3 pos, float s)
    {
        var r = Root("Nube3D", par, pos);
        Pm(SP, "A", r, 0, 0, 0, 3.2f * s, 1.4f * s, 1.2f * s, "#FFFFFF");
        Pm(SP, "B", r, -1.4f * s, -0.15f * s, 0, 2.2f * s, 1.0f * s, 1.0f * s, "#F4F8FB");
        Pm(SP, "C", r, 1.5f * s, -0.1f * s, 0, 2.4f * s, 1.1f * s, 1.0f * s, "#F4F8FB");
        Pm(SP, "D", r, 0.2f * s, 0.55f * s, 0, 1.8f * s, 1.1f * s, 1.0f * s, "#FFFFFF");
        return r;
    }

    /// <summary>Casa del perro. Devuelve la raíz; "Ojos" = objeto con los ojos rojos asomando por la puerta.</summary>
    static Transform ModDoghouse(Transform par, Vector3 pos, out Transform eyes)
    {
        var r = Root("CasaPerro3D", par, pos);
        float w = 4.2f, h = 2.5f, d = 2.8f;
        Pm(CU, "Cuerpo", r, 0, h * 0.5f, 0, w, h, d, "#B5453A");
        Pm(CU, "Zocalo", r, 0, 0.1f, -0.01f, w + 0.1f, 0.2f, d + 0.1f, "#8F352C");
        Pm(CU, "Puerta", r, 0, 0.8f, -d * 0.5f - 0.01f, 1.5f, 1.6f, 0.04f, "#1B1214");
        Pm(CY, "Arco", r, 0, 1.6f, -d * 0.5f - 0.01f, 1.5f, 0.02f, 1.5f, "#1B1214", 90f, 0f, 0f);
        Pm(CU, "TechoL", r, -w * 0.27f, h + 0.55f, 0, w * 0.68f, 0.18f, d + 0.5f, "#4B3A2A", 0f, 0f, 34f);
        Pm(CU, "TechoR", r, w * 0.27f, h + 0.55f, 0, w * 0.68f, 0.18f, d + 0.5f, "#5A4634", 0f, 0f, -34f);
        Pm(CU, "Cartel", r, 0, 2.15f, -d * 0.5f - 0.03f, 1.4f, 0.4f, 0.04f, "#F2E4C4");
        MakeText("PERRO", r, r.position + new Vector3(0f, 2.15f, -d * 0.5f - 0.07f), 0.16f, new Color(0.35f, 0.14f, 0.1f), 48);
        var e = new GameObject("Ojos").transform;
        e.SetParent(r, false);
        e.localPosition = new Vector3(0f, 0.95f, -d * 0.5f - 0.05f);
        Pm(SP, "OjoI", e, -0.22f, 0, 0, 0.16f, 0.1f, 0.05f, "#FF3030");
        Pm(SP, "OjoD", e, 0.22f, 0, 0, 0.16f, 0.1f, 0.05f, "#FF3030");
        e.gameObject.SetActive(false);
        eyes = e;
        return r;
    }

    static Transform ModToyBox(Transform par, Vector3 pos)
    {
        var r = Root("CajaJuguetes3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, 1.0f, 0, 3.2f, 2.0f, 2.4f, "#E8605A");
        Pm(CU, "Franja", r, 0, 1.0f, -1.21f, 3.2f, 0.4f, 0.04f, "#F2C230");
        Pm(CU, "Tapa", r, -1.2f, 2.5f, 0, 1.9f, 0.14f, 2.4f, "#F2C230", 0f, 0f, 55f);
        MakeText("JUGUETES", r, r.position + new Vector3(0f, 1.0f, -1.26f), 0.13f, Color.white, 48);
        return r;
    }

    // ---- perro y ovillo gigantes (perseguidores)
    static Chaser MakeDogChaser(Transform parent, float homeX, float startX, float speed, out Transform house)
    {
        var root = new GameObject("Perseguidor_Perro");
        root.transform.SetParent(parent, false);
        root.transform.position = new Vector3(homeX, 0f, 0f);
        var vis = new GameObject("Visual").transform; vis.SetParent(root.transform, false);
        string fur = "#8B5A2B", dk = "#4A2E16", lt = "#C79257";
        var torso = new GameObject("Torso").transform; torso.SetParent(vis, false); torso.localPosition = new Vector3(0f, 1.25f, 0f);
        Pm(SP, "Cuerpo", torso, 0, 0, 0, 2.5f, 1.5f, 1.35f, fur);
        Pm(SP, "Panza", torso, 0.05f, -0.35f, 0, 1.8f, 0.8f, 1.1f, lt);
        Pm(SP, "Cabeza", torso, 1.5f, 0.5f, 0, 1.05f, 0.98f, 0.98f, fur);
        Pm(SP, "Hocico", torso, 2.0f, 0.3f, 0, 0.7f, 0.45f, 0.56f, lt);
        Pm(SP, "Nariz", torso, 2.3f, 0.45f, 0, 0.18f, 0.14f, 0.2f, "#111111");
        Pm(SP, "OjoB", torso, 1.78f, 0.78f, -0.36f, 0.24f, 0.22f, 0.1f, "#FFFFFF");
        Pm(SP, "OjoP", torso, 1.84f, 0.78f, -0.42f, 0.12f, 0.14f, 0.06f, "#E5242A");
        Pm(CU, "Ceja", torso, 1.75f, 0.98f, -0.4f, 0.4f, 0.08f, 0.06f, dk, 0f, 0f, -18f);
        Pm(SP, "OrejaF", torso, 1.2f, 0.7f, -0.45f, 0.38f, 0.8f, 0.2f, dk, 0f, 0f, 15f);
        Pm(SP, "OrejaB", torso, 1.2f, 0.7f, 0.45f, 0.38f, 0.8f, 0.2f, dk, 0f, 0f, 15f);
        Pm(CU, "Colmillo1", torso, 2.1f, 0.0f, -0.17f, 0.08f, 0.22f, 0.07f, "#FFFFFF");
        Pm(CU, "Colmillo2", torso, 2.1f, 0.0f, 0.17f, 0.08f, 0.22f, 0.07f, "#FFFFFF");
        Pm(CY, "Collar", torso, 1.0f, 0.15f, 0, 0.5f, 0.12f, 1.0f, "#D9423A", 0f, 0f, 70f);
        var jaw = new GameObject("Mandibula").transform; jaw.SetParent(torso, false); jaw.localPosition = new Vector3(1.8f, 0.12f, 0f);
        Pm(SP, "Quijada", jaw, 0.2f, -0.1f, 0, 0.6f, 0.2f, 0.44f, lt);
        Pm(SP, "Lengua", jaw, 0.2f, -0.03f, 0, 0.4f, 0.08f, 0.26f, "#E86F8A");
        var tail = new GameObject("ColaPivote").transform; tail.SetParent(torso, false); tail.localPosition = new Vector3(-1.2f, 0.25f, 0f);
        tail.localRotation = Quaternion.Euler(0f, 0f, 45f);
        Pm(CY, "Cola", tail, 0, 0.45f, 0, 0.2f, 0.45f, 0.2f, dk);
        Pm(SP, "PuntaCola", tail, 0, 0.92f, 0, 0.26f, 0.26f, 0.26f, lt);
        var legs = new Transform[4];
        float[] lx = { 0.8f, 0.8f, -0.8f, -0.8f }, lz = { -0.45f, 0.45f, -0.45f, 0.45f };
        for (int i = 0; i < 4; i++)
        {
            var pv = new GameObject("Pata" + i).transform; pv.SetParent(vis, false); pv.localPosition = new Vector3(lx[i], 0.95f, lz[i]);
            string c = lz[i] < 0f ? fur : dk;
            Pm(CY, "Muslo", pv, 0, -0.42f, 0, 0.34f, 0.44f, 0.34f, c);
            Pm(SP, "Pata", pv, 0.06f, -0.9f, 0, 0.42f, 0.2f, 0.36f, lz[i] < 0f ? lt : dk);
            legs[i] = pv;
        }
        Transform eyes;
        house = ModDoghouse(parent, new Vector3(homeX, 0f, 2.1f), out eyes);
        var ch = root.AddComponent<Chaser>();
        ch.startX = startX; ch.homeX = homeX; ch.speed = speed; ch.behind = 6f; ch.label = "¡GUAU!";
        ch.visual = vis; ch.house = house; ch.eyes = eyes; ch.bodyT = torso; ch.tail = tail; ch.jaw = jaw; ch.legs = legs;
        ch.homeZ = 2.1f;
        return ch;
    }

    static Chaser MakeYarnChaser(Transform parent, float homeX, float startX, float speed)
    {
        var root = new GameObject("Perseguidor_Ovillo");
        root.transform.SetParent(parent, false);
        root.transform.position = new Vector3(homeX, 0f, 0f);
        var vis = new GameObject("Visual").transform; vis.SetParent(root.transform, false);
        var ball = new GameObject("Ovillo").transform; ball.SetParent(vis, false); ball.localPosition = new Vector3(0f, 1.25f, 0f);
        Pm(SP, "Esfera", ball, 0, 0, 0, 2.5f, 2.5f, 2.5f, "#D8508A");
        for (int i = 0; i < 4; i++) Pm(CY, "Hilo", ball, 0, 0, 0, 2.54f, 0.04f, 2.54f, i % 2 == 0 ? "#9C2F63" : "#F2A3C4", i * 40f, i * 55f, i * 25f);
        Pm(SP, "Pelusa", ball, 0.5f, 0.95f, -1.0f, 0.55f, 0.35f, 0.35f, "#F2A3C4");
        Pm(CU, "Ojo1", ball, 0.7f, 0.5f, -1.22f, 0.4f, 0.4f, 0.05f, "#FFFFFF");
        Pm(CU, "Ojo2", ball, -0.2f, 0.5f, -1.22f, 0.4f, 0.4f, 0.05f, "#FFFFFF");
        Pm(SP, "Pupila1", ball, 0.78f, 0.48f, -1.26f, 0.16f, 0.2f, 0.05f, "#161616");
        Pm(SP, "Pupila2", ball, -0.12f, 0.48f, -1.26f, 0.16f, 0.2f, 0.05f, "#161616");
        Pm(CU, "Ceja1", ball, 0.7f, 0.85f, -1.24f, 0.55f, 0.08f, 0.05f, "#3A1530", 0f, 0f, -18f);
        Pm(CU, "Ceja2", ball, -0.2f, 0.85f, -1.24f, 0.55f, 0.08f, 0.05f, "#3A1530", 0f, 0f, 18f);
        var house = ModToyBox(parent, new Vector3(homeX, 0f, 2.2f));
        var ch = root.AddComponent<Chaser>();
        ch.startX = startX; ch.homeX = homeX; ch.speed = speed; ch.behind = 6f; ch.label = "¡EL OVILLO!";
        ch.homeZ = 2.2f; ch.roll = true; ch.rollRadius = 1.25f; ch.visual = vis; ch.house = house; ch.rollT = ball;
        return ch;
    }
}
#endif
