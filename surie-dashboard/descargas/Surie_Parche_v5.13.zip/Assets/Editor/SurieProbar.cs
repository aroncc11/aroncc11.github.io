#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;

/// <summary>Atajos para probar un solo nivel sin pasar por el menú ni el mapa: Surie ▸ Probar ▸ ...</summary>
public static class SurieProbar
{
    static void Play(string scene)
    {
        if (EditorApplication.isPlaying) { EditorUtility.DisplayDialog("Surie", "Detén el Play antes de elegir otro nivel.", "OK"); return; }
        var a = AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/Scenes/" + scene + ".unity");
        if (a == null) { EditorUtility.DisplayDialog("Surie", "No encuentro Assets/Scenes/" + scene + ".unity\nEjecuta primero Surie > Construir mundo y niveles 2-6.", "OK"); return; }
        EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
        EditorSceneManager.playModeStartScene = a;       // Play arranca directo en esa escena
        EditorApplication.isPlaying = true;
    }

    [MenuItem("Surie/Probar/Nivel 2 - Cocina")] static void N2() { Play("Nivel_2_Cocina"); }
    [MenuItem("Surie/Probar/Nivel 3 - Baño")] static void N3() { Play("Nivel_3_Bano"); }
    [MenuItem("Surie/Probar/Nivel 4 - Patio")] static void N4() { Play("Nivel_4_Patio"); }
    [MenuItem("Surie/Probar/Nivel 5 - Sótano")] static void N5() { Play("Nivel_5_Sotano"); }
    [MenuItem("Surie/Probar/Nivel 6 - Benito (jefe)")] static void N6() { Play("Nivel_6_Benito"); }
    [MenuItem("Surie/Probar/Minijuegos")] static void Mini() { Play("Mini_Surie"); }
    [MenuItem("Surie/Probar/Juego completo (desde el menú)")] static void Full() { Play("Menu_Surie"); }
}
#endif
