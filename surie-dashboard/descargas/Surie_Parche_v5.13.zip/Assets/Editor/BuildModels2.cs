#if UNITY_EDITOR
using UnityEngine;

/// <summary>Más modelos caseros: enemigos (ratón, mosca, cucaracha, araña) y decoración del sótano y del cuarto de Benito.</summary>
public static partial class BuildSurieLevel
{
    // =====================================================================================
    // ENEMIGOS
    // =====================================================================================
    static Transform LegPivot(Transform par, string n, float x, float y, float z, float len, float thick, string hex, float restRz = 0f)
    {
        var pv = new GameObject(n).transform;
        pv.SetParent(par, false);
        pv.localPosition = new Vector3(x, y, z);
        pv.localRotation = Quaternion.Euler(0f, 0f, restRz);
        Pm(CY, "Seg", pv, 0, -len * 0.5f, 0, thick, len * 0.5f, thick, hex);
        return pv;
    }

    static GameObject MakeEnemy(Enemy.Kind kind, float xcm, float ycm, float xMinCm, float xMaxCm, float speed, Transform parent)
    {
        string nm = kind == Enemy.Kind.Raton ? "Enemigo_Raton" : kind == Enemy.Kind.Mosca ? "Enemigo_Mosca" : kind == Enemy.Kind.Cucaracha ? "Enemigo_Cucaracha" : "Enemigo_Arana";
        var e = new GameObject(nm);
        e.transform.SetParent(parent, false);
        float cy = kind == Enemy.Kind.Raton ? 0.28f : kind == Enemy.Kind.Mosca ? ycm * S : kind == Enemy.Kind.Cucaracha ? 0.17f : 0.3f;
        e.transform.position = new Vector3(xcm * S, cy, 0f);
        var t = e.transform;
        Vector3 tsize = new Vector3(0.9f, 1.0f, 0.8f), tcen = new Vector3(0f, 0.3f, 0f);
        float stompH = 0.12f;
        switch (kind)
        {
            case Enemy.Kind.Raton:
                Pm(SP, "Cuerpo", t, 0, 0, 0, 0.66f, 0.4f, 0.42f, "#8E8E96");
                Pm(SP, "Panza", t, 0.02f, -0.08f, 0, 0.5f, 0.22f, 0.36f, "#C9C9D0");
                Pm(SP, "Cabeza", t, 0.34f, 0.04f, 0, 0.3f, 0.26f, 0.27f, "#9A9AA2");
                Pm(SP, "Hocico", t, 0.5f, -0.01f, 0, 0.16f, 0.13f, 0.14f, "#B2B2BA");
                Pm(SP, "Nariz", t, 0.58f, 0.0f, 0, 0.06f, 0.06f, 0.06f, "#F07A94");
                Pm(SP, "Oreja1", t, 0.3f, 0.2f, 0.13f, 0.17f, 0.17f, 0.05f, "#9A9AA2");
                Pm(SP, "OrejaI1", t, 0.3f, 0.2f, 0.16f, 0.11f, 0.11f, 0.03f, "#F0A8B8");
                Pm(SP, "Oreja2", t, 0.3f, 0.2f, -0.13f, 0.17f, 0.17f, 0.05f, "#9A9AA2");
                Pm(SP, "OrejaI2", t, 0.3f, 0.2f, -0.16f, 0.11f, 0.11f, 0.03f, "#F0A8B8");
                Pm(SP, "Ojo", t, 0.44f, 0.09f, -0.1f, 0.05f, 0.05f, 0.05f, "#161616");
                Pm(CU, "Diente", t, 0.55f, -0.08f, -0.02f, 0.03f, 0.05f, 0.03f, "#FFFFFF");
                for (int i = 0; i < 3; i++) Pm(CY, "Bigote", t, 0.5f, -0.01f + (i - 1) * 0.03f, -0.1f, 0.01f, 0.09f, 0.01f, "#E8E8EE", 90f, 0f, 90f + (i - 1) * 18f);
                Pm(CY, "ColaA", t, -0.42f, -0.05f, 0, 0.035f, 0.12f, 0.035f, "#F0A8B8", 0f, 0f, 80f);
                Pm(CY, "ColaB", t, -0.62f, 0.02f, 0, 0.03f, 0.12f, 0.03f, "#F0A8B8", 0f, 0f, 60f);
                LegPivot(t, "Pata_1", 0.2f, -0.12f, -0.14f, 0.16f, 0.07f, "#7C7C84");
                LegPivot(t, "Pata_2", 0.2f, -0.12f, 0.14f, 0.16f, 0.07f, "#7C7C84");
                LegPivot(t, "Pata_3", -0.2f, -0.12f, -0.14f, 0.16f, 0.07f, "#7C7C84");
                LegPivot(t, "Pata_4", -0.2f, -0.12f, 0.14f, 0.16f, 0.07f, "#7C7C84");
                tsize = new Vector3(0.95f, 1.0f, 0.8f); tcen = new Vector3(0f, 0.3f, 0f); stompH = 0.12f;
                break;
            case Enemy.Kind.Mosca:
                Pm(SP, "Cuerpo", t, 0, 0, 0, 0.4f, 0.32f, 0.32f, "#3A3A46");
                Pm(SP, "Abdomen", t, -0.2f, -0.02f, 0, 0.3f, 0.26f, 0.26f, "#2B2B36");
                Pm(SP, "Cabeza", t, 0.22f, 0.02f, 0, 0.22f, 0.22f, 0.22f, "#3A3A46");
                Pm(SP, "OjoI", t, 0.3f, 0.06f, -0.1f, 0.12f, 0.14f, 0.1f, "#E5484D");
                Pm(SP, "OjoD", t, 0.3f, 0.06f, 0.1f, 0.12f, 0.14f, 0.1f, "#E5484D");
                var a1 = Pm(SP, "Ala1", t, -0.02f, 0.2f, -0.14f, 0.34f, 0.05f, 0.2f, "#BFE3F2");
                var a2 = Pm(SP, "Ala2", t, -0.02f, 0.2f, 0.14f, 0.34f, 0.05f, 0.2f, "#BFE3F2");
                LegPivot(t, "Pata_1", 0.08f, -0.1f, -0.08f, 0.14f, 0.03f, "#222222");
                LegPivot(t, "Pata_2", 0.0f, -0.1f, 0.08f, 0.14f, 0.03f, "#222222");
                LegPivot(t, "Pata_3", -0.1f, -0.1f, -0.08f, 0.14f, 0.03f, "#222222");
                tsize = new Vector3(0.75f, 0.7f, 0.8f); tcen = Vector3.zero; stompH = -0.12f;
                break;
            case Enemy.Kind.Cucaracha:
                Pm(SP, "Cuerpo", t, 0, 0, 0, 0.62f, 0.24f, 0.38f, "#5B3A1E");
                Pm(SP, "Alas", t, -0.04f, 0.07f, 0, 0.5f, 0.12f, 0.34f, "#7A4E27");
                Pm(CU, "Linea", t, -0.04f, 0.14f, 0, 0.45f, 0.01f, 0.02f, "#3A2410");
                Pm(SP, "Cabeza", t, 0.36f, -0.01f, 0, 0.2f, 0.18f, 0.22f, "#4A2E16");
                Pm(SP, "OjoI", t, 0.42f, 0.04f, -0.08f, 0.06f, 0.06f, 0.06f, "#FFFFFF");
                Pm(SP, "OjoD", t, 0.42f, 0.04f, 0.08f, 0.06f, 0.06f, 0.06f, "#FFFFFF");
                Pm(CY, "Antena1", t, 0.52f, 0.14f, -0.08f, 0.015f, 0.22f, 0.015f, "#3A2410", 0f, 0f, -55f);
                Pm(CY, "Antena2", t, 0.52f, 0.14f, 0.08f, 0.015f, 0.22f, 0.015f, "#3A2410", 0f, 0f, -75f);
                for (int i = 0; i < 6; i++)
                    LegPivot(t, "Pata_" + i, -0.18f + (i / 2) * 0.18f, -0.06f, (i % 2 == 0 ? -1f : 1f) * 0.15f, 0.15f, 0.035f, "#3A2410");
                tsize = new Vector3(0.9f, 0.9f, 0.8f); tcen = new Vector3(0f, 0.25f, 0f); stompH = 0.08f;
                break;
            default: // araña
                Pm(SP, "Abdomen", t, -0.2f, 0.02f, 0, 0.5f, 0.42f, 0.42f, "#1E1A22");
                Pm(SP, "Marca", t, -0.2f, 0.02f, -0.2f, 0.12f, 0.16f, 0.04f, "#D9302F");
                Pm(SP, "Cabeza", t, 0.14f, 0f, 0, 0.3f, 0.26f, 0.28f, "#2B2630");
                Pm(SP, "Ojo1", t, 0.26f, 0.06f, -0.08f, 0.07f, 0.07f, 0.06f, "#FF3B3B");
                Pm(SP, "Ojo2", t, 0.28f, 0.0f, -0.06f, 0.05f, 0.05f, 0.05f, "#FF3B3B");
                Pm(SP, "Ojo3", t, 0.26f, 0.06f, 0.08f, 0.07f, 0.07f, 0.06f, "#FF3B3B");
                for (int i = 0; i < 8; i++)
                {
                    float z = (i % 2 == 0 ? -1f : 1f) * 0.1f;
                    float x = 0.2f - (i / 2) * 0.13f;
                    var lp = LegPivot(t, "Pata_" + i, x, 0f, z, 0.32f, 0.04f, "#1E1A22", (i / 2 - 1.5f) * 22f);
                }
                tsize = new Vector3(1.0f, 1.0f, 0.8f); tcen = new Vector3(0f, 0.25f, 0f); stompH = 0.1f;
                break;
        }
        var bc = e.AddComponent<BoxCollider>();
        bc.isTrigger = true; bc.size = tsize; bc.center = tcen;
        var rb = e.AddComponent<Rigidbody>(); rb.isKinematic = true;
        var en = e.AddComponent<Enemy>();
        en.kind = kind; en.xMin = xMinCm * S; en.xMax = xMaxCm * S; en.speed = speed; en.baseY = cy; en.stompHeight = stompH;
        return e;
    }

    // =====================================================================================
    // DECORACIÓN: SÓTANO Y CUARTO DE BENITO
    // =====================================================================================
    static Transform ModCrateStack(Transform par, Vector3 pos)
    {
        var r = Root("PilaCajas3D", par, pos);
        ModCrate(r, pos + new Vector3(-0.6f, 0f, 0f), 1.5f, 1.2f);
        ModCrate(r, pos + new Vector3(0.7f, 0f, 0.1f), 1.2f, 1.0f);
        ModCrate(r, pos + new Vector3(-0.2f, 1.2f, 0f), 1.1f, 0.9f);
        return r;
    }

    static Transform ModRack(Transform par, Vector3 pos, float w)
    {
        var r = Root("Anaquel3D", par, pos);
        Pm(CU, "PosteI", r, -w * 0.5f + 0.06f, 1.5f, 0, 0.12f, 3.0f, 0.5f, "#6B6F76");
        Pm(CU, "PosteD", r, w * 0.5f - 0.06f, 1.5f, 0, 0.12f, 3.0f, 0.5f, "#6B6F76");
        for (int i = 0; i < 4; i++)
        {
            float y = 0.3f + i * 0.9f;
            Pm(CU, "Tabla", r, 0, y, 0, w, 0.1f, 0.55f, "#8B6B3E");
            int n = Mathf.Max(2, Mathf.RoundToInt(w / 0.45f));
            for (int j = 0; j < n; j++)
            {
                float x = -w * 0.5f + (j + 0.5f) * w / n;
                if (mrnd.Next(4) == 0) continue;
                float hh = Rf(0.25f, 0.5f);
                Pm(CY, "Frasco", r, x, y + 0.05f + hh * 0.5f, 0, 0.26f, hh * 0.5f, 0.26f, Pal("#C9774A", "#7FBF7A", "#D9C27A", "#9B7AC9"));
                Pm(CY, "Tapa", r, x, y + 0.06f + hh, 0, 0.22f, 0.025f, 0.22f, "#444A50");
            }
        }
        return r;
    }

    static Transform ModPipes(Transform par, Vector3 pos, float w)
    {
        var r = Root("Tuberias3D", par, pos);
        Pm(CY, "Tubo", r, 0, 0, 0, 0.22f, w * 0.5f, 0.22f, "#7B8088", 0f, 0f, 90f);
        for (float x = -w * 0.5f + 1f; x < w * 0.5f; x += 3.5f) Pm(CY, "Junta", r, x, 0, 0, 0.32f, 0.12f, 0.32f, "#5C6168", 0f, 0f, 90f);
        for (float x = -w * 0.5f + 2.2f; x < w * 0.5f; x += 7f) Pm(CY, "Bajada", r, x, -0.6f, 0, 0.14f, 0.6f, 0.14f, "#7B8088");
        return r;
    }

    static Transform ModBulb(Transform par, Vector3 pos)
    {
        var r = Root("Foco3D", par, pos);
        Pm(CY, "Cable", r, 0, 0.5f, 0, 0.03f, 0.5f, 0.03f, "#222222");
        Pm(CY, "Casquillo", r, 0, 0.0f, 0, 0.14f, 0.07f, 0.14f, "#8A8D92");
        Pm(SP, "Foco", r, 0, -0.18f, 0, 0.32f, 0.38f, 0.32f, "#FFF3B0");
        r.gameObject.AddComponent<Wobble>().rotAmp = new Vector3(0f, 0f, 4f);
        return r;
    }

    static Transform ModHeater(Transform par, Vector3 pos)
    {
        var r = Root("Calentador3D", par, pos);
        Pm(CY, "Tanque", r, 0, 1.4f, 0, 1.4f, 1.4f, 1.4f, "#B8BEC4");
        Pm(CY, "Tapa", r, 0, 2.8f, 0, 1.2f, 0.05f, 1.2f, "#8E959C");
        Pm(CY, "Pipa", r, 0.3f, 3.1f, 0, 0.14f, 0.3f, 0.14f, "#6B6F76");
        Pm(CU, "Panel", r, 0, 1.6f, -0.71f, 0.5f, 0.35f, 0.03f, "#2D3237");
        Pm(SP, "Luz", r, 0.1f, 1.6f, -0.74f, 0.08f, 0.08f, 0.04f, "#5CFF7A");
        return r;
    }

    static Transform ModBed(Transform par, Vector3 pos)
    {
        var r = Root("Cama3D", par, pos);
        Pm(CU, "Base", r, 0, 0.5f, 0, 4.2f, 0.7f, 2.2f, "#9B7A5A");
        Pm(CU, "Colchon", r, 0, 1.0f, 0, 4.0f, 0.4f, 2.0f, "#F4F0E6");
        Pm(CU, "Manta", r, 0.5f, 1.25f, -0.02f, 3.0f, 0.12f, 2.04f, "#6AA9E0");
        Pm(SP, "Almohada", r, -1.6f, 1.35f, 0, 0.9f, 0.3f, 1.2f, "#FFFFFF");
        Pm(CU, "Cabecera", r, -2.15f, 1.3f, 0, 0.14f, 1.8f, 2.3f, "#7A5A3C");
        Pm(CU, "Piecera", r, 2.15f, 0.9f, 0, 0.14f, 1.1f, 2.3f, "#7A5A3C");
        Pm(SP, "Peluche", r, -1.1f, 1.6f, -0.3f, 0.5f, 0.5f, 0.5f, "#D9A066");
        return r;
    }

    static Transform ModPoster(Transform par, Vector3 pos, float w, float h, string c1, string c2)
    {
        var r = Root("Poster3D", par, pos);
        Pm(CU, "Marco", r, 0, h * 0.5f, 0, w, h, 0.06f, "#FFFFFF");
        Pm(CU, "Fondo", r, 0, h * 0.5f, -0.04f, w - 0.14f, h - 0.14f, 0.03f, c1);
        Pm(SP, "Sol", r, -w * 0.15f, h * 0.65f, -0.07f, w * 0.28f, w * 0.28f, 0.03f, c2);
        Pm(CU, "Pie", r, 0, h * 0.28f, -0.07f, w * 0.7f, h * 0.18f, 0.03f, c2);
        return r;
    }

    static Transform ModBalloons(Transform par, Vector3 pos)
    {
        var r = Root("Globos3D", par, pos);
        string[] cs = { "#E8605A", "#F2C230", "#4F9AE0" };
        for (int i = 0; i < 3; i++)
        {
            float x = (i - 1) * 0.55f, y = 2.6f + (i % 2) * 0.35f;
            Pm(SP, "Globo", r, x, y, 0, 0.7f, 0.85f, 0.7f, cs[i]);
            Pm(CY, "Hilo", r, x * 0.5f, y * 0.5f - 0.2f, 0, 0.015f, y * 0.5f - 0.2f, 0.015f, "#DDDDDD", 0f, 0f, -x * 14f);
        }
        r.gameObject.AddComponent<Wobble>().rotAmp = new Vector3(0f, 0f, 3f);
        return r;
    }

    static Transform ModBlockTower(Transform par, Vector3 pos)
    {
        var r = Root("Torre3D", par, pos);
        string[] cs = { "#E8605A", "#F2C230", "#4F9AE0", "#5CBF7A", "#B07AD8" };
        for (int i = 0; i < 5; i++)
        {
            Pm(CU, "Bloque", r, Rf(-0.08f, 0.08f), 0.4f + i * 0.8f, 0, 0.8f, 0.8f, 0.8f, cs[i], 0f, Rf(-8f, 8f), 0f);
        }
        return r;
    }

    static Transform ModBallToy(Transform par, Vector3 pos)
    {
        var r = Root("Pelota3D", par, pos);
        Pm(SP, "Bola", r, 0, 0.7f, 0, 1.4f, 1.4f, 1.4f, "#E8605A");
        Pm(CY, "Franja", r, 0, 0.7f, 0, 1.42f, 0.04f, 1.42f, "#FFFFFF");
        Pm(CY, "Franja2", r, 0, 0.7f, 0, 1.42f, 0.04f, 1.42f, "#4F9AE0", 90f, 0f, 0f);
        return r;
    }

    static Transform ModToyShelf(Transform par, Vector3 pos, float w)
    {
        var r = Root("EstanteJuguetes3D", par, pos);
        Pm(CU, "Cuerpo", r, 0, 1.5f, 0, w, 0.12f, 0.7f, "#C99A66");
        Pm(CU, "Cuerpo2", r, 0, 2.6f, 0, w, 0.12f, 0.7f, "#C99A66");
        Pm(CU, "LadoI", r, -w * 0.5f, 2.0f, 0, 0.12f, 2.2f, 0.7f, "#B58552");
        Pm(CU, "LadoD", r, w * 0.5f, 2.0f, 0, 0.12f, 2.2f, 0.7f, "#B58552");
        ModToyBlock(r, pos + new Vector3(-w * 0.28f, 1.56f, 0f), 0.6f, 0.6f);
        ModToyBlock(r, pos + new Vector3(w * 0.05f, 1.56f, 0f), 0.5f, 0.5f);
        Pm(SP, "Pelota", r, w * 0.3f, 1.9f, 0, 0.5f, 0.5f, 0.5f, "#4F9AE0");
        Pm(SP, "Peluche", r, -w * 0.15f, 2.95f, 0, 0.55f, 0.55f, 0.4f, "#D9A066");
        Pm(SP, "Peluche2", r, w * 0.2f, 2.9f, 0, 0.5f, 0.5f, 0.4f, "#F4A6B8");
        return r;
    }

    // =====================================================================================
    // DECORACIÓN DE FONDO POR NIVEL (z grande = más al fondo)
    // =====================================================================================
    static void DecorLevel(int li, float lenM, Transform deco)
    {
        var rnd = new System.Random(900 + li);
        float x = 2f; int k = 0;
        while (x < lenM)
        {
            switch (li)
            {
                case 0: // cocina
                    switch (k % 5)
                    {
                        case 0: ModKitchenWindow(deco, new Vector3(x, 0f, 3.45f)); ModCounter(deco, new Vector3(x, 0f, 2.7f), 3.4f, 1.4f); break;
                        case 1: ModFridge(deco, new Vector3(x, 0f, 2.7f)); ModCabinets(deco, new Vector3(x + 2.8f, 0f, 3.3f), 3.2f); break;
                        case 2: ModCabinets(deco, new Vector3(x, 0f, 3.3f), 3.6f); ModCounter(deco, new Vector3(x, 0f, 2.7f), 3.6f, 1.4f); ModHangingPots(deco, new Vector3(x, 0f, 3.0f)); break;
                        case 3: ModKitchenWindow(deco, new Vector3(x, 0f, 3.45f)); ModStove(deco, new Vector3(x, 0f, 2.7f), 2.0f, 1.4f); break;
                        default: ModFridge(deco, new Vector3(x, 0f, 2.7f)); ModCounter(deco, new Vector3(x + 2.4f, 0f, 2.7f), 3.0f, 1.4f); break;
                    }
                    x += 6.5f + (float)rnd.NextDouble() * 3f; break;
                case 1: // baño
                    switch (k % 5)
                    {
                        case 0: ModMirror(deco, new Vector3(x, 0f, 3.45f)); ModSink(deco, new Vector3(x, 0f, 2.8f)); break;
                        case 1: ModBathtubDecor(deco, new Vector3(x, 0f, 2.5f)); ModShowerDecor(deco, new Vector3(x + 2.2f, 0f, 3.2f)); break;
                        case 2: ModTowelRack(deco, new Vector3(x, 0f, 3.4f)); ModKitchenWindow(deco, new Vector3(x + 2.8f, 0f, 3.45f)); break;
                        case 3: ModSink(deco, new Vector3(x, 0f, 2.8f)); ModMirror(deco, new Vector3(x, 0f, 3.45f)); ModTowelRack(deco, new Vector3(x + 2f, 0f, 3.4f)); break;
                        default: ModBathtubDecor(deco, new Vector3(x, 0f, 2.5f)); ModMirror(deco, new Vector3(x + 2.5f, 0f, 3.45f)); break;
                    }
                    x += 6.0f + (float)rnd.NextDouble() * 3f; break;
                case 2: // patio
                    ModTree(deco, new Vector3(x, 0f, 5.2f + (float)rnd.NextDouble() * 1.5f), 8f + (float)rnd.NextDouble() * 3f);
                    ModBush(deco, new Vector3(x + 3.2f, 0f, 2.6f), 2.4f);
                    ModFlowers(deco, new Vector3(x + 1.2f, 0f, 1.7f), 2.6f);
                    if (k % 3 == 1) ModCloud(deco, new Vector3(x + 1f, 7.5f + (float)rnd.NextDouble() * 2f, 11f), 1.6f);
                    x += 9f + (float)rnd.NextDouble() * 4f; break;
                case 3: // sótano
                    switch (k % 5)
                    {
                        case 0: ModRack(deco, new Vector3(x, 0f, 3.2f), 3.4f); ModCrateStack(deco, new Vector3(x + 3.2f, 0f, 2.4f)); break;
                        case 1: ModHeater(deco, new Vector3(x, 0f, 2.8f)); ModBarrel(deco, new Vector3(x + 2.4f, 0f, 2.3f), 1.1f, 1.5f); break;
                        case 2: ModCrateStack(deco, new Vector3(x, 0f, 2.4f)); ModRack(deco, new Vector3(x + 3.4f, 0f, 3.2f), 3.0f); break;
                        case 3: ModBarrel(deco, new Vector3(x, 0f, 2.3f), 1.1f, 1.5f); ModBarrel(deco, new Vector3(x + 1.3f, 0f, 2.6f), 1.1f, 1.5f); ModRack(deco, new Vector3(x + 3f, 0f, 3.2f), 3.4f); break;
                        default: ModSuitcase(deco, new Vector3(x, 0f, 2.4f), 1.6f, 1.0f); ModCrateStack(deco, new Vector3(x + 2.2f, 0f, 2.4f)); break;
                    }
                    ModBulb(deco, new Vector3(x + 1.5f, 3.0f, 1.8f));
                    x += 6.5f + (float)rnd.NextDouble() * 3f; break;
                default: // cuarto de Benito
                    switch (k % 5)
                    {
                        case 0: ModBed(deco, new Vector3(x, 0f, 2.6f)); ModPoster(deco, new Vector3(x + 0.6f, 1.8f, 3.45f), 1.6f, 2.0f, "#7FB6E8", "#FFE066"); break;
                        case 1: ModToyShelf(deco, new Vector3(x, 0f, 3.2f), 3.2f); ModBlockTower(deco, new Vector3(x + 3.2f, 0f, 2.4f)); break;
                        case 2: ModBalloons(deco, new Vector3(x, 0f, 2.4f)); ModBallToy(deco, new Vector3(x + 1.5f, 0f, 2.3f)); ModPoster(deco, new Vector3(x + 3.2f, 1.6f, 3.45f), 1.8f, 2.2f, "#F29EC1", "#FFFFFF"); break;
                        case 3: ModToyShelf(deco, new Vector3(x, 0f, 3.2f), 3.6f); ModBalloons(deco, new Vector3(x + 3.2f, 0f, 2.6f)); break;
                        default: ModBlockTower(deco, new Vector3(x, 0f, 2.4f)); ModBed(deco, new Vector3(x + 3.6f, 0f, 2.7f)); break;
                    }
                    x += 7f + (float)rnd.NextDouble() * 3f; break;
            }
            k++;
        }
    }
}
#endif
