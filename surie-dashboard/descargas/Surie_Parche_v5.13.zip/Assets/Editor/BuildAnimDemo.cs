#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>
/// Menú  Surie ▸ Escena demo de animaciones (FBX de Blender)
/// Toma Assets/Animations/Surie_Animaciones.fbx (el que exporta el script de Blender), crea un Animator Controller
/// con los 5 clips y una escena "Animaciones_Surie" lista para grabar el video entregable.
/// </summary>
public static class BuildAnimDemo
{
    const string Fbx = "Assets/Animations/Surie_Animaciones.fbx";

    static string Short(string n) { int i = n.LastIndexOf('|'); return i >= 0 ? n.Substring(i + 1) : n; }

    [MenuItem("Surie/Escena demo de animaciones (FBX de Blender)")]
    public static void Build()
    {
        try
        {
            var model = AssetDatabase.LoadAssetAtPath<GameObject>(Fbx);
            if (model == null)
            {
                EditorUtility.DisplayDialog("Surie", "No encuentro " + Fbx + ".\n\nCopia el archivo Surie_Animaciones.fbx (lo exporta el script de Blender) dentro de Assets/Animations/ y vuelve a intentarlo.", "OK");
                return;
            }
            // el rig es "Generic" y los clips de bucle se marcan con Loop Time
            var imp = AssetImporter.GetAtPath(Fbx) as ModelImporter;
            if (imp != null)
            {
                imp.animationType = ModelImporterAnimationType.Generic;
                var cas = imp.defaultClipAnimations;
                foreach (var c in cas)
                {
                    string n = Short(c.name);
                    c.name = n;
                    c.loopTime = n == "Idle_Respira" || n == "Caminar";
                }
                imp.clipAnimations = cas;
                imp.SaveAndReimport();
            }
            var clips = new Dictionary<string, AnimationClip>();
            foreach (var o in AssetDatabase.LoadAllAssetsAtPath(Fbx))
            {
                var c = o as AnimationClip;
                if (c != null && !c.name.StartsWith("__preview__")) clips[Short(c.name)] = c;
            }
            if (clips.Count == 0) { EditorUtility.DisplayDialog("Surie", "El FBX no trae animaciones. Vuelve a exportarlo desde Blender (Bake Animation + All Actions).", "OK"); return; }

            string ctrlPath = "Assets/Animations/Surie_Demo.controller";
            var ctrl = AnimatorController.CreateAnimatorControllerAtPath(ctrlPath);
            var sm = ctrl.layers[0].stateMachine;
            string[] order = { "Idle_Respira", "Caminar", "Estirarse_Bostezar", "Buscar", "Tomar_agua" };
            AnimatorState first = null;
            foreach (var n in order)
            {
                if (!clips.ContainsKey(n)) { Debug.LogWarning("[Surie] Falta el clip " + n); continue; }
                var st = sm.AddState(n);
                st.motion = clips[n];
                if (first == null) first = st;
            }
            if (first != null) sm.defaultState = first;

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var camGo = new GameObject("Main Camera"); camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(0.62f, 0.78f, 0.95f);
            camGo.AddComponent<AudioListener>();
            var lg = new GameObject("Luz"); var l = lg.AddComponent<Light>(); l.type = LightType.Directional; l.intensity = 1.2f;
            lg.transform.rotation = Quaternion.Euler(45f, -30f, 0f);
            var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "Piso"; floor.transform.localScale = new Vector3(40f, 0.2f, 12f); floor.transform.position = new Vector3(0f, -0.1f, 0f);

            var inst = (GameObject)PrefabUtility.InstantiatePrefab(model);
            inst.name = "Surie_Animada";
            inst.transform.position = Vector3.zero;
            inst.transform.rotation = Quaternion.Euler(0f, 90f, 0f);      // mira hacia +X
            var an = inst.GetComponent<Animator>();
            if (an == null) an = inst.AddComponent<Animator>();
            an.runtimeAnimatorController = ctrl;
            var demo = inst.AddComponent<SurieAnimDemo>();
            demo.anim = an;

            float h = 1.3f;
            camGo.transform.position = new Vector3(2.2f, h, -5.5f);
            camGo.transform.LookAt(new Vector3(1.4f, 0.7f, 0f));
            Directory.CreateDirectory("Assets/Scenes");
            EditorSceneManager.SaveScene(scene, "Assets/Scenes/Animaciones_Surie.unity");
            EditorUtility.DisplayDialog("Surie", "Escena Assets/Scenes/Animaciones_Surie creada.\n\nDale Play: se queda en Idle y cada pocos segundos hace un gesto. Teclas 1-5 fuerzan cada animación.\nGraba la pantalla para el video.", "OK");
        }
        catch (System.Exception e)
        {
            Debug.LogError("[Surie] " + e);
            EditorUtility.DisplayDialog("Surie · ERROR", e.GetType().Name + ": " + e.Message, "OK");
        }
    }
}
#endif
