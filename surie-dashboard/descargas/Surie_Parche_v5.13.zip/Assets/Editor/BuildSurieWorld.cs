#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>
/// Menú  Surie ▸ Construir mundo y niveles 2-6   (v5)
/// Niveles 2-6 generados por tramos con dificultad creciente y MODELOS 3D en todo (muebles, árboles, inodoros...),
/// peligros con aviso (llamas, goteras, inodoros, ramas, columpios, aspersores, apagón), enemigos que se pueden pisar,
/// perseguidores que salen de una casa/caja, escena de Benito robando el juguete y jefe final.
/// Además: mapa de islas "Mundo_Surie" y escena de minijuegos 3D "Mini_Surie".
/// </summary>
public static partial class BuildSurieLevel
{
    class Theme
    {
        public string title, wallA, wallB, floor, trim, sky, ambient;
        public bool ceiling = true, outdoor, dark;
        public float length, d0;
        public int seed;
        public int[] weights;
        public string[] styles;
        public float chaseFrom = -1f;
        public float chaseSpeed = 2.2f;
        public string chaser = "perro";
        public int[] chaseWeights;
        public string[] story;
        public string climb = "cortina";     // qué se trepa en este nivel: cortina, tuberia, enredadera, red
    }

    // tipos de tramo
    const int T_RUN = 0, T_PIT = 1, T_PUDDLE = 2, T_ROOMBA = 3, T_STAIRS = 4, T_SHELVES = 5, T_TABLE = 6, T_TV = 7, T_MOVING = 8, T_HILL = 9,
              T_RATON = 10, T_MOSCA = 11, T_REST = 12, T_STOVE = 13, T_DRIP = 14, T_TUB = 15, T_CURTAIN = 16, T_TOILET = 17, T_BRANCH = 18,
              T_SWING = 19, T_SPRINK = 20, T_ROACH = 21, T_SPIDER = 22, T_SHELFCLIMB = 23, T_PYRAMID = 24, T_TREEHOUSE = 25, T_CATWALK = 26, T_COUNT = 27;

    static int[] W(params int[] pairs)
    {
        var a = new int[T_COUNT];
        for (int i = 0; i + 1 < pairs.Length; i += 2) a[pairs[i]] = pairs[i + 1];
        return a;
    }

    static Theme[] Themes()
    {
        return new[]
        {
            new Theme { title = "La cocina", wallA = "#F7F0DC", wallB = "#EAF1F5", floor = "#C7D3DA", trim = "#9FB3BF", sky = "#251C3F", ambient = "#A6A6AE", length = 1000f, d0 = 0.2f, seed = 11,
                styles = new[] { "lata", "caja", "libros", "mueble" },
                weights = W(T_RUN, 1, T_PIT, 2, T_PUDDLE, 2, T_ROOMBA, 1, T_STAIRS, 1, T_SHELVES, 2, T_TABLE, 2, T_MOVING, 1, T_RATON, 2, T_MOSCA, 1, T_STOVE, 3, T_DRIP, 2, T_CURTAIN, 2), climb = "tuberia",
                story = new[] { "¡Surie recuperó su juguete en la sala... pero Benito se lo vuelve a quitar!", "BENITO: ¡Jejeje! ¡Ahora está en la cocina! ¡Atrápame!", "Cuidado con las llamas de la estufa y las goteras." } },
            new Theme { title = "El baño y el pasillo", wallA = "#DDF1F3", wallB = "#CFE3EC", floor = "#B5D3DB", trim = "#8BB3BF", sky = "#1E2A45", ambient = "#A4ACB4", length = 1200f, d0 = 0.35f, seed = 22,
                styles = new[] { "toalla", "jabon", "banquito", "caja" },
                weights = W(T_PIT, 2, T_PUDDLE, 1, T_SHELVES, 1, T_MOVING, 2, T_MOSCA, 1, T_RATON, 1, T_DRIP, 2, T_TUB, 3, T_CURTAIN, 3, T_TOILET, 3, T_STAIRS, 2, T_ROACH, 1),
                story = new[] { "Benito escapó de la cocina con el juguete...", "BENITO: ¡Jejeje! ¡Me escondí en el baño!", "Sube por las cortinas, cruza la tina y espera a que los inodoros cierren la tapa." } },
            new Theme { title = "El patio", wallA = "#C6E9F7", wallB = "#D9F1CF", floor = "#78B565", trim = "#5C8F4B", sky = "#7FC8EC", ambient = "#BCC2B4", ceiling = false, outdoor = true, length = 1250f, d0 = 0.45f, seed = 33,
                styles = new[] { "tronco", "piedra", "maceta", "caja" },
                weights = W(T_RUN, 1, T_PIT, 2, T_PUDDLE, 1, T_STAIRS, 2, T_BRANCH, 3, T_SWING, 3, T_SPRINK, 2, T_MOSCA, 2, T_RATON, 1, T_ROACH, 1, T_CURTAIN, 3, T_TREEHOUSE, 1), climb = "enredadera",
                chaseFrom = 690f, chaseSpeed = 2.6f, chaser = "perro", chaseWeights = W(T_RUN, 6, T_PIT, 3, T_PUDDLE, 2, T_HILL, 2, T_STAIRS, 1),
                story = new[] { "Benito salió corriendo al patio con el juguete...", "BENITO: ¡Jejeje! ¡Ni el perro del vecino te salvará!", "Esquiva ramas y aspersores. ¡Y no despiertes al perro!" } },
            new Theme { title = "El sótano", wallA = "#4F4666", wallB = "#40395A", floor = "#6A5A4B", trim = "#8A7767", sky = "#120E1D", ambient = "#7A7890", dark = true, length = 1250f, d0 = 0.6f, seed = 44,
                styles = new[] { "caja", "barril", "libros", "maleta" },
                weights = W(T_PIT, 2, T_ROOMBA, 1, T_STAIRS, 1, T_PYRAMID, 2, T_SHELVES, 1, T_SHELFCLIMB, 3, T_TABLE, 1, T_MOVING, 2, T_ROACH, 3, T_SPIDER, 3, T_RATON, 1, T_DRIP, 1, T_CURTAIN, 3, T_CATWALK, 2), climb = "tuberia",
                story = new[] { "Benito se llevó el juguete a lo más oscuro de la casa...", "BENITO: ¡Jejeje! ¡En el sótano nadie te escucha!", "A veces se va la luz. Cuidado con las cucarachas y las arañas." } },
            new Theme { title = "El cuarto de Benito", wallA = "#F3D9E6", wallB = "#F6E7C9", floor = "#D6B595", trim = "#A88562", sky = "#2A1E3A", ambient = "#AAA2AA", length = 1300f, d0 = 0.8f, seed = 55,
                styles = new[] { "bloque", "lego", "libros", "caja" },
                weights = W(T_PIT, 3, T_MOVING, 3, T_ROOMBA, 2, T_STAIRS, 3, T_SHELVES, 2, T_MOSCA, 1, T_RATON, 2, T_PYRAMID, 1, T_CURTAIN, 3), climb = "red",
                chaseFrom = 640f, chaseSpeed = 2.75f, chaser = "ovillo", chaseWeights = W(T_RUN, 6, T_PIT, 3, T_HILL, 2, T_STAIRS, 1, T_MOVING, 1),
                story = new[] { "Por fin... el cuarto de Benito.", "BENITO: ¡El juguete es MÍO! ¡Ven por él si te atreves!", "Escapa del ovillo gigante y vence a Benito: pisalo cuando se maree." } }
        };
    }

    static void RegisterScenes()
    {
        var list = new List<EditorBuildSettingsScene>();
        string[] names = { "Menu_Surie", "Comic_Surie", "Mundo_Surie", "Nivel_Surie", "Nivel_2_Cocina", "Nivel_3_Bano", "Nivel_4_Patio", "Nivel_5_Sotano", "Nivel_6_Benito", "Mini_Surie" };
        foreach (var n in names)
        {
            string p = "Assets/Scenes/" + n + ".unity";
            if (File.Exists(p)) list.Add(new EditorBuildSettingsScene(p, true));
        }
        EditorBuildSettings.scenes = list.ToArray();
    }

    [MenuItem("Surie/Construir mundo y niveles 2-6")]
    public static void BuildWorld()
    {
        try
        {
            AssetDatabase.Refresh();
            Directory.CreateDirectory("Assets/Scenes");
            var th = Themes();
            string[] sceneNames = { "Nivel_2_Cocina", "Nivel_3_Bano", "Nivel_4_Patio", "Nivel_5_Sotano", "Nivel_6_Benito" };
            for (int i = 0; i < th.Length; i++)
            {
                missingSkins = 0; mats.Clear(); raw = false;
                EditorUtility.DisplayProgressBar("Surie", "Construyendo " + sceneNames[i] + "...", i / (float)(th.Length + 2));
                BuildGenLevel(i + 1, sceneNames[i], th[i]);
            }
            mats.Clear(); raw = false;
            EditorUtility.DisplayProgressBar("Surie", "Construyendo el mapa de islas...", 0.8f);
            BuildWorldScene();
            EditorUtility.DisplayProgressBar("Surie", "Construyendo los minijuegos 3D...", 0.9f);
            BuildMiniScene();
            RegisterScenes();
            var menuAsset = AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/Scenes/Menu_Surie.unity");
            if (menuAsset != null) EditorSceneManager.playModeStartScene = menuAsset;
            AssetDatabase.SaveAssets();
            EditorUtility.ClearProgressBar();
            EditorUtility.DisplayDialog("Surie", "¡Mundo y niveles 2-6 construidos (" + BuildInfo.Patch + ")!\n\nAbre Assets/Scenes/Menu_Surie y pulsa Play.\nJUGAR → historieta → mapa de islas → nivel.", "OK");
        }
        catch (System.Exception e)
        {
            EditorUtility.ClearProgressBar();
            Debug.LogError("[Surie] Error al construir el mundo: " + e);
            EditorUtility.DisplayDialog("Surie · ERROR", e.GetType().Name + ": " + e.Message + "\n\nMándame esta ventana o la línea roja de la consola.", "OK");
        }
    }

    static Mesh StarAsset()
    {
        var m = AssetDatabase.LoadAssetAtPath<Mesh>("Assets/Models/Star.asset");
        if (m == null)
        {
            m = StarMesh(0.3f);
            Directory.CreateDirectory("Assets/Models");
            AssetDatabase.CreateAsset(m, "Assets/Models/Star.asset");
        }
        return m;
    }

    // ------------------------------------------------------------------ contexto del nivel en construcción
    static Theme gT; static System.Random gR; static float gDiff;
    static Transform gGeo, gDeco, gZones, gHaz, gPick;
    static Material gFloorM, gWaterM, gPitM, gCurtainM, gBrownL;
    static float gRunStart; static int gFloorN, gLettersPlaced; static bool gIsLetter;
    static string Sty() { return gT.styles[gR.Next(gT.styles.Length)]; }
    static float Rnd(float a, float b) { return a + (float)gR.NextDouble() * (b - a); }

    static void CloseFloor(float end)
    {
        if (end - gRunStart > 0.5f) Box("Piso_" + (gFloorN++), gRunStart, end, -3f, 0f, gFloorM, gGeo, true, D + 0.6f);
    }

    static void PitAt(float a, float b)
    {
        Trigger("Zona_Foso", a, b, -9f, -2f, gZones, ZoneType.Fall, 3f);
        Box("Foso_Fondo", a, b, -9f, -8f, gPitM, gDeco, false, 2f);
    }

    static GameObject MovingPlat(string name, float xcm, float wcm, float y0cm, float y1cm, string style, Vector3 amp, float period, float phase)
    {
        var g = new GameObject(name);
        g.transform.SetParent(gHaz, false);
        g.transform.position = new Vector3(xcm * S, (y0cm + y1cm) * 0.5f * S, 0f);
        var bc = g.AddComponent<BoxCollider>();
        bc.size = new Vector3(wcm * S, (y1cm - y0cm) * S, D);
        BuildStyle(style, g.transform, new Vector3(xcm * S, y0cm * S, 0f), wcm * S, (y1cm - y0cm) * S);
        g.AddComponent<Rigidbody>().isKinematic = true;
        var sp = g.AddComponent<SlidePlatform>();
        sp.amplitude = amp; sp.period = period; sp.phase = phase;
        return g;
    }

    static GameObject Zone2(string name, Vector3 center, Vector3 size, Transform parent)
    {
        var g = new GameObject(name);
        g.transform.SetParent(parent, false);
        g.transform.position = center;
        var bc = g.AddComponent<BoxCollider>();
        bc.isTrigger = true; bc.size = size;
        return g;
    }

    static GameObject Marker(Vector3 pos, float d, string hex)
    {
        var m = Pm(CY, "Marca_Suelo", gDeco, pos.x, 0.03f, 0f, d, 0.01f, d, hex);
        return m;
    }

    // ------------------------------------------------------------------ SEGMENTOS (devuelven el ancho en cm)
    static int gSpecial;
    static bool gChase, gChasePot;
    static Chaser gYarn;
    static float S_Run(float x0, int seg)
    {
        float w = 16f + Rnd(0f, 10f);
        for (float cx = x0 + 4f; cx < x0 + w - 2f; cx += 8f) Croqueta(cx, 0.8f, gPick);
        if (gChase)
        {
            // obstáculos que el perseguidor destruye al pasar
            int n = w > 21f ? 2 : 1;
            for (int i = 0; i < n; i++)
            {
                float cx = x0 + 6f + i * 10f;
                var col = Box("Obstaculo_Rompible", cx - 1.6f, cx + 1.6f, 0f, 4f, Cm("#C8935A"), gGeo);
                col.GetComponent<Renderer>().enabled = false;
                Transform vis = gChasePot ? ModPot(gDeco, new Vector3(cx * S, 0f, 0f), 0.55f, 0.6f) : ModCrate(gDeco, new Vector3(cx * S, 0f, 0f), 0.5f, 0.6f);
                col.AddComponent<Smashable>().visual = vis;
            }
        }
        return w;
    }

    static float S_Pit(float x0, int seg)
    {
        bool needDash = gR.NextDouble() < 0.15f + 0.6f * gDiff;
        float pw = needDash ? 10.5f + Rnd(0f, 2.5f) : 5f + Rnd(0f, 1.4f);
        float pre = 14f;
        Checkpoint("CP_Foso" + seg, x0 + 3f, 0f, gZones);
        Croqueta(x0 + 8f, 0.8f, gPick); if (needDash) Croqueta(x0 + 12f, 0.8f, gPick);
        float a = x0 + pre;
        CloseFloor(a);
        PitAt(a, a + pw);
        gRunStart = a + pw;
        Croqueta(a + pw * 0.5f, 6f, gPick);
        MakeText(needDash ? "SHIFT" : "SALTA", gDeco, new Vector3((a - 4f) * S, 8f * S, -0.62f), 0.05f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return pre + pw + 8f;
    }

    static float S_Puddle(float x0, int seg)
    {
        float pw = 5f + Rnd(0f, 1.2f);
        float a = x0 + 10f;
        Box("Agua", a, a + pw, 0f, 0.5f, gWaterM, gDeco, false, D);
        Pm(SP, "Brillo", gDeco, (a + pw * 0.5f) * S, 0.08f, -0.2f, pw * S * 0.6f, 0.02f, 0.4f, "#CFEFFF");
        Trigger("Zona_Agua", a, a + pw, 0f, 3f, gZones, ZoneType.Water);
        Croqueta(a + pw * 0.5f, 5.5f, gPick);
        return 10f + pw + 8f;
    }

    static float S_Roomba(float x0, int seg)
    {
        float L = 40f, sp = 1.4f + 1.4f * gDiff;
        MakeRoomba("Roomba_" + seg, x0 + L * 0.5f, x0 + 4f, x0 + L - 4f, sp, Cm("#555555"), gHaz);
        Box("Estante_N", x0 + 13f, x0 + 27f, 5f, 5.6f, Cm("#A0714F"), gGeo);
        Plat("Estante_S1_" + seg, x0 + 14f, x0 + 14.8f, 0f, 5f, "repisa", gGeo, gDeco);
        Plat("Estante_S2_" + seg, x0 + 26.2f, x0 + 27f, 0f, 5f, "repisa", gGeo, gDeco);
        Croqueta(x0 + 18f, 5.6f, gPick); Croqueta(x0 + 23f, 5.6f, gPick);
        MakeText("ROOMBA", gDeco, new Vector3((x0 + 8f) * S, 9.5f * S, -0.62f), 0.05f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return L;
    }

    static float S_Stairs(float x0, int seg)
    {
        float[] hs = { 3f, 5.5f, 3f };
        string st = Sty();
        for (int i = 0; i < 3; i++)
        {
            Plat("Escalon_" + seg + "_" + i, x0 + 6f + i * 12f, x0 + 12f + i * 12f, 0f, hs[i], st, gGeo, gDeco);
            Croqueta(x0 + 9f + i * 12f, hs[i] + 0.6f, gPick);
        }
        return 6f + 36f + 4f;
    }

    static float S_Shelves(float x0, int seg)
    {
        float[] hs = { 4f, 6.5f, 4.5f };
        float a = x0 + 8f, total = 3 * 6f + 2 * 5.5f;
        Box("Agua", a - 2f, a + total + 2f, 0f, 0.5f, gWaterM, gDeco, false, D);
        Trigger("Zona_Agua", a - 2f, a + total + 2f, 0f, 3f, gZones, ZoneType.Water);
        for (int i = 0; i < 3; i++)
        {
            float sx = a + i * 11.5f;
            Plat("Repisa_" + seg + "_" + i, sx, sx + 6f, hs[i] - 0.8f, hs[i], "repisa", gGeo, gDeco);
            Croqueta(sx + 3f, hs[i] + 0.6f, gPick);
        }
        return 8f + total + 8f;
    }

    static float S_Table(float x0, int seg)
    {
        float a = x0 + 8f;
        Box("Mesa_Tapa", a, a + 14f, 3.6f, 4.4f, Cm("#7A4E2D"), gGeo);
        Box("Mesa_Pata1", a + 0.4f, a + 1.2f, 0f, 3.6f, Cm("#7A4E2D"), gGeo);
        Box("Mesa_Pata2", a + 12.8f, a + 13.6f, 0f, 3.6f, Cm("#7A4E2D"), gGeo);
        var vg = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        vg.name = "Jarron";
        vg.transform.SetParent(gHaz, false);
        vg.transform.position = new Vector3((a + 8f) * S, 4.4f * S + 0.24f, 0f);
        vg.transform.localScale = new Vector3(0.26f, 0.24f, 0.26f);
        vg.GetComponent<Renderer>().sharedMaterial = Cm("#3B6FB5");
        Skin(vg, "jarron", true);
        vg.AddComponent<Rigidbody>();
        vg.AddComponent<Jarron>();
        Croqueta(a + 3f, 5f, gPick);
        return 8f + 14f + 8f;
    }

    static float S_TV(float x0, int seg)
    {
        float L = 32f;
        Trigger("Zona_Ruido_TV", x0 + 4f, x0 + L, 0f, 24f, gZones, ZoneType.Noise);
        Box("TV_Marco", x0 + 8f, x0 + 24f, 9f, 17f, Cm("#1F2328"), gDeco, false, 0.1f, 1.4f);
        MakeText("¡RUIDO!", gDeco, new Vector3((x0 + 16f) * S, 13f * S, 1.34f), 0.1f, new Color(0.75f, 0.1f, 0.1f), 64);
        for (float cx = x0 + 6f; cx < x0 + L - 2f; cx += 9f) Croqueta(cx, 0.8f, gPick);
        return L + 4f;
    }

    static float S_Moving(float x0, int seg)
    {
        float pw = 16f, a = x0 + 12f;
        Checkpoint("CP_Mov" + seg, x0 + 4f, 0f, gZones);
        CloseFloor(a);
        PitAt(a, a + pw);
        gRunStart = a + pw;
        MovingPlat("Plataforma_Movil", a + pw * 0.5f, 6f, -0.8f, 0.6f, Sty(), new Vector3(5f * S, 0f, 0f), 3.6f - 0.8f * gDiff, 0f);
        Croqueta(a + pw * 0.5f, 3f, gPick);
        return 12f + pw + 8f;
    }

    static float S_Hill(float x0, int seg)
    {
        float a = x0 + 6f;
        string st = Sty();
        Plat("Colina_A" + seg, a, a + 6f, 0f, 3.5f, st, gGeo, gDeco);
        Plat("Colina_B" + seg, a + 8f, a + 14f, 0f, 7f, st, gGeo, gDeco);
        Plat("Colina_C" + seg, a + 16f, a + 22f, 0f, 3.5f, st, gGeo, gDeco);
        if (gIsLetter) { Letter(gLettersPlaced, a + 11f, 7f, gPick); gLettersPlaced++; }
        else Croqueta(a + 11f, 7.8f, gPick);
        return 6f + 22f + 6f;
    }

    static float S_Raton(float x0, int seg)
    {
        float L = 34f;
        MakeEnemy(Enemy.Kind.Raton, x0 + L * 0.5f, 0f, x0 + 5f, x0 + L - 5f, 1.1f + 0.9f * gDiff, gHaz);
        Croqueta(x0 + 8f, 0.8f, gPick);
        MakeText("¡PÍSALO desde arriba o usa SHIFT!", gDeco, new Vector3((x0 + 17f) * S, 10f * S, -0.62f), 0.04f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return L;
    }

    static float S_Mosca(float x0, int seg)
    {
        float L = 34f;
        MakeEnemy(Enemy.Kind.Mosca, x0 + L * 0.5f, 6.2f, x0 + 6f, x0 + L - 6f, 1.3f + 0.9f * gDiff, gHaz);
        Croqueta(x0 + 6f, 0.8f, gPick); Croqueta(x0 + L - 6f, 0.8f, gPick);
        return L;
    }

    static float S_Rest(float x0, int seg)
    {
        float a = x0 + 6f;
        Box("Cojin_N1", a, a + 6f, 0f, 3.5f, Cm("#B98A66"), gGeo);
        Trigger("Descanso_" + seg, a, a + 6f, 3f, 8f, gZones, ZoneType.Rest);
        Checkpoint("CP_Descanso" + seg, a + 3f, 3.5f, gZones);
        Croqueta(a + 10f, 0.8f, gPick); Croqueta(a + 14f, 0.8f, gPick);
        return 6f + 6f + 12f;
    }

    static float S_Stove(float x0, int seg)
    {
        float a = x0 + 6f, wd = 30f, h = 4f;
        Checkpoint("CP_Estufa" + seg, x0 + 3f, 0f, gZones);
        var blk = Box("Estufa_Bloque", a, a + wd, 0f, h, Cm("#9AA3AB"), gGeo);
        blk.GetComponent<Renderer>().enabled = false;
        ModStove(gDeco, new Vector3((a + wd * 0.5f) * S, 0f, 0f), wd * S, h * S);
        for (int i = 0; i < 3; i++)
        {
            float bx = a + 5f + i * 10f;
            Vector3 wp = new Vector3(bx * S, h * S, 0f);
            Transform fl;
            ModBurner(gDeco, wp, out fl);
            var hz = Zone2("Llama_" + i, wp + new Vector3(0f, 0.45f, 0f), new Vector3(0.55f, 0.9f, 1.0f), gHaz);
            var th = hz.AddComponent<TimedHazard>();
            th.onTime = 1.4f; th.offTime = 2.2f; th.warnTime = 0.6f; th.phase = i * 1.2f; th.fx = fl;
            th.message = "¡Te quemaste con la llama! +1 estrés";
        }
        Croqueta(a + 10f, h + 0.9f, gPick); Croqueta(a + 20f, h + 0.9f, gPick);
        MakeText("¡FUEGO!", gDeco, new Vector3((a + 3f) * S, 9f * S, -0.62f), 0.06f, new Color(0.75f, 0.2f, 0.1f), 48, true);
        return 6f + wd + 6f;
    }

    static float S_Drip(float x0, int seg)
    {
        float a = x0 + 6f;
        Checkpoint("CP_Gotera" + seg, x0 + 3f, 0f, gZones);
        Pm(CY, "TuboGotera", gDeco, (a + 12f) * S, 3.45f, 0.3f, 0.12f, 14f * S, 0.12f, "#7B8088", 0f, 0f, 90f);
        for (int i = 0; i < 3; i++)
        {
            float dx = a + 4f + i * 9f;
            Pm(CY, "Grifo", gDeco, dx * S, 3.3f, 0.3f, 0.1f, 0.12f, 0.1f, "#8E959C");
            var drop = Pm(SP, "Gota", gHaz, dx * S, 2.9f, 0f, 0.24f, 0.34f, 0.24f, "#4FA3E0");
            var mk = Marker(new Vector3(dx * S, 0f, 0f), 0.7f, "#2F6FA8");
            var fh = drop.AddComponent<FallingHazard>();
            fh.obj = drop.transform; fh.marker = mk.transform; fh.groundY = 0.12f; fh.radius = 0.6f; fh.interval = 2.0f; fh.warn = 0.7f; fh.phase = i * 0.7f; fh.activeRange = 14f;
            fh.message = "¡Una gota helada! +1 estrés";
        }
        for (float cx = a + 2f; cx < a + 28f; cx += 8f) Croqueta(cx, 0.8f, gPick);
        MakeText("GOTERAS", gDeco, new Vector3((a + 12f) * S, 10f * S, -0.62f), 0.055f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return 6f + 28f + 6f;
    }

    static void TubWall(string name, float x0, float x1, float h)
    {
        var b = Box(name, x0, x1, 0f, h, Cm("#F4F7F8"), gGeo);
        b.GetComponent<Renderer>().enabled = false;
        float w = (x1 - x0) * S, hh = h * S;
        Vector3 p = new Vector3((x0 + x1) * 0.5f * S, 0f, 0f);
        var r = Root("TinaPared3D", gDeco, p);
        Pm(CU, "Cuerpo", r, 0, hh * 0.5f, 0, w, hh, 1.1f, "#F4F7F8");
        Pm(CU, "Borde", r, 0, hh - 0.04f, 0, w + 0.06f, 0.1f, 1.18f, "#E2E8EC");
        Pm(CU, "Base", r, 0, 0.05f, 0, w + 0.04f, 0.1f, 1.12f, "#D9C27A");
    }

    static float S_Tub(float x0, int seg)
    {
        float a = x0 + 8f;
        Checkpoint("CP_Tina" + seg, x0 + 3f, 0f, gZones);
        TubWall("TinaPared_I", a, a + 4f, 5f);
        TubWall("TinaPared_D", a + 26f, a + 30f, 5f);
        Box("Agua_Tina", a + 4f, a + 26f, 0f, 2.6f, Cm("#5DB6E8"), gDeco, false, 1.1f);
        Pm(CY, "Espuma", gDeco, (a + 15f) * S, 2.6f * S + 0.01f, -0.3f, 22f * S * 0.9f, 0.01f, 0.35f, "#EAF7FF", 0f, 0f, 90f).transform.localRotation = Quaternion.identity;
        for (int i = 0; i < 6; i++) Pm(SP, "Burbuja", gDeco, (a + 5f + i * 3.6f) * S, 2.6f * S + 0.05f, -0.45f + (i % 2) * 0.25f, 0.22f, 0.18f, 0.22f, "#FFFFFF");
        Trigger("Zona_Agua_Tina", a + 4f, a + 26f, 0f, 3.0f, gZones, ZoneType.Water);
        float[] duckX = { a + 10f, a + 20f };
        for (int i = 0; i < 2; i++)
        {
            var dk = new GameObject("Pato_" + i);
            dk.transform.SetParent(gHaz, false);
            float topY = 4.2f * S;
            dk.transform.position = new Vector3(duckX[i] * S, topY - 0.06f, 0f);
            var bc = dk.AddComponent<BoxCollider>(); bc.size = new Vector3(0.85f, 0.12f, D);
            var duck = ModDuck(dk.transform, new Vector3(duckX[i] * S, topY - 0.6f, 0f));
            dk.AddComponent<Rigidbody>().isKinematic = true;
            var sp = dk.AddComponent<SlidePlatform>();
            sp.amplitude = new Vector3(0f, 0.14f, 0f); sp.period = 2.2f; sp.phase = i * 0.5f;
            Croqueta(duckX[i], 4.2f + 0.8f, gPick);
        }
        Pm(CY, "Grifo", gDeco, (a + 2f) * S, 5f * S + 0.35f, 0.3f, 0.12f, 0.3f, 0.12f, "#D9C27A");
        MakeText("TINA", gDeco, new Vector3((a + 15f) * S, 9.5f * S, -0.62f), 0.06f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return 8f + 30f + 8f;
    }

    static float S_Toilet(float x0, int seg)
    {
        int count = 2;
        float w = 8f;
        for (int i = 0; i < count; i++)
        {
            float a = x0 + 8f + i * 20f;
            Checkpoint("CP_Inodoro" + seg + "_" + i, a - 3f, 0f, gZones);
            var slab = Box("Inodoro_Taza", a, a + 6f, 0f, 3.3f, Cm("#F2F4F5"), gGeo); slab.GetComponent<Renderer>().enabled = false;
            var tank = Box("Inodoro_Tanque", a + 6f, a + 9f, 0f, 6.5f, Cm("#F2F4F5"), gGeo); tank.GetComponent<Renderer>().enabled = false;
            Transform lid, water;
            ModToilet(gDeco, new Vector3((a + 3f) * S, 0f, 0f), out lid, out water);
            var hz = Zone2("Inodoro_Peligro_" + i, new Vector3((a + 3f) * S, 3.3f * S + 0.45f, 0f), new Vector3(0.8f, 0.9f, 1.0f), gHaz);
            var th = hz.AddComponent<TimedHazard>();
            th.onTime = 1.7f; th.offTime = 3.0f; th.warnTime = 0.7f; th.phase = i * 2.3f; th.lid = lid; th.fx = water;
            th.message = "¡Splash! El inodoro se abrió +1 estrés";
            Croqueta(a + 3f, 3.3f + 0.9f, gPick); Croqueta(a + 7.5f, 6.5f + 0.9f, gPick);
            w = 8f + i * 20f + 9f + 10f;
        }
        MakeText("¡ESPERA A QUE CIERRE!", gDeco, new Vector3((x0 + 16f) * S, 12f * S, -0.62f), 0.045f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return w;
    }

    static float S_Curtain(float x0, int seg)
    {
        float a = x0 + 6f;
        Checkpoint("CP_Cortina" + seg, x0 + 3f, 0f, gZones);
        ClimbVisual(gT.climb, a, a + 3f, 18.8f);
        Trigger("Zona_Cortina_Trepar_" + seg, a, a + 3f, 0f, 18.2f, gZones, ZoneType.Climb);
        Plat("Armario_" + seg, a + 6f, a + 12f, 0f, 13.5f, gT.outdoor ? "tronco" : "caja", gGeo, gDeco);
        Croqueta(a + 9f, 14.4f, gPick);
        Croqueta(a + 1.5f, 9f, gPick);
        MakeText(gT.climb == "cortina" ? "¡SUBE con W!" : "¡TREPA con W!", gDeco, new Vector3((a - 5f) * S, 9f * S, -0.62f), 0.05f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return 6f + 12f + 10f;
    }

    // ------------------------------------------------------------------ cosas para trepar (visual; la zona Climb va aparte)
    static void ClimbVisual(string kind, float x0, float x1, float top)
    {
        float cx = (x0 + x1) * 0.5f * S, w = (x1 - x0) * S, h = top * S, z = 0.45f;
        var r = Root("Trepar_" + kind, gDeco, new Vector3(cx, 0f, z));
        switch (kind)
        {
            case "tuberia":
                Pm(CY, "Tubo", r, 0, h * 0.5f, 0, 0.2f, h * 0.5f, 0.2f, "#8E959C");
                Pm(CY, "Tubo2", r, 0.22f, h * 0.5f, 0.05f, 0.09f, h * 0.5f, 0.09f, "#B5651D");
                for (float y = 0.3f; y < h; y += 0.55f) { Pm(CY, "Abrazadera", r, 0, y, 0, 0.27f, 0.04f, 0.27f, "#5F666D"); Pm(CU, "Agarre", r, 0, y + 0.2f, -0.05f, w * 0.9f, 0.05f, 0.06f, "#D9A441"); }
                Pm(CY, "Codo", r, 0.25f, h, 0, 0.2f, 0.3f, 0.2f, "#8E959C", 0f, 0f, 90f);
                break;
            case "enredadera":
                Pm(CU, "Celosia", r, 0, h * 0.5f, 0.06f, w, h, 0.04f, "#B98B5E");
                for (float y = 0.25f; y < h; y += 0.4f) Pm(CU, "Liston", r, 0, y, 0.02f, w + 0.06f, 0.05f, 0.05f, "#8C5F3E");
                Pm(CY, "Tallo", r, -0.08f, h * 0.5f, -0.03f, 0.07f, h * 0.5f, 0.07f, "#3F8F4A", 0f, 0f, 3f);
                Pm(CY, "Tallo2", r, 0.1f, h * 0.45f, -0.03f, 0.05f, h * 0.45f, 0.05f, "#4BA057", 0f, 0f, -4f);
                for (int i = 0; i < 16; i++) Pm(SP, "Hoja", r, Rf(-w * 0.5f, w * 0.5f), Rf(0.15f, h), -0.06f, 0.2f, 0.13f, 0.06f, Pal("#4BA057", "#3F8F4A", "#58B063"), 0f, 0f, Rf(-40f, 40f));
                for (int i = 0; i < 4; i++) Pm(SP, "Flor", r, Rf(-w * 0.4f, w * 0.4f), Rf(0.4f, h), -0.09f, 0.13f, 0.13f, 0.06f, Pal("#F25C7A", "#F7D154", "#FFFFFF"));
                break;
            case "red":
                for (int i = 0; i <= 3; i++) Pm(CY, "Cuerda_V", r, -w * 0.5f + i * w / 3f, h * 0.5f, 0, 0.045f, h * 0.5f, 0.045f, "#E0C48A");
                for (float y = 0.2f; y < h; y += 0.3f) Pm(CY, "Cuerda_H", r, 0, y, 0, 0.04f, w * 0.5f, 0.04f, "#D2B271", 0f, 0f, 90f);
                Pm(CY, "Barra", r, 0, h + 0.03f, 0, 0.09f, w * 0.5f + 0.1f, 0.09f, "#E25B5B", 0f, 0f, 90f);
                break;
            case "escalera":
                Pm(CU, "Larguero_I", r, -w * 0.5f, h * 0.5f, 0, 0.08f, h, 0.08f, "#8C5F3E");
                Pm(CU, "Larguero_D", r, w * 0.5f, h * 0.5f, 0, 0.08f, h, 0.08f, "#8C5F3E");
                for (float y = 0.2f; y < h; y += 0.26f) Pm(CU, "Peldano", r, 0, y, 0, w, 0.06f, 0.1f, "#B98B5E");
                break;
            default:    // cortina
                Box("Cortina", x0, x1, 0.25f, top, gCurtainM, gDeco, false, 0.12f, 0.45f);
                Box("Cortina_Barra", x0 - 0.6f, x1 + 0.6f, top, top + 0.4f, gBrownL, gDeco, false, 0.1f, 0.45f);
                break;
        }
    }

    static GameObject Solid(string name, float x0, float x1, float y0, float y1)
    {
        var b = Box(name, x0, x1, y0, y1, Cm("#999999"), gGeo, true, D);
        b.GetComponent<Renderer>().enabled = false;
        return b;
    }

    // ------------------------------------------------------------------ CASITA DEL ÁRBOL (patio): se sube por la escalera, se explora por dentro y se cruza un puente colgante
    static float S_TreeHouse(float x0, int seg)
    {
        float a = x0 + 6f, dk = 10f;                       // dk = altura del piso de la casita
        Checkpoint("CP_Casita" + seg, x0 + 3f, 0f, gZones);
        // árboles que la sostienen (fondo)
        ModTree(gDeco, new Vector3((a + 21f) * S, 0f, 1.5f), 10f);
        ModTree(gDeco, new Vector3((a + 54f) * S, 0f, 1.5f), 8f);
        // escalera
        ClimbVisual("escalera", a, a + 3f, dk + 3.5f);
        Trigger("Zona_Escalera_Casita_" + seg, a, a + 3f, 0f, dk + 4.5f, gZones, ZoneType.Climb);
        // plataforma principal
        Solid("Casita_Piso", a + 5f, a + 36f, dk - 1f, dk);
        var r = Root("Casita3D", gDeco, new Vector3(0f, 0f, 0f));
        float px0 = (a + 5f) * S, px1 = (a + 36f) * S, py = dk * S;
        for (float x = px0; x < px1 - 0.01f; x += 0.3f) Pm(CU, "Tabla", r, x + 0.15f, py - 0.06f, 0f, 0.28f, 0.12f, D + 0.3f, Pal("#B07D48", "#9A6B3C", "#A87343"));
        Pm(CU, "Viga", r, (px0 + px1) * 0.5f, py - 0.17f, 0.55f, px1 - px0, 0.12f, 0.12f, "#6B4423");
        foreach (float sx in new[] { a + 6f, a + 34f }) Pm(CY, "Poste", r, sx * S, py * 0.5f - 0.08f, 0.6f, 0.14f, py * 0.5f - 0.08f, 0.14f, "#6B4423");
        Pm(CY, "Puntal", r, (a + 13f) * S, py * 0.55f, 0.75f, 0.1f, py * 0.6f, 0.1f, "#6B4423", 0f, 0f, 35f);
        Pm(CY, "Puntal", r, (a + 29f) * S, py * 0.55f, 0.75f, 0.1f, py * 0.6f, 0.1f, "#6B4423", 0f, 0f, -35f);
        // barandal del balcón (izquierda de la casita)
        for (float x = a + 6f; x < a + 12f; x += 2f) Pm(CU, "Baranda_Poste", r, x * S, py + 0.22f, 0.62f, 0.05f, 0.44f, 0.05f, "#8C5F3E");
        Pm(CU, "Baranda", r, (a + 8.5f) * S, py + 0.44f, 0.62f, 6f * S, 0.05f, 0.05f, "#8C5F3E");
        // la casita (vista en corte: pared del fondo, marcos laterales y techo)
        float hx0 = (a + 12f) * S, hx1 = (a + 31f) * S, hw = hx1 - hx0, wallTop = 19.6f * S;
        Pm(CU, "Pared_Fondo", r, (hx0 + hx1) * 0.5f, (py + wallTop) * 0.5f, 0.66f, hw, wallTop - py, 0.06f, "#D9A766");
        for (float y = py + 0.18f; y < wallTop; y += 0.3f) Pm(CU, "Junta", r, (hx0 + hx1) * 0.5f, y, 0.62f, hw, 0.015f, 0.02f, "#B98B5E");
        Pm(CU, "Ventana", r, hx0 + hw * 0.3f, py + 0.75f, 0.6f, 0.55f, 0.5f, 0.03f, "#9FD8F5");
        Pm(CU, "Ventana_Cruz1", r, hx0 + hw * 0.3f, py + 0.75f, 0.58f, 0.57f, 0.04f, 0.02f, "#FFFFFF");
        Pm(CU, "Ventana_Cruz2", r, hx0 + hw * 0.3f, py + 0.75f, 0.58f, 0.04f, 0.52f, 0.02f, "#FFFFFF");
        Pm(CU, "Dibujo", r, hx0 + hw * 0.62f, py + 0.5f, 0.6f, 0.36f, 0.28f, 0.02f, "#FFF6DA");
        Pm(SP, "Dibujo_Sol", r, hx0 + hw * 0.62f, py + 0.52f, 0.58f, 0.14f, 0.14f, 0.02f, "#F7C623");
        // marcos de las puertas (solo la parte de arriba: Surie pasa por abajo)
        Pm(CU, "Marco_I", r, hx0, (py + 0.75f + wallTop) * 0.5f, 0f, 0.08f, wallTop - py - 0.75f, D + 0.2f, "#C8935A");
        Pm(CU, "Marco_D", r, hx1, (py + 0.75f + wallTop) * 0.5f, 0f, 0.08f, wallTop - py - 0.75f, D + 0.2f, "#C8935A");
        Pm(CU, "Techo_I", r, hx0 + hw * 0.25f - 0.05f, wallTop + 0.3f, 0f, hw * 0.58f, 0.1f, D + 0.7f, "#C0504D", 0f, 0f, 22f);
        Pm(CU, "Techo_D", r, hx1 - hw * 0.25f + 0.05f, wallTop + 0.3f, 0f, hw * 0.58f, 0.1f, D + 0.7f, "#B24642", 0f, 0f, -22f);
        Pm(CU, "Banderin_Asta", r, hx0 + hw * 0.5f, wallTop + 0.95f, 0f, 0.04f, 0.6f, 0.04f, "#8C5F3E");
        Pm(CU, "Banderin", r, hx0 + hw * 0.5f + 0.18f, wallTop + 1.12f, 0f, 0.34f, 0.2f, 0.02f, "#F7D154");
        Pm(SP, "Farol", r, hx0 + hw * 0.5f, wallTop - 0.25f, 0.3f, 0.2f, 0.26f, 0.2f, "#FFE680");
        Pm(CY, "Farol_Cuerda", r, hx0 + hw * 0.5f, wallTop - 0.07f, 0.3f, 0.02f, 0.08f, 0.02f, "#5E3A20");
        // altillo dentro de la casita (se sube por una escalerita)
        float loft = 15.4f;
        ClimbVisual("escalera", a + 15.5f, a + 18f, loft + 1.2f);
        Trigger("Zona_Escalera_Altillo_" + seg, a + 15.5f, a + 18f, dk, loft + 3.2f, gZones, ZoneType.Climb);
        Solid("Casita_Altillo", a + 20.5f, a + 31f, loft - 0.8f, loft);
        Pm(CU, "Altillo", r, (a + 25.75f) * S, loft * S - 0.06f, 0f, 10.5f * S, 0.12f, D + 0.1f, "#B07D48");
        ModCushion(gDeco, new Vector3((a + 27.5f) * S, loft * S, 0.25f), 0.7f, 0.16f);
        Trigger("Zona_Descanso_Casita_" + seg, a + 24f, a + 31f, loft, loft + 3.5f, gZones, ZoneType.Rest);
        for (float cx = a + 22f; cx < a + 31f; cx += 3f) Croqueta(cx, loft + 0.8f, gPick);
        // dentro, abajo: caja de juguetes y croquetas
        ModCrate(gDeco, new Vector3((a + 28.5f) * S, py, 0.4f), 0.4f, 0.32f);
        Pm(SP, "Pelota", gDeco, (a + 26f) * S, py + 0.12f, 0.35f, 0.24f, 0.24f, 0.24f, "#E8605A");
        for (float cx = a + 8f; cx < a + 35f; cx += 5f) Croqueta(cx, dk + 0.8f, gPick);
        // puente colgante
        float b0 = a + 36f, b1 = a + 50f;
        Solid("Puente_Colgante", b0, b1, dk - 0.8f, dk);
        for (float x = b0 + 0.6f; x < b1; x += 1.3f)
        {
            float sag = 0.07f * Mathf.Sin((x - b0) / (b1 - b0) * Mathf.PI);
            Pm(CU, "Puente_Tabla", r, x * S, py - 0.05f - sag * 0.3f, 0f, 0.16f, 0.06f, D + 0.1f, Pal("#B07D48", "#9A6B3C"));
            Pm(CY, "Puente_Tirante", r, x * S, py + 0.22f - sag, 0.6f, 0.02f, 0.24f, 0.02f, "#E0C48A");
        }
        Pm(CY, "Puente_Cuerda", r, (b0 + b1) * 0.5f * S, py + 0.44f, 0.6f, 0.03f, (b1 - b0) * 0.5f * S, 0.03f, "#E0C48A", 0f, 0f, 90f);
        Pm(CY, "Puente_Cuerda2", r, (b0 + b1) * 0.5f * S, py - 0.1f, 0.6f, 0.03f, (b1 - b0) * 0.5f * S, 0.03f, "#C9AA6E", 0f, 0f, 90f);
        for (float cx = b0 + 3f; cx < b1; cx += 4f) Croqueta(cx, dk + 0.8f, gPick);
        // mirador en el segundo árbol
        Solid("Mirador", b1, b1 + 8f, dk - 1f, dk);
        Pm(CY, "Mirador_Piso", r, (b1 + 4f) * S, py - 0.07f, 0f, 8f * S + 0.1f, 0.07f, D + 0.5f, "#A87343");
        Pm(CY, "Mirador_Poste", r, (b1 + 4f) * S, py * 0.5f - 0.07f, 0.65f, 0.18f, py * 0.5f - 0.07f, 0.18f, "#6B4423");
        Croqueta(b1 + 4f, dk + 2.5f, gPick);
        // bajada
        Plat("Tocon_Bajada_" + seg, b1 + 10f, b1 + 14f, 0f, 5f, "tronco", gGeo, gDeco);
        // por abajo también se puede pasar, pero hay enemigos
        MakeEnemy(Enemy.Kind.Raton, a + 14f, 0f, a + 6f, a + 30f, 1.6f + 0.8f * gDiff, gHaz);
        MakeEnemy(Enemy.Kind.Cucaracha, a + 42f, 0f, a + 32f, a + 56f, 1.8f + 0.8f * gDiff, gHaz);
        MakeText("CASITA DEL ÁRBOL\nsube con W", gDeco, new Vector3((a - 4f) * S, 7f * S, -0.62f), 0.045f, new Color(0.17f, 0.3f, 0.12f), 48, true);
        return 6f + 64f + 8f;
    }

    // ------------------------------------------------------------------ PASARELAS del sótano: dos rutas (arriba por la tubería, abajo con bichos) y un montacargas
    static float S_Catwalk(float x0, int seg)
    {
        float a = x0 + 6f, top = 12f;
        Checkpoint("CP_Pasarela" + seg, x0 + 3f, 0f, gZones);
        ClimbVisual("tuberia", a, a + 3f, top + 5f);
        Trigger("Zona_Tuberia_Trepar_" + seg, a, a + 3f, 0f, top + 5f, gZones, ZoneType.Climb);
        Plat("Pasarela_A_" + seg, a + 5f, a + 20f, top - 1f, top, "repisa", gGeo, gDeco);
        Plat("Pasarela_B_" + seg, a + 25f, a + 40f, top - 1f, top, "repisa", gGeo, gDeco);
        for (float cx = a + 7f; cx < a + 40f; cx += 4.5f) if (cx < a + 20f || cx > a + 25f) Croqueta(cx, top + 0.8f, gPick);
        MakeEnemy(Enemy.Kind.Mosca, a + 22f, top + 4f, a + 8f, a + 38f, 1.4f + 0.6f * gDiff, gHaz);
        // cadenas que "cuelgan" las pasarelas del techo
        foreach (float cx in new[] { a + 5f, a + 18.5f, a + 26.5f, a + 38.5f })
            Pm(CY, "Cadena", gDeco, cx * S, (top + 20.5f) * 0.5f * S, 0.5f, 0.04f, (20.5f - top) * 0.5f * S, 0.04f, "#9AA3AB");
        // montacargas (sube y baja): único paso para cruzar el muro de cajas
        MovingPlat("Montacargas_" + seg, a + 45f, 6f, 7.5f, 8.5f, "caja", new Vector3(0f, 4f * S, 0f), 5.2f, 0.25f);
        Pm(CU, "Riel_Montacargas", gDeco, (a + 45f) * S, 10f * S, 0.62f, 0.12f, 20f * S, 0.08f, "#5F666D");
        Plat("Muro_Cajas_" + seg, a + 50f, a + 58f, 0f, top, "caja", gGeo, gDeco);
        Croqueta(a + 45f, top + 2.5f, gPick); Croqueta(a + 54f, top + 0.9f, gPick);
        // ruta de abajo
        MakeEnemy(Enemy.Kind.Cucaracha, a + 12f, 0f, a + 5f, a + 24f, 1.6f + 0.8f * gDiff, gHaz);
        MakeEnemy(Enemy.Kind.Arana, a + 32f, 0f, a + 24f, a + 41f, 1.1f + 0.6f * gDiff, gHaz);
        for (float cx = a + 8f; cx < a + 40f; cx += 8f) Croqueta(cx, 0.8f, gPick);
        MakeText("¿Por arriba o por abajo?\nTrepa la tubería con W", gDeco, new Vector3((a - 4f) * S, 8f * S, -0.62f), 0.04f, new Color(0.85f, 0.8f, 0.95f), 48, true);
        MakeText("MONTACARGAS", gDeco, new Vector3((a + 45f) * S, 16f * S, -0.62f), 0.04f, new Color(0.85f, 0.8f, 0.95f), 48, true);
        return 6f + 58f + 8f;
    }

    static float S_Branch(float x0, int seg)
    {
        float a = x0 + 6f;
        Checkpoint("CP_Ramas" + seg, x0 + 3f, 0f, gZones);
        ModTree(gDeco, new Vector3((a + 14f) * S, 0f, 1.8f), 9f);
        for (int i = 0; i < 2; i++)
        {
            float bx = a + 9f + i * 12f;
            var br = Root("Rama3D", gHaz, new Vector3(bx * S, 4.3f, 0f));
            Pm(CY, "Rama", br, 0, 0, 0, 0.26f, 0.95f, 0.26f, "#6B4423", 0f, 0f, 82f);
            Pm(CY, "Ramita1", br, 0.35f, 0.18f, 0, 0.13f, 0.45f, 0.13f, "#6B4423", 0f, 0f, 35f);
            Pm(CY, "Ramita2", br, -0.4f, 0.14f, 0, 0.12f, 0.4f, 0.12f, "#6B4423", 0f, 0f, -30f);
            for (int l = 0; l < 6; l++) Pm(SP, "Hoja", br, -0.8f + l * 0.32f, 0.15f + (l % 2) * 0.22f, 0, 0.42f, 0.2f, 0.3f, l % 2 == 0 ? "#4BA057" : "#3F8F4A");
            var mk = Marker(new Vector3(bx * S, 0f, 0f), 0.9f, "#2E5E34");
            var fh = br.gameObject.AddComponent<FallingHazard>();
            fh.obj = br; fh.marker = mk.transform; fh.groundY = 0.18f; fh.radius = 1.0f; fh.interval = 3.0f; fh.warn = 0.9f; fh.phase = i * 1.5f; fh.activeRange = 14f;
            fh.message = "¡Se cayó una rama! +1 estrés";
        }
        for (float cx = a + 2f; cx < a + 30f; cx += 8f) Croqueta(cx, 0.8f, gPick);
        MakeText("¡RAMAS!", gDeco, new Vector3((a + 12f) * S, 10f * S, -0.62f), 0.06f, new Color(0.17f, 0.3f, 0.12f), 48, true);
        return 6f + 30f + 6f;
    }

    static float S_Swing(float x0, int seg)
    {
        float pw = 18f, pre = 10f, a = x0 + pre;
        Checkpoint("CP_Columpio" + seg, x0 + 3f, 0f, gZones);
        CloseFloor(a);
        PitAt(a, a + pw);
        gRunStart = a + pw;
        float cx = (a + pw * 0.5f) * S;
        var seat = new GameObject("Columpio_Asiento");
        seat.transform.SetParent(gHaz, false);
        seat.transform.position = new Vector3(cx, 0.0f, 0f);
        var bc = seat.AddComponent<BoxCollider>(); bc.size = new Vector3(1.0f, 0.12f, D);
        seat.AddComponent<Rigidbody>().isKinematic = true;
        var pp = seat.AddComponent<PendulumPlatform>();
        pp.pivot = new Vector3(cx, 2.9f, 0f); pp.length = 2.9f; pp.amplitudeDeg = 20f; pp.period = 2.8f;
        Pm(CU, "Asiento", seat.transform, 0f, 0f, 0f, 1.0f, 0.12f, 0.55f, "#C9A26B");
        Pm(CU, "Borde", seat.transform, 0f, 0.07f, -0.28f, 1.02f, 0.03f, 0.04f, "#8B6B3E");
        var r1 = Pm(CY, "Cuerda1", gDeco, cx, 1f, 0f, 0.05f, 1f, 0.05f, "#E0D3B0");
        var r2 = Pm(CY, "Cuerda2", gDeco, cx, 1f, 0f, 0.05f, 1f, 0.05f, "#E0D3B0");
        pp.ropes = new[] { r1.transform, r2.transform };
        pp.ropeDx = new[] { -0.42f, 0.42f };
        float px1 = a * S - 0.55f, px2 = (a + pw) * S + 0.55f;
        Pm(CY, "Poste1", gDeco, px1, 1.5f, 0.1f, 0.2f, 1.5f, 0.2f, "#C94F4F");
        Pm(CY, "Poste2", gDeco, px2, 1.5f, 0.1f, 0.2f, 1.5f, 0.2f, "#C94F4F");
        Pm(CY, "Viga", gDeco, cx, 3.0f, 0.1f, 0.22f, (px2 - px1) * 0.5f, 0.22f, "#C94F4F", 0f, 0f, 90f);
        Croqueta(a + pw * 0.5f, 5.5f, gPick);
        MakeText("COLUMPIO", gDeco, new Vector3((a - 3f) * S, 10f * S, -0.62f), 0.05f, new Color(0.17f, 0.3f, 0.12f), 48, true);
        return pre + pw + 8f;
    }

    static float S_Sprink(float x0, int seg)
    {
        float a = x0 + 8f;
        Checkpoint("CP_Aspersor" + seg, x0 + 3f, 0f, gZones);
        for (int i = 0; i < 2; i++)
        {
            float sx = a + i * 16f;
            Transform jet;
            ModSprinkler(gDeco, new Vector3(sx * S, 0f, 0f), out jet);
            var hz = Zone2("Aspersor_Peligro_" + i, new Vector3(sx * S, 0.9f, 0f), new Vector3(1.5f, 1.8f, 1.0f), gHaz);
            var th = hz.AddComponent<TimedHazard>();
            th.onTime = 1.4f; th.offTime = 1.8f; th.warnTime = 0.7f; th.phase = i * 1.5f; th.fx = jet; th.knock = new Vector2(4.5f, 6.5f);
            th.message = "¡Te mojó el aspersor! +1 estrés";
            Croqueta(sx + 8f, 0.8f, gPick);
        }
        MakeText("¡ASPERSORES!", gDeco, new Vector3((a + 8f) * S, 10f * S, -0.62f), 0.05f, new Color(0.17f, 0.3f, 0.12f), 48, true);
        return 8f + 16f + 14f;
    }

    static float S_Roach(float x0, int seg)
    {
        float L = 36f;
        MakeEnemy(Enemy.Kind.Cucaracha, x0 + 10f, 0f, x0 + 4f, x0 + 22f, 1.5f + 0.8f * gDiff, gHaz);
        MakeEnemy(Enemy.Kind.Cucaracha, x0 + 26f, 0f, x0 + 14f, x0 + L - 3f, 1.8f + 0.8f * gDiff, gHaz);
        Croqueta(x0 + 6f, 0.8f, gPick); Croqueta(x0 + L - 5f, 0.8f, gPick);
        MakeText("¡CUCARACHAS! písalas", gDeco, new Vector3((x0 + 17f) * S, 8f * S, -0.62f), 0.04f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return L;
    }

    static float S_Spider(float x0, int seg)
    {
        float L = 38f;
        MakeEnemy(Enemy.Kind.Arana, x0 + 12f, 0f, x0 + 5f, x0 + 26f, 1.0f + 0.6f * gDiff, gHaz);
        MakeEnemy(Enemy.Kind.Arana, x0 + 28f, 0f, x0 + 16f, x0 + L - 4f, 1.2f + 0.6f * gDiff, gHaz);
        Croqueta(x0 + 8f, 0.8f, gPick); Croqueta(x0 + L - 6f, 0.8f, gPick);
        MakeText("ARAÑAS (saltan)", gDeco, new Vector3((x0 + 19f) * S, 8f * S, -0.62f), 0.04f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return L;
    }

    static float S_ShelfClimb(float x0, int seg)
    {
        float[] hs = { 4f, 8.5f, 13f, 8.5f, 4f };
        string st = "repisa";
        for (int i = 0; i < 5; i++)
        {
            float sx = x0 + 6f + i * 9f;
            Plat("Anaquel_" + seg + "_" + i, sx, sx + 6f, hs[i] - 0.9f, hs[i], st, gGeo, gDeco);
            Croqueta(sx + 3f, hs[i] + 0.7f, gPick);
        }
        MakeEnemy(Enemy.Kind.Cucaracha, x0 + 22f, 0f, x0 + 6f, x0 + 52f, 1.7f, gHaz);
        MakeText("¡SUBE!", gDeco, new Vector3((x0 + 8f) * S, 13f * S, -0.62f), 0.06f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        return 6f + 45f + 10f;
    }

    static float S_Pyramid(float x0, int seg)
    {
        float[] hs = { 3f, 6f, 9f, 6f, 3f };
        string st = Sty();
        for (int i = 0; i < 5; i++)
        {
            Plat("Piramide_" + seg + "_" + i, x0 + 6f + i * 6.5f, x0 + 12.5f + i * 6.5f, 0f, hs[i], st, gGeo, gDeco);
            Croqueta(x0 + 9.2f + i * 6.5f, hs[i] + 0.7f, gPick);
        }
        return 6f + 32.5f + 5f;
    }

    // ------------------------------------------------------------------ constructor de un nivel generado
    static void BuildGenLevel(int li, string sceneName, Theme t)
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        gT = t; gR = new System.Random(t.seed); mrnd = new System.Random(t.seed + 100);
        string tag = "N" + (li + 1);
        raw = true;

        var root = new GameObject("Nivel_" + (li + 1)).transform;
        gGeo = new GameObject("Geometria").transform; gGeo.SetParent(root);
        gDeco = new GameObject("Decoracion").transform; gDeco.SetParent(root);
        gZones = new GameObject("Zonas").transform; gZones.SetParent(root);
        gHaz = new GameObject("Peligros_y_Mecanicas").transform; gHaz.SetParent(root);
        gPick = new GameObject("Coleccionables").transform; gPick.SetParent(root);

        gFloorM = Mat("Piso_" + tag, t.floor);
        gWaterM = Mat("Agua", "#4FA3E0");
        gPitM = Mat("FosoFondo", "#3A2F2A");
        gCurtainM = Mat("Cortina", "#E39AB0");
        gBrownL = Mat("MaderaClara", "#A0714F");
        var accent = Mat("Acento_" + tag, t.trim);

        float len = t.length;
        float x0;
        gRunStart = -10f; gFloorN = 0; gLettersPlaced = 0;
        var sections = new List<float>();
        int[] letterSeg = new int[5];
        int plannedSegs = Mathf.RoundToInt(len / 36f);
        for (int i = 0; i < 5; i++) letterSeg[i] = Mathf.Clamp(Mathf.RoundToInt(plannedSegs * (i + 1) / 6f), 2, plannedSegs - 2);

        // ---------- arranque
        Box("Cartel_Inicio", 6f, 30f, 12f, 17f, accent, gDeco, false, 0.06f, 1.2f);
        MakeText(t.title.ToUpper(), gDeco, new Vector3(18f * S, 14.5f * S, 1.15f), 0.07f, Color.white, 56);
        Croqueta(14f, 0.8f, gPick); Croqueta(20f, 0.8f, gPick);
        Checkpoint("CP_Inicio", 10f, 0f, gZones);
        x0 = 36f;
        sections.Add(0f);

        int seg = 0, sinceRest = 0;
        float lastSection = 0f;
        int guard = 0;
        bool chaseDone = false; gChase = false; gYarn = null; gSpecial = 0;
        while (x0 < len - 60f && guard++ < 400)
        {
            float prog = Mathf.Clamp01(x0 / len);
            gDiff = Mathf.Clamp01(t.d0 + 0.25f * prog);
            if (x0 - lastSection >= 100f) { sections.Add(x0); lastSection = x0; }

            // ---- inicio de la persecución: casa del perro / caja de juguetes
            if (t.chaseFrom >= 0f && !chaseDone && x0 >= t.chaseFrom)
            {
                chaseDone = true; gChase = true; gChasePot = t.chaser == "perro";
                float homeCm = x0 + 10f, startCm = homeCm + 32f;
                if (t.chaser == "perro") { Transform hs; MakeDogChaser(gHaz, homeCm * S, startCm * S, t.chaseSpeed, out hs); }
                else gYarn = MakeYarnChaser(gHaz, homeCm * S, startCm * S, t.chaseSpeed);
                Checkpoint("CP_Perseguidor", startCm + 6f, 0f, gZones);
                for (float cx = x0 + 4f; cx < x0 + 46f; cx += 8f) Croqueta(cx, 0.8f, gPick);
                MakeText(t.chaser == "perro" ? "¡No despiertes al perro!" : "¡Cuidado con la caja!", gDeco, new Vector3((homeCm - 2f) * S, 13f * S, -0.62f), 0.045f, new Color(0.17f, 0.11f, 0.3f), 48, true);
                x0 += 52f; seg++; sinceRest++;
                continue;
            }

            int type;
            gIsLetter = gLettersPlaced < 5 && seg >= letterSeg[gLettersPlaced];
            if (gIsLetter) type = T_HILL;
            else if (sinceRest >= 3 && !(t.chaseFrom >= 0f && chaseDone)) type = T_REST;
            else type = Pick(gR, (t.chaseFrom >= 0f && chaseDone) ? t.chaseWeights : t.weights);

            // casita del árbol (patio) y pasarelas (sótano): al menos una vez, como máximo dos
            if (!gIsLetter && type != T_REST && !(t.chaseFrom >= 0f && chaseDone))
            {
                if (gSpecial == 0 && seg >= 3) type = t.outdoor ? T_TREEHOUSE : (t.dark ? T_CATWALK : type);
                else if (gSpecial >= 2 && type == T_TREEHOUSE) type = T_BRANCH;
                else if (gSpecial >= 2 && type == T_CATWALK) type = T_SHELFCLIMB;
            }

            float w;
            switch (type)
            {
                case T_RUN: w = S_Run(x0, seg); break;
                case T_PIT: w = S_Pit(x0, seg); break;
                case T_PUDDLE: w = S_Puddle(x0, seg); break;
                case T_ROOMBA: w = S_Roomba(x0, seg); break;
                case T_STAIRS: w = S_Stairs(x0, seg); break;
                case T_SHELVES: w = S_Shelves(x0, seg); break;
                case T_TABLE: w = S_Table(x0, seg); break;
                case T_TV: w = S_TV(x0, seg); break;
                case T_MOVING: w = S_Moving(x0, seg); break;
                case T_HILL: w = S_Hill(x0, seg); break;
                case T_RATON: w = S_Raton(x0, seg); break;
                case T_MOSCA: w = S_Mosca(x0, seg); break;
                case T_STOVE: w = S_Stove(x0, seg); break;
                case T_DRIP: w = S_Drip(x0, seg); break;
                case T_TUB: w = S_Tub(x0, seg); break;
                case T_CURTAIN: w = S_Curtain(x0, seg); break;
                case T_TOILET: w = S_Toilet(x0, seg); break;
                case T_BRANCH: w = S_Branch(x0, seg); break;
                case T_SWING: w = S_Swing(x0, seg); break;
                case T_SPRINK: w = S_Sprink(x0, seg); break;
                case T_ROACH: w = S_Roach(x0, seg); break;
                case T_SPIDER: w = S_Spider(x0, seg); break;
                case T_SHELFCLIMB: w = S_ShelfClimb(x0, seg); break;
                case T_PYRAMID: w = S_Pyramid(x0, seg); break;
                case T_TREEHOUSE: w = S_TreeHouse(x0, seg); gSpecial++; break;
                case T_CATWALK: w = S_Catwalk(x0, seg); gSpecial++; break;
                default: w = S_Rest(x0, seg); sinceRest = -1; break;
            }
            if (type == T_REST) sinceRest = -1;
            x0 += w; sinceRest++; seg++;
        }

        // ---------- final del nivel
        float endX, endCm;
        var toy = new GameObject("Juguete_META");
        toy.transform.SetParent(gPick, false);
        toy.AddComponent<MeshFilter>().sharedMesh = StarAsset();
        toy.AddComponent<MeshRenderer>().sharedMaterial = Cm("#F4C430");
        var tbc = toy.AddComponent<SphereCollider>(); tbc.isTrigger = true; tbc.radius = 0.5f;
        toy.AddComponent<Collectible>().type = CollectType.Toy;

        BossBenito boss = null;
        Checkpoint("CP_Final", x0 + 6f, 0f, gZones);
        if (li == 5)
        {
            // ---------- ARENA DEL JEFE
            float ax = x0 + 10f;                       // cm
            float arenaMin = ax * S, arenaMax = arenaMin + 16f;
            float arenaEndCm = arenaMax / S;
            endCm = arenaEndCm + 22f;
            endX = (arenaMin + arenaMax) * 0.5f / S;
            CloseFloor(endCm + 28f);
            Checkpoint("CP_Arena", ax - 2f, 0f, gZones);
            for (float cx = ax - 40f; cx < ax - 4f; cx += 9f) Croqueta(cx, 0.8f, gPick);
            if (gLettersPlaced < 5) for (int i = gLettersPlaced; i < 5; i++) Letter(i, x0 - 40f + (i - gLettersPlaced) * 8f, 0f, gPick);
            if (gYarn != null) gYarn.stopX = (ax - 28f) * S;
            boss = BuildBossArena(arenaMin, arenaMax, endCm, toy, gDeco, gHaz);
            toy.SetActive(false);
        }
        else
        {
            endX = x0 + 14f;
            endCm = len;
            Croqueta(x0 + 8f, 0.8f, gPick);
            CloseFloor(len + 28f);
            toy.transform.position = new Vector3(endX * S, 4f * S + 0.3f, 0f);
            Plat("Pedestal", endX - 4f, endX + 4f, 0f, 3f, "cojin", gGeo, gDeco);
            MakeText("META", gDeco, new Vector3(endX * S, 9f * S, -0.62f), 0.07f, new Color(0.17f, 0.11f, 0.3f), 48, true);
            if (gLettersPlaced < 5) for (int i = gLettersPlaced; i < 5; i++) Letter(i, x0 - 40f + (i - gLettersPlaced) * 8f, 0f, gPick);
        }

        // ---------- cuarto: paredes, fondo, techo (con profundidad real)
        var floorFar = Mat("PisoFondo_" + tag, t.trim);
        var wallA = Mat("ParedA_" + tag, t.wallA);
        var wallB = Mat("ParedB_" + tag, t.wallB);
        float wallTop = t.outdoor ? 15f : 40f;
        for (float x = -10f, i = 0; x < endCm + 40f; x += 60f, i++)
            Box("Pared_" + (int)i, x, x + 60f, -9f, wallTop, (i % 2 == 0) ? wallA : wallB, gDeco, false, 0.2f, 3.7f);
        Box("Zocalo", -10f, endCm + 40f, 0f, 1.4f, Mat("Detalle_" + tag, t.trim), gDeco, false, 0.12f, 3.55f);
        Box("PisoLejano", -10f, endCm + 40f, -3f, 0f, floorFar, gDeco, false, 2.9f, 2.15f);
        Box("Limite_Izq", -12f, -11f, -9f, 30f, gFloorM, gGeo, true, D).GetComponent<Renderer>().enabled = false;
        Box("Limite_Der", endCm + 28f, endCm + 29f, -9f, 30f, gFloorM, gGeo, true, D).GetComponent<Renderer>().enabled = false;
        Box("Techo_Invisible", -12f, endCm + 29f, 20.5f, 25f, gFloorM, gGeo, true, D).GetComponent<Renderer>().enabled = false;
        if (t.ceiling) Box("Techo", -12f, endCm + 29f, 20.5f, 23f, Mat("Techo_" + tag, t.trim), gDeco, false, 8f, 3.2f);
        if (t.outdoor)
        {
            Box("Pasto_Lejano", -10f, endCm + 40f, -3f, 0f, Mat("PastoLejano", "#5E9E50"), gDeco, false, 16f, 12f);
            ModSun(gDeco, new Vector3(endCm * S * 0.35f, 8.5f, 20f));
        }
        DecorLevel(li - 1, endCm * S, gDeco);
        if (t.outdoor) for (float fx = 0f; fx < endCm * S + 6f; fx += 6f) ModFence(gDeco, new Vector3(fx + 3f, 0f, 3.35f), 6f);
        if (li == 4) ModPipes(gDeco, new Vector3(endCm * S * 0.5f, 2.9f, 3.2f), endCm * S);

        // ---------- jugador
        Vector3 startPos = new Vector3(12f * S, 1.2f, 0f);
        var player = new GameObject("Surie_Jugadora");
        player.tag = "Player";
        player.transform.position = startPos;
        var prb = player.AddComponent<Rigidbody>(); prb.mass = 1f;
        var cap = player.AddComponent<CapsuleCollider>();
        cap.direction = 0; cap.radius = 0.2f; cap.height = 0.85f; cap.center = new Vector3(0f, 0.22f, 0f);
        var pc = player.AddComponent<PlayerController2D>();
        var model = Cat("Surie", player.transform, Vector3.zero, 0.55f);
        pc.model = model.transform;

        // ---------- Benito roba el juguete (escena al inicio)
        {
            var bn = new GameObject("Benito_Intro");
            bn.transform.position = new Vector3(startPos.x + 4.8f, 0f, 0f);
            var bm = Cat("Benito", bn.transform, Vector3.zero, 0.7f);
            var star = new GameObject("Juguete_Robado");
            star.transform.SetParent(bn.transform, false);
            star.transform.localPosition = new Vector3(0.62f, 0.5f, 0f);
            star.AddComponent<MeshFilter>().sharedMesh = StarAsset();
            star.AddComponent<MeshRenderer>().sharedMaterial = Cm("#F4C430");
            star.transform.localScale = Vector3.one * 0.9f;
            var intro = new GameObject("Intro_Benito").AddComponent<LevelIntro>();
            intro.benito = bn.transform; intro.toy = star; intro.lines = t.story; intro.runUntilX = startPos.x + 30f;
        }

        // ---------- gestor del juego
        var gmGo = new GameObject("GameManager");
        var gm = gmGo.AddComponent<GameManager>();
        gm.player = pc;
        gm.startPoint = startPos; gm.respawnPoint = startPos;
        gm.sceneStamp = BuildInfo.Stamp;
        gm.levelIndex = li;
        gm.levelTitle = t.title;
        gm.sectionStartsCm = sections.ToArray();
        if (t.dark) gmGo.AddComponent<LightsOut>();

        // ---------- cámara y luz
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 35f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = C(t.sky);
        cam.farClipPlane = 80f;
        camGo.AddComponent<AudioListener>();
        var cf = camGo.AddComponent<CameraFollow>();
        cf.target = player.transform;
        cf.minX = 5.5f;
        cf.maxX = (endCm + 28f) * S - 5.5f;
        camGo.transform.position = new Vector3(startPos.x, 2f, -10f);
        var lightGo = new GameObject("Luz_Direccional");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = li == 4 ? 0.9f : 1.15f;
        light.color = new Color(1f, 0.96f, 0.9f);
        lightGo.transform.rotation = Quaternion.Euler(38f, -28f, 0f);
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = C(t.ambient);

        raw = false;
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/" + sceneName + ".unity");
        Debug.Log("[Surie] " + sceneName + " construido: " + Mathf.RoundToInt(endCm) + " cm, " + seg + " tramos, " + gLettersPlaced + " letras.");
    }

    // ------------------------------------------------------------------ jefe final
    static BossBenito BuildBossArena(float arenaMin, float arenaMax, float endCm, GameObject toy, Transform deco, Transform haz)
    {
        // pared invisible (se activa al empezar la pelea) y alfombra de juego
        var wall = new GameObject("Pared_Arena");
        wall.transform.SetParent(haz, false);
        wall.transform.position = new Vector3(arenaMin - 0.3f, 3f, 0f);
        var wb = wall.AddComponent<BoxCollider>(); wb.size = new Vector3(0.4f, 12f, D);
        wall.SetActive(false);
        var endWall = new GameObject("Pared_Arena_Der");
        endWall.transform.SetParent(haz, false);
        endWall.transform.position = new Vector3(arenaMax + 0.3f, 3f, 0f);
        var eb = endWall.AddComponent<BoxCollider>(); eb.size = new Vector3(0.4f, 12f, D);

        float cx = (arenaMin + arenaMax) * 0.5f;
        Pm(CU, "Alfombra", deco, cx, 0.02f, 0.2f, arenaMax - arenaMin, 0.04f, 1.8f, "#E9A6C3");
        Pm(CU, "AlfombraBorde", deco, cx, 0.03f, 0.2f, arenaMax - arenaMin - 1f, 0.04f, 1.4f, "#F7D6E3");
        Pm(CU, "CartelArena", deco, cx, 4.3f, 3.4f, 7f, 1.3f, 0.12f, "#6A4FA3");
        MakeText("ARENA DE BENITO", deco, new Vector3(cx, 4.3f, 3.3f), 0.2f, Color.white, 56);
        ModBalloons(deco, new Vector3(arenaMin + 1.6f, 0f, 2.2f));
        ModBalloons(deco, new Vector3(arenaMax - 1.6f, 0f, 2.2f));
        ModBlockTower(deco, new Vector3(arenaMin + 3.5f, 0f, 2.5f));
        ModBallToy(deco, new Vector3(arenaMax - 3.5f, 0f, 2.4f));

        var bossRoot = new GameObject("Jefe_Benito");
        bossRoot.transform.SetParent(haz, false);
        bossRoot.transform.position = new Vector3(arenaMax - 2.6f, 0f, 0f);
        var spin = new GameObject("Giro").transform;
        spin.SetParent(bossRoot.transform, false);
        spin.localPosition = new Vector3(0f, 0.4f, 0f);
        var model = Cat("Benito", spin, new Vector3(0f, -0.4f, 0f), 0.85f);
        var bb = bossRoot.AddComponent<BossBenito>();
        bb.triggerX = arenaMin + 2.0f; bb.arenaMin = arenaMin; bb.arenaMax = arenaMax;
        bb.spin = spin; bb.visual = model.transform; bb.toy = toy; bb.wallLeft = wall;
        bb.toyAt = new Vector3(cx, 1.1f, 0f);
        return bb;
    }

    static int Pick(System.Random r, int[] w)
    {
        int tot = 0;
        for (int i = 0; i < w.Length; i++) tot += w[i];
        int v = r.Next(tot);
        for (int i = 0; i < w.Length; i++) { v -= w[i]; if (v < 0) return i; }
        return 0;
    }

    static GameObject Prim(PrimitiveType pt, string name, Transform parent, Vector3 lp, Vector3 ls, Material m)
    {
        var g = GameObject.CreatePrimitive(pt);
        g.name = name;
        g.transform.SetParent(parent, false);
        g.transform.localPosition = lp;
        g.transform.localScale = ls;
        g.GetComponent<Renderer>().sharedMaterial = m;
        Object.DestroyImmediate(g.GetComponent<Collider>());
        return g;
    }
}
#endif
