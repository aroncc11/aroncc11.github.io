#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>Las imágenes de Resources/UI se importan nítidas (sin compresión ni mipmaps) para que el menú se vea bien.</summary>
public class UIImport : AssetPostprocessor
{
    void OnPreprocessTexture()
    {
        if (!assetPath.Contains("Resources/UI/")) return;
        var ti = (TextureImporter)assetImporter;
        ti.textureType = TextureImporterType.Default;
        ti.mipmapEnabled = false;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
        ti.filterMode = FilterMode.Bilinear;
        ti.maxTextureSize = 2048;
        ti.alphaIsTransparency = true;
    }
}
#endif
