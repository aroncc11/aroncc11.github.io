#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>Mapa del mundo en ISLAS (v5) y escena de minijuegos 3D.</summary>
public static partial class BuildSurieLevel
{
    static void Scaled(Transform t, float k) { if (t != null) t.localScale = Vector3.one * k; }

    static void BuildWorldScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        raw = false;
        mrnd = new System.Random(77);
        var root = new GameObject("Mundo").transform;
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 40f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = C("#9AD4F5");
        cam.farClipPlane = 200f;
        camGo.AddComponent<AudioListener>();
        var lightGo = new GameObject("Luz_Direccional");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional; light.intensity = 1.2f; light.color = new Color(1f, 0.96f, 0.88f);
        lightGo.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.62f, 0.66f, 0.72f);

        // ---------- mar
        Pm(CU, "Mar", root, 25f, -0.9f, 6f, 120f, 1f, 70f, "#3E9BD6");
        Pm(CU, "MarProfundo", root, 25f, -1.45f, 6f, 120f, 0.1f, 70f, "#2F7FB8");

        Vector3[] pts =
        {
            new Vector3(0f, 0.3f, 0f), new Vector3(10.5f, 0.3f, 3.2f), new Vector3(21f, 0.3f, -1.2f),
            new Vector3(31.5f, 0.3f, 3.2f), new Vector3(42f, 0.3f, -1.2f), new Vector3(52.5f, 0.3f, 2.8f)
        };
        string[] grass = { "#8FD37A", "#B7E27A", "#7FC8A0", "#6DBE5A", "#8F8A7A", "#E7C86B" };
        string[] cols = { "#E9A6B8", "#CFD8DC", "#BFE3EA", "#8DCB7B", "#7A6A8F", "#F2C46B" };
        var stops = new Transform[pts.Length];
        var locks = new Transform[pts.Length];
        var flags = new Transform[pts.Length];
        for (int i = 0; i < pts.Length; i++)
        {
            var st = new GameObject("Estacion_" + i).transform;
            st.SetParent(root, false);
            st.position = pts[i];
            stops[i] = st;
            Vector3 c = pts[i];
            // isla: espuma, roca, arena, pasto, colinas
            Pm(CY, "Espuma", root, c.x, -0.33f, c.z, 7.6f, 0.02f, 7.6f, "#CDEBF7");
            Pm(CY, "Roca", root, c.x, -0.7f, c.z, 6.7f, 0.9f, 6.7f, "#8D8493");
            Pm(CY, "Roca2", root, c.x + 0.4f, -1.15f, c.z - 0.3f, 5.2f, 0.7f, 5.2f, "#756C7C");
            Pm(CY, "Arena", root, c.x, 0.0f, c.z, 6.6f, 0.34f, 6.6f, "#F1DEAA");
            Pm(CY, "Pasto", root, c.x, 0.2f, c.z, 5.6f, 0.2f, 5.6f, grass[i]);
            Pm(SP, "ColinaA", root, c.x + 1.9f, 0.18f, c.z - 1.4f, 2.2f, 1.2f, 2.0f, grass[i]);
            Pm(SP, "ColinaB", root, c.x - 2.2f, 0.18f, c.z + 1.6f, 1.8f, 0.9f, 1.8f, grass[i]);
            Pm(CY, "Plataforma_" + i, st, 0f, -0.02f, 0f, 3.4f, 0.04f, 3.4f, cols[i]);
            Pm(CY, "PlataformaBorde", st, 0f, -0.04f, 0f, 3.7f, 0.03f, 3.7f, "#FFFFFF");
            // rocas y flores en la orilla
            for (int k = 0; k < 6; k++)
            {
                float a = (k * 60f + i * 17f) * Mathf.Deg2Rad;
                float rr = 2.75f;
                if (k % 2 == 0) Pm(SP, "Roquita", root, c.x + Mathf.Cos(a) * rr, 0.3f, c.z + Mathf.Sin(a) * rr, Rf(0.4f, 0.8f), Rf(0.3f, 0.5f), Rf(0.4f, 0.7f), Pal("#9A97A0", "#B0AEB6", "#847F8A"));
                else Scaled(ModFlowers(root, new Vector3(c.x + Mathf.Cos(a) * rr, 0.3f, c.z + Mathf.Sin(a) * rr), 1.2f), 0.5f);
            }
            WorldProp(i, st);
            // candado
            var lk = new GameObject("Candado_" + i).transform;
            lk.SetParent(st, false); lk.localPosition = new Vector3(0f, 1.5f, 0f);
            Pm(CU, "Cuerpo", lk, 0, 0, 0, 1.0f, 0.8f, 0.4f, "#F2C230");
            Pm(CY, "ArgollaI", lk, -0.3f, 0.6f, 0, 0.12f, 0.3f, 0.12f, "#B8BEC4");
            Pm(CY, "ArgollaD", lk, 0.3f, 0.6f, 0, 0.12f, 0.3f, 0.12f, "#B8BEC4");
            Pm(CY, "ArgollaT", lk, 0, 0.9f, 0, 0.12f, 0.35f, 0.12f, "#B8BEC4", 0f, 0f, 90f);
            Pm(SP, "Ojo", lk, 0, 0, -0.22f, 0.16f, 0.16f, 0.05f, "#3B3350");
            locks[i] = lk;
            // bandera
            var fl = new GameObject("Bandera_" + i).transform;
            fl.SetParent(st, false); fl.localPosition = new Vector3(1.9f, 0f, -0.4f);
            Pm(CY, "Poste", fl, 0, 1.0f, 0, 0.1f, 1.0f, 0.1f, "#666666");
            Pm(CU, "Tela", fl, 0.45f, 1.7f, 0, 0.9f, 0.55f, 0.06f, "#F2C230");
            Pm(SP, "Punta", fl, 0, 2.05f, 0, 0.18f, 0.18f, 0.18f, "#F2C230");
            flags[i] = fl;
        }

        // ---------- puentes entre islas
        for (int i = 0; i + 1 < pts.Length; i++)
        {
            Vector3 d = pts[i + 1] - pts[i]; d.y = 0f;
            Vector3 dn = d.normalized;
            Vector3 a = pts[i] + dn * 3.1f, b = pts[i + 1] - dn * 3.1f;
            float L = (b - a).magnitude;
            Quaternion q = Quaternion.LookRotation(dn, Vector3.up);
            var br = new GameObject("Puente_" + i).transform; br.SetParent(root, false);
            for (float s = 0.2f; s < L; s += 0.5f)
            {
                Vector3 p = a + dn * s; p.y = 0.2f;
                var pl = Pm(CU, "Tabla", br, p.x, p.y, p.z, 1.5f, 0.1f, 0.42f, (int)(s * 2) % 2 == 0 ? "#B07D48" : "#9A6B3C");
                pl.transform.rotation = q;
            }
            for (int sd = -1; sd <= 1; sd += 2)
            {
                Vector3 side = Vector3.Cross(Vector3.up, dn) * (0.78f * sd);
                var rail = Pm(CU, "Pasamanos", br, (a + b).x * 0.5f + side.x, 0.85f, (a + b).z * 0.5f + side.z, 0.07f, 0.07f, L, "#7A4E2D");
                rail.transform.rotation = q;
                for (float s = 0.1f; s <= L; s += 1.6f)
                {
                    Vector3 p = a + dn * s + side;
                    Pm(CY, "Poste", br, p.x, 0.5f, p.z, 0.12f, 0.35f, 0.12f, "#5E3A20");
                }
            }
        }

        // ---------- cielo: sol y nubes
        Scaled(ModSun(root, new Vector3(-12f, 26f, 60f)), 2.2f);
        for (int i = 0; i < 12; i++) ModCloud(root, new Vector3(-10f + i * 7.5f + Rf(-2f, 2f), Rf(12f, 22f), Rf(30f, 55f)), Rf(1.6f, 3.2f));
        // barquitos y gaviotas
        for (int i = 0; i < 4; i++)
        {
            var bt = Root("Barco", root, new Vector3(5f + i * 15f, -0.3f, 11f + (i % 2) * 5f));
            Pm(CU, "Casco", bt, 0, 0.1f, 0, 1.6f, 0.4f, 0.7f, "#C94F4F");
            Pm(CU, "Mastil", bt, 0, 0.9f, 0, 0.06f, 1.4f, 0.06f, "#7A4E2D");
            Pm(CU, "Vela", bt, 0.35f, 1.0f, 0, 0.8f, 1.0f, 0.04f, "#FFFFFF");
            bt.gameObject.AddComponent<Wobble>().posAmp = new Vector3(0f, 0.08f, 0f);
            bt.GetComponent<Wobble>().rotAmp = new Vector3(0f, 0f, 3f);
        }

        // ---------- Surie
        var sm = new GameObject("Surie_Mapa").transform;
        sm.SetParent(root, false);
        var catModel = Cat("Surie", sm, Vector3.zero, 0.9f);
        catModel.transform.localRotation = Quaternion.identity;
        sm.position = pts[0] + Vector3.up * 0.45f;

        var wm = new GameObject("WorldMap").AddComponent<WorldMap>();
        wm.stops = stops; wm.locks = locks; wm.flags = flags; wm.surie = sm; wm.cam = cam;
        camGo.transform.position = pts[0] + new Vector3(0f, 7.5f, -9.5f);
        camGo.transform.rotation = Quaternion.Euler(33f, 0f, 0f);
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/Mundo_Surie.unity");
    }

    static void WorldProp(int i, Transform st)
    {
        Vector3 o = st.position;
        switch (i)
        {
            case 0: // sala: casita rosa con techo
                {
                    var h = Root("Casa", st, o + new Vector3(-1.6f, 0f, 1.0f));
                    Pm(CU, "Paredes", h, 0, 0.7f, 0, 2.0f, 1.4f, 1.5f, "#F4A6B8");
                    Pm(CU, "TechoL", h, -0.55f, 1.6f, 0, 1.3f, 0.12f, 1.9f, "#B5453A", 0f, 0f, 32f);
                    Pm(CU, "TechoR", h, 0.55f, 1.6f, 0, 1.3f, 0.12f, 1.9f, "#9C3A30", 0f, 0f, -32f);
                    Pm(CU, "Puerta", h, 0.0f, 0.45f, -0.77f, 0.5f, 0.9f, 0.04f, "#7A4E2D");
                    Pm(CU, "Ventana", h, 0.6f, 0.85f, -0.77f, 0.4f, 0.4f, 0.04f, "#A9D8F2");
                    Pm(CU, "Chimenea", h, -0.7f, 1.9f, 0.3f, 0.3f, 0.7f, 0.3f, "#8D8493");
                    Scaled(ModBush(st, o + new Vector3(-0.4f, 0f, 1.7f), 1.2f), 0.7f);
                    break;
                }
            case 1: // cocina
                {
                    Scaled(ModFridge(st, o + new Vector3(-1.9f, 0f, 1.0f)), 0.5f);
                    Scaled(ModStove(st, o + new Vector3(-0.9f, 0f, 1.2f), 1.8f, 1.2f), 0.7f);
                    var pot = Pm(CY, "Olla", st, o.x - 0.9f, 0.9f, o.z + 1.2f, 0.5f, 0.2f, 0.5f, "#C94F4F");
                    Pm(CY, "Vapor", st, o.x - 0.9f, 1.3f, o.z + 1.2f, 0.18f, 0.18f, 0.18f, "#FFFFFF");
                    Scaled(ModCabinets(st, o + new Vector3(-1.2f, 0f, 1.9f), 2.4f), 0.5f);
                    break;
                }
            case 2: // baño
                {
                    Scaled(ModBathtubDecor(st, o + new Vector3(-1.5f, 0f, 1.1f)), 0.55f);
                    Scaled(ModShowerDecor(st, o + new Vector3(-0.3f, 0f, 1.5f)), 0.55f);
                    Scaled(ModDuck(st, o + new Vector3(-1.2f, 0.75f, 0.7f)).transform, 0.35f);
                    break;
                }
            case 3: // patio: árbol y casita del perro
                {
                    Scaled(ModTree(st, o + new Vector3(-2.0f, 0f, 1.2f), 8f), 0.32f);
                    Transform eyes;
                    Scaled(ModDoghouse(st, o + new Vector3(-0.3f, 0f, 1.7f), out eyes), 0.28f);
                    Scaled(ModFence(st, o + new Vector3(-1.2f, 0f, 2.3f), 6f), 0.4f);
                    break;
                }
            case 4: // sótano: cueva, barriles y farol
                {
                    Pm(SP, "RocaCueva", st, o.x - 1.6f, 0.9f, o.z + 1.2f, 2.4f, 1.9f, 1.8f, "#5E5870");
                    Pm(SP, "BocaCueva", st, o.x - 1.6f, 0.55f, o.z + 0.4f, 1.1f, 1.0f, 0.3f, "#15111E");
                    Scaled(ModBarrel(st, o + new Vector3(-0.2f, 0f, 1.3f), 1.0f, 1.3f), 0.6f);
                    Scaled(ModBarrel(st, o + new Vector3(0.4f, 0f, 1.5f), 1.0f, 1.3f), 0.6f);
                    Scaled(ModCrateStack(st, o + new Vector3(-2.4f, 0f, 0.4f)), 0.4f);
                    Pm(SP, "Farol", st, o.x - 0.9f, 1.1f, o.z + 0.5f, 0.3f, 0.34f, 0.3f, "#FFE680");
                    break;
                }
            default: // cuarto de Benito: castillo de bloques y ovillo
                {
                    Scaled(ModBlockTower(st, o + new Vector3(-1.8f, 0f, 1.1f)), 0.6f);
                    Scaled(ModBlockTower(st, o + new Vector3(-1.0f, 0f, 1.5f)), 0.45f);
                    Scaled(ModBlockTower(st, o + new Vector3(-2.6f, 0f, 1.5f)), 0.45f);
                    Pm(CU, "Muro", st, o.x - 1.8f, 0.35f, o.z + 0.55f, 2.6f, 0.5f, 0.4f, "#4F9AE0");
                    Scaled(ModBallToy(st, o + new Vector3(0.0f, 0f, 1.8f)), 0.5f);
                    Scaled(ModBalloons(st, o + new Vector3(-0.2f, 0f, 1.0f)), 0.6f);
                    break;
                }
        }
    }

    // ------------------------------------------------------------------ minijuegos 3D
    static void BuildMiniScene()
    {
        var sc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        mrnd = new System.Random(88);
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 40f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = C("#1C1230");
        cam.farClipPlane = 120f;
        camGo.transform.position = new Vector3(0f, 3.4f, -13f);
        camGo.transform.rotation = Quaternion.Euler(6f, 0f, 0f);
        camGo.AddComponent<AudioListener>();
        var lightGo = new GameObject("Luz_Direccional");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional; light.intensity = 1.2f; light.color = new Color(1f, 0.96f, 0.9f);
        lightGo.transform.rotation = Quaternion.Euler(42f, -25f, 0f);
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.66f, 0.66f, 0.72f);

        var mg = new GameObject("Minijuego").AddComponent<MiniGame>();
        var sr = new GameObject("Surie3D").transform;
        var model = Cat("Surie", sr, Vector3.zero, 1.25f);
        model.transform.localRotation = Quaternion.Euler(0f, 90f, 0f);
        mg.surie = sr; mg.surieModel = model.transform; mg.cam = cam;
        mg.baseMat = Cm("#FFFFFF");
        EditorSceneManager.SaveScene(sc, "Assets/Scenes/Mini_Surie.unity");
    }
}
#endif
