#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>
/// Menú  Surie ▸ Construir nivel completo
/// Crea la escena "Nivel_Surie" con las 5 secciones (sala + cocina), los modelos 3D de Surie y Benito,
/// cámara fija lateral, luces y todos los scripts conectados. Medidas en cm de la maqueta × 0.15 = metros.
/// </summary>
public static partial class BuildSurieLevel
{
    const float S = 0.15f;      // 1 cm de la maqueta = 0.15 m en Unity
    const float D = 1.2f;       // profundidad de las plataformas (carril)

    static Dictionary<string, Material> mats = new Dictionary<string, Material>();

    // ------------------------------------------------------------------ utilidades
    static Color C(string hex)
    {
        Color c;
        ColorUtility.TryParseHtmlString(hex, out c);
        return c;
    }

    static Material Mat(string name, string hex, bool emissive = false)
    {
        Material m;
        if (mats.TryGetValue(name, out m)) return m;
        Directory.CreateDirectory("Assets/Materials");
        string path = "Assets/Materials/" + name + ".mat";
        m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null)
        {
            Shader sh = null;
            if (GraphicsSettings.currentRenderPipeline != null) sh = Shader.Find("Universal Render Pipeline/Lit");
            if (sh == null) sh = Shader.Find("Standard");
            if (sh == null) sh = Shader.Find("Sprites/Default");
            m = new Material(sh);
            AssetDatabase.CreateAsset(m, path);
        }
        m.color = C(hex);
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", 0.1f);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 0.1f);
        EditorUtility.SetDirty(m);
        mats[name] = m;
        return m;
    }

    // ---- separación extra entre muebles: cada tramo (cm, extra) añade espacio libre a partir de ese punto
    static readonly float[,] Gaps = { { 14.5f, 4f }, { 22.5f, 3f }, { 31f, 5f }, { 64.6f, 4f }, { 90f, 3f }, { 121.05f, 90f }, { 130f, 4f }, { 135.5f, 8f }, { 141f, 3f }, { 147f, 10f } };
    static bool raw;   // true = las coordenadas ya vienen en cm finales (zona nueva)
    static float M(float x)
    {
        if (raw) return x;
        float r = x;
        for (int i = 0; i < Gaps.GetLength(0); i++) if (x > Gaps[i, 0]) r += Gaps[i, 1];
        return r;
    }

    // ---- modelos 3D (Assets/Models/Muebles/*.obj) que sustituyen a los bloques; el collider sigue siendo el bloque
    static readonly Dictionary<string, string> Skins = new Dictionary<string, string>
    {
        { "Cama", "cama" }, { "Cama_Cabecera", "cabecera" }, { "Cama_Almohada", "almohada" },
        { "Cojin_1", "cojin" }, { "Cojin_2", "cojin" }, { "Cojin_N1", "cojin" },
        { "Sofa_Asiento", "sofa_asiento" }, { "Sofa_Respaldo", "sofa_respaldo" }, { "Sofa_Cojin", "sofa_cojin" },
        { "Ventana_Marco", "ventana" }, { "Cuadro_Marco", "marco" },
        { "Cortina", "cortina" }, { "Repisa_U", "repisa" }, { "Estante_N", "repisa" },
        { "Mesa_Tapa", "mesa_tapa" }, { "Mesa_Pata1", "pata" }, { "Mesa_Pata2", "pata" },
        { "Caja_Empujable", "caja" }, { "Caja_Impulso", "caja" }, { "Puf", "puf" },
        { "Libro_1", "librero_bajo" }, { "Libro_2", "librero_alto" },
        { "Ventilador_Poste", "ventilador_poste" }, { "Ventilador_Plataforma", "ventilador_plataforma" },
        { "Encimera", "encimera" }, { "Encimera_Plato", "plato" }, { "Taburete", "taburete" }, { "Taburete_Cocina", "taburete" },
        { "Mueble_TV", "mueble_tv" }, { "TV_Marco", "tv" }, { "Control_Remoto", "remoto" }
    };

    // host = bloque (cubo) o primitiva; tall = cilindro/cápsula (alto 2). El modelo se ajusta a la caja del host.
    static int missingSkins;
    static void Skin(GameObject host, string model, bool tall = false)
    {
        var rend = host.GetComponent<Renderer>();
        if (model == "-") { if (rend != null) rend.enabled = false; return; }
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Models/Muebles/" + model + ".obj");
        if (prefab == null)
        {
            Debug.LogWarning("Falta Assets/Models/Muebles/" + model + ".obj (se deja el bloque)");
            missingSkins++;
            return;
        }
        var inst = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
        PrefabUtility.UnpackPrefabInstance(inst, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
        inst.name = model;
        inst.transform.position = Vector3.zero;
        inst.transform.rotation = Quaternion.identity;
        inst.transform.localScale = Vector3.one;
        // medir el modelo (sin importar la escala con la que Unity lo importó)
        Vector3 mn = new Vector3(1e9f, 1e9f, 1e9f), mx = new Vector3(-1e9f, -1e9f, -1e9f);
        foreach (var mf in inst.GetComponentsInChildren<MeshFilter>())
        {
            if (mf.sharedMesh == null) continue;
            Vector3 c = mf.sharedMesh.bounds.center, e = mf.sharedMesh.bounds.extents;
            for (int i = 0; i < 8; i++)
            {
                Vector3 q = mf.transform.TransformPoint(new Vector3(c.x + ((i & 1) == 0 ? -e.x : e.x), c.y + ((i & 2) == 0 ? -e.y : e.y), c.z + ((i & 4) == 0 ? -e.z : e.z)));
                mn = new Vector3(Mathf.Min(mn.x, q.x), Mathf.Min(mn.y, q.y), Mathf.Min(mn.z, q.z));
                mx = new Vector3(Mathf.Max(mx.x, q.x), Mathf.Max(mx.y, q.y), Mathf.Max(mx.z, q.z));
            }
        }
        Vector3 sz = mx - mn;
        if (sz.x < 1e-5f || sz.y < 1e-5f || sz.z < 1e-5f) { Object.DestroyImmediate(inst); return; }
        float h = tall ? 2f : 1f;
        float sy = h / sz.y;
        inst.transform.SetParent(host.transform, false);
        inst.transform.localScale = new Vector3(1f / sz.x, sy, 1f / sz.z);
        inst.transform.localPosition = new Vector3(-(mn.x + mx.x) * 0.5f / sz.x, -0.5f * h - mn.y * sy, -(mn.z + mx.z) * 0.5f / sz.z);
        foreach (var r in inst.GetComponentsInChildren<Renderer>())
        {
            var ms = r.sharedMaterials;
            for (int i = 0; i < ms.Length; i++)
            {
                if (ms[i] == null) continue;
                string n = ms[i].name.Replace(" (Instance)", "");
                if (n.StartsWith("F_") && n.Length >= 8) ms[i] = Mat(n, "#" + n.Substring(2, 6));
            }
            r.sharedMaterials = ms;
        }
        if (rend != null) rend.enabled = false;
    }

    static GameObject Box(string name, float x0, float x1, float y0, float y1, Material m, Transform parent,
                          bool collider = true, float depth = D, float z = 0f)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.position = new Vector3((M(x0) + M(x1)) * 0.5f * S, (y0 + y1) * 0.5f * S, z);
        go.transform.localScale = new Vector3((M(x1) - M(x0)) * S, (y1 - y0) * S, depth);
        go.GetComponent<Renderer>().sharedMaterial = m;
        if (!collider) Object.DestroyImmediate(go.GetComponent<Collider>());
        string sk;
        if (Skins.TryGetValue(name, out sk)) Skin(go, sk);
        return go;
    }

    static GameObject Trigger(string name, float x0, float x1, float y0, float y1, Transform parent, ZoneType t, float depth = D)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.position = new Vector3((M(x0) + M(x1)) * 0.5f * S, (y0 + y1) * 0.5f * S, 0f);
        var bc = go.AddComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.size = new Vector3((M(x1) - M(x0)) * S, (y1 - y0) * S, depth);
        var z = go.AddComponent<Zone>();
        z.type = t;
        return go;
    }

    static GameObject Checkpoint(string name, float xcm, float topcm, Transform parent)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.position = new Vector3(M(xcm) * S, topcm * S + 0.35f, 0f);
        var bc = go.AddComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.size = new Vector3(1.0f, 0.8f, D);
        go.AddComponent<Zone>().type = ZoneType.Checkpoint;
        return go;
    }

    static GameObject Croqueta(float xcm, float ycm, Transform parent)
    {
        var c = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        c.name = "Croqueta_Energia";
        c.transform.SetParent(parent, false);
        c.transform.position = new Vector3(M(xcm) * S, ycm * S + 0.2f, 0f);
        c.transform.localScale = new Vector3(0.28f, 0.2f, 0.28f);
        c.GetComponent<Renderer>().sharedMaterial = Mat("Croqueta", "#C97B2E");
        Skin(c, "pescadito");
        var sc = c.GetComponent<SphereCollider>();
        sc.isTrigger = true;
        sc.radius = 1.8f;
        c.AddComponent<Collectible>().type = CollectType.Energy;
        return c;
    }

    static GameObject MakeRoomba(string name, float xcm, float xMinCm, float xMaxCm, float speed, Material gray, Transform parent)
    {
        var roomba = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        roomba.name = name;
        roomba.transform.SetParent(parent, false);
        roomba.transform.localScale = new Vector3(0.9f, 0.12f, 0.9f);
        roomba.transform.position = new Vector3(M(xcm) * S, 0.12f, 0f);
        roomba.GetComponent<Renderer>().sharedMaterial = gray;
        Skin(roomba, "roomba", true);
        Object.DestroyImmediate(roomba.GetComponent<Collider>());
        var solid = roomba.AddComponent<BoxCollider>();
        solid.size = new Vector3(1f, 2f, 1f);
        roomba.AddComponent<IgnorePlayerCollision>();
        var rbc = roomba.AddComponent<BoxCollider>();
        rbc.isTrigger = true;
        rbc.size = new Vector3(1.1f, 3f, 1.1f);
        rbc.center = new Vector3(0f, 1f, 0f);
        var led = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        led.name = name + "_LED";
        led.transform.SetParent(roomba.transform, false);
        led.transform.localPosition = new Vector3(0f, 1.1f, 0f);
        led.transform.localScale = new Vector3(0.18f, 0.5f, 0.18f);
        led.GetComponent<Renderer>().enabled = false;   // el modelo ya trae su LED
        Object.DestroyImmediate(led.GetComponent<Collider>());
        var rb = roomba.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        var rm = roomba.AddComponent<Roomba>();
        rm.xMin = M(xMinCm) * S;
        rm.xMax = M(xMaxCm) * S;
        rm.speed = speed;
        return roomba;
    }

    static TextMesh MakeText(string text, Transform parent, Vector3 worldPos, float charSize, Color col, int fontSize = 64, bool outline = false)
    {
        if (outline)
        {
            // copia clara detrás: el texto oscuro se lee sobre cualquier pared
            var sh = MakeText(text, parent, worldPos + new Vector3(0.012f, -0.012f, 0.01f), charSize, new Color(1f, 0.97f, 0.88f), fontSize, false);
            sh.gameObject.name = "Sombra_" + text;
        }
        var go = new GameObject("Texto_" + text);
        go.transform.SetParent(parent, false);
        go.transform.position = worldPos;
        var tm = go.AddComponent<TextMesh>();
        tm.text = text;
        tm.fontSize = fontSize;
        tm.characterSize = charSize;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.alignment = TextAlignment.Center;
        tm.color = col;
        tm.fontStyle = FontStyle.Bold;
        var ls = parent.lossyScale;
        go.transform.localScale = new Vector3(1f / ls.x, 1f / ls.y, 1f / ls.z);   // cancela la escala del padre
        Font f = null;
        try { f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
        if (f == null) { try { f = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { } }
        if (f != null)
        {
            tm.font = f;
            go.GetComponent<MeshRenderer>().sharedMaterial = f.material;
        }
        return tm;
    }

    static GameObject Letter(int idx, float xcm, float topcm, Transform parent)
    {
        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "Letra_" + "SURIE"[idx];
        cube.transform.SetParent(parent, false);
        float size = 1.8f * S;
        cube.transform.position = new Vector3(M(xcm) * S, topcm * S + size * 0.5f + 0.02f, 0f);
        cube.transform.localScale = new Vector3(size, size, size);
        cube.GetComponent<Renderer>().sharedMaterial = Mat("Letra", "#F4C430");
        var bc = cube.GetComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.size = Vector3.one * 1.2f;
        var col = cube.AddComponent<Collectible>();
        col.type = CollectType.Letter;
        col.index = idx;
        var tm = MakeText("" + "SURIE"[idx], cube.transform, cube.transform.position + new Vector3(0, 0, -size * 0.52f), 0.08f, Color.black, 48);
        return cube;
    }

    static Mesh StarMesh(float R)
    {
        float depth = R * 0.35f;
        var verts = new List<Vector3>();
        var tris = new List<int>();
        int n = 10;
        // centro delante y detrás
        verts.Add(new Vector3(0, 0, -depth));  // 0
        verts.Add(new Vector3(0, 0, depth));   // 1
        for (int i = 0; i < n; i++)
        {
            float a = Mathf.PI / 2f + i * Mathf.PI / 5f;
            float r = (i % 2 == 0) ? R : R * 0.45f;
            verts.Add(new Vector3(Mathf.Cos(a) * r, Mathf.Sin(a) * r, 0f));
        }
        for (int i = 0; i < n; i++)
        {
            int a = 2 + i, b = 2 + (i + 1) % n;
            tris.AddRange(new[] { 0, b, a });   // cara frontal (hacia -Z)
            tris.AddRange(new[] { 1, a, b });   // cara trasera
        }
        var m = new Mesh();
        m.name = "StarMesh";
        m.SetVertices(verts);
        m.SetTriangles(tris, 0);
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }

    static GameObject Cat(string modelName, Transform parent, Vector3 pos, float scale)
    {
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Models/" + modelName + ".obj");
        GameObject inst;
        if (prefab != null)
        {
            inst = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            PrefabUtility.UnpackPrefabInstance(inst, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
        }
        else
        {
            Debug.LogWarning("No se encontró Assets/Models/" + modelName + ".obj; se usa una cápsula de reemplazo.");
            inst = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            Object.DestroyImmediate(inst.GetComponent<Collider>());
        }
        bool partes = false;
        if (prefab != null)
        {
            var pp = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Models/" + modelName + "_partes.obj");
            if (pp != null)
            {
                Object.DestroyImmediate(inst);
                inst = (GameObject)PrefabUtility.InstantiatePrefab(pp);
                PrefabUtility.UnpackPrefabInstance(inst, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                partes = true;
            }
        }
        inst.name = modelName + "_Modelo";
        inst.transform.SetParent(parent, false);
        inst.transform.localPosition = pos;
        inst.transform.localRotation = Quaternion.Euler(0f, 90f, 0f);   // el modelo mira a +Z → lo giramos a +X
        inst.transform.localScale = Vector3.one * scale;
        foreach (var r in inst.GetComponentsInChildren<Renderer>())
        {
            var ms = r.sharedMaterials;
            for (int i = 0; i < ms.Length; i++)
            {
                if (ms[i] == null) continue;
                Material repl = CatMaterial(ms[i].name);
                if (repl != null) ms[i] = repl;
            }
            r.sharedMaterials = ms;
        }
        if (partes) RigPartes(inst);
        return inst;
    }

    // Crea pivotes en las articulaciones. Unity puede nombrar las piezas "Cuerpo", "Cuerpo_base"...
    // así que se agrupan todas las que empiecen con el nombre de la parte.
    static bool Es(string n, string part) { return n == part || n.StartsWith(part + "_"); }

    static Transform Pivot(Transform root, string part, Vector3 joint)
    {
        var found = new List<Transform>();
        foreach (var t in root.GetComponentsInChildren<Transform>(true))
        {
            if (t == root || !Es(t.name, part)) continue;
            if (t.parent != root && Es(t.parent.name, part)) continue;   // solo la pieza de más arriba
            found.Add(t);
        }
        if (found.Count == 0) return null;
        var pv = new GameObject("Pivote_" + part).transform;
        pv.SetParent(root, false);
        pv.localPosition = joint;
        pv.localRotation = Quaternion.identity;
        foreach (var t in found) t.SetParent(pv, true);
        return pv;
    }

    static void RigPartes(GameObject inst)
    {
        var root = inst.transform;
        var names = "";
        foreach (var t in root.GetComponentsInChildren<Transform>(true)) names += t.name + ", ";
        var a = inst.AddComponent<CatAnimator>();
        a.frontP = Pivot(root, "PataDel_P", new Vector3(0.14f, 0.34f, 0.34f));
        a.frontN = Pivot(root, "PataDel_N", new Vector3(-0.14f, 0.34f, 0.34f));
        a.backP = Pivot(root, "PataTras_P", new Vector3(0.17f, 0.30f, -0.30f));
        a.backN = Pivot(root, "PataTras_N", new Vector3(-0.17f, 0.30f, -0.30f));
        a.head = Pivot(root, "Cabeza", new Vector3(0f, 0.66f, 0.46f));
        a.tail = Pivot(root, "Cola", new Vector3(0f, 0.55f, -0.48f));
        a.player = inst.GetComponentInParent<PlayerController2D>();
        if (a.frontP == null || a.backP == null)
            Debug.LogWarning("CatAnimator: no se encontraron las patas. Piezas del modelo: " + names);
    }

    static Material CatMaterial(string n)
    {
        n = n.Replace(" (Instance)", "");
        string[] surie = { "base", "#E9E2D6", "chest", "#F6F2EA", "tabby", "#A39D95", "dark", "#625D58", "pink", "#E8A3AB", "blue", "#79B4DA", "pupil", "#161616", "spot", "#1B1B1B", "cream2", "#E7CFA8" };
        string[] benito = { "base", "#B9A07B", "chest", "#E8C896", "tabby", "#4B3F33", "dark", "#2E2823", "pink", "#D9959C", "blue", "#8E9A4B", "pupil", "#161616", "spot", "#4B3F33", "cream2", "#E8C896" };
        string[] pal = n.StartsWith("Surie_") ? surie : (n.StartsWith("Benito_") ? benito : null);
        if (pal == null) return null;
        string key = n.Substring(n.IndexOf('_') + 1);
        for (int i = 0; i < pal.Length; i += 2)
            if (pal[i] == key)
            {
                var m = Mat(n, pal[i + 1]);
                var tx = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Models/Textures/" + n + ".png");
                if (tx != null)
                {
                    m.mainTexture = tx;
                    m.color = Color.white;
                    if (m.HasProperty("_BaseMap")) m.SetTexture("_BaseMap", tx);
                    if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", Color.white);
                }
                return m;
            }
        return null;
    }

    // ------------------------------------------------------------------ construcción
    [MenuItem("Surie/Probar nivel bonus (durante Play)")]
    public static void ProbarBonus()
    {
        if (!Application.isPlaying) { EditorUtility.DisplayDialog("Surie", "Primero dale Play al nivel (desde Menu_Surie o abriendo Nivel_Surie) y luego elige esta opción.", "OK"); return; }
        var gm = Object.FindFirstObjectByType<GameManager>();
        if (gm == null) { EditorUtility.DisplayDialog("Surie", "No hay GameManager en la escena actual. Entra al nivel (JUGAR) y vuelve a elegir esta opción.", "OK"); return; }
        gm.DebugGoBonus();
    }

    [MenuItem("Surie/Construir nivel completo")]
    public static void Build()
    {
        try { BuildInner(); }
        catch (System.Exception e)
        {
            Debug.LogError("[Surie] Error al construir el nivel: " + e);
            EditorUtility.DisplayDialog("Surie · ERROR al construir", "No se pudo construir el nivel (la escena NO se actualizó):\n\n" + e.GetType().Name + ": " + e.Message + "\n\nMándame esta ventana o la línea roja de la consola.", "OK");
        }
    }

    static void BuildInner()
    {
        missingSkins = 0;
        AssetDatabase.Refresh();
        mats.Clear();
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var root = new GameObject("Nivel_Surie").transform;
        var geo = new GameObject("Geometria").transform; geo.SetParent(root);
        var deco = new GameObject("Decoracion").transform; deco.SetParent(root);
        var zones = new GameObject("Zonas").transform; zones.SetParent(root);
        var hazards = new GameObject("Peligros_y_Mecanicas").transform; hazards.SetParent(root);
        var pick = new GameObject("Coleccionables").transform; pick.SetParent(root);

        // ---------- materiales
        var wood = Mat("Piso", "#D9C3A5");
        var wallM = Mat("Pared", "#F3E6CF");
        var pink = Mat("Cama", "#F4A6B8");
        var pinkD = Mat("CamaOsc", "#E58E8E");
        var cushion = Mat("Cojin", "#B98A66");
        var sofa = Mat("Sofa", "#C9885B");
        var brown = Mat("Madera", "#7A4E2D");
        var brownL = Mat("MaderaClara", "#A0714F");
        var orange = Mat("Caja", "#E8833A");
        var purple = Mat("Puf", "#8E5BD0");
        var bookA = Mat("LibroA", "#6C8EBF");
        var bookB = Mat("LibroB", "#5B7DB1");
        var water = Mat("Agua", "#4FA3E0");
        var white = Mat("Blanco", "#FFFFFF");
        var dark = Mat("Negro", "#1F2328");
        var curtainM = Mat("Cortina", "#E39AB0");
        var fanM = Mat("Ventilador", "#7CC0E0");
        var kitchen = Mat("Encimera", "#C9D6DE");
        var doorM = Mat("Puerta", "#C98A55");
        var gold = Mat("Dorado", "#F2C230");
        var red = Mat("Rojo", "#E5484D");
        var gray = Mat("Roomba", "#555555");
        var glass = Mat("Vidrio", "#BFE3F2");
        var vase = Mat("Jarron", "#3B6FB5");
        var tv = Mat("TV", "#1F2328");
        var screenM = Mat("Pantalla", "#1F2328");

        // ---------- pared de fondo con color por sección
        Color[] secCol = { C("#FBE9D9"), C("#FBF1D4"), C("#E8E3F4"), C("#DCEBF5"), C("#E6F1E7") };
        string[] secName = { "1 · INICIO", "2 · DESARROLLO", "3 · VARIACIÓN", "4 · COMPLICACIÓN", "5 · CONCLUSIÓN" };
        for (int i = 0; i < 5; i++)
        {
            var m = Mat("ParedSec" + (i + 1), "#FFFFFF");
            m.color = secCol[i];
            EditorUtility.SetDirty(m);
            Box("Pared_S" + (i + 1), i * 30f - (i == 0 ? 3f : 0f), (i + 1) * 30f + (i == 4 ? 3f : 0f), 0f, 20.5f, m, geo, false, 0.1f, 0.75f);
            // (rótulos de sección quitados)
            // MakeText(secName[i], deco, new Vector3((i * 30f + 15f) * S, 19.2f * S, 0.68f), 0.07f, new Color(0.2f, 0.2f, 0.2f), 64);
        }
        // zócalo
        Box("Zocalo", -3f, 153f, 0f, 1.2f, Mat("Zocalo", "#E7D7BC"), geo, false, 0.12f, 0.66f);

        // ---------- piso (con foso entre 104 y 121 cm)
        Box("Piso_A", -3f, 104f, -3f, 0f, wood, geo, true, D + 0.6f);
        Box("Piso_B", 121.5f, 153f, -3f, 0f, wood, geo, true, D + 0.6f);
        // muros invisibles en los extremos
        Box("Limite_Izq", -4f, -3f, -3f, 24f, wood, geo, true, D).GetComponent<Renderer>().enabled = false;
        Box("Limite_Der", 150f, 151f, -3f, 24f, wood, geo, true, D).GetComponent<Renderer>().enabled = false;
        var ceiling = Box("Techo_Invisible", -3f, 153f, 20.5f, 25f, wood, geo, true, D);
        ceiling.GetComponent<Renderer>().enabled = false;

        // ---------- SECCIÓN 1: cama + cojines
        Box("Cama", 2f, 13f, 0f, 3f, pink, geo);
        Box("Cama_Cabecera", 2f, 3.2f, 3f, 6.2f, pinkD, geo);
        Box("Cama_Almohada", 3.6f, 7.2f, 3f, 4.6f, white, deco, false, 0.34f, 0.5f);
        Box("Cojin_1", 16f, 21f, 0f, 3.5f, cushion, geo);
        Box("Cojin_2", 24f, 29f, 0f, 3.5f, cushion, geo);
        MakeText("CAMA", deco, new Vector3(M(9.5f) * S, 1.2f * S, -0.62f), 0.065f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        // cuadro en la pared
        Box("Cuadro_Marco", 7f, 17f, 8f, 15.5f, brownL, deco, false, 0.06f, 0.66f);
        Box("Cuadro_Imagen", 8f, 16f, 9f, 14.5f, Mat("CuadroImg", "#9CC9A6"), deco, false, 0.04f, 0.62f);

        // ---------- SECCIÓN 2: sofá, cortina, repisa, agua, mesa, jarrón
        Box("Sofa_Asiento", 33f, 45f, 0f, 4f, sofa, geo);
        Box("Sofa_Respaldo", 33f, 35.2f, 4f, 7.6f, sofa, geo);
        Box("Sofa_Cojin", 35.4f, 44.8f, 4f, 6.2f, Mat("SofaCojin", "#D9A074"), deco, false, 0.34f, 0.5f);
        // ventana
        Box("Ventana_Marco", 37f, 52f, 7f, 18f, white, deco, false, 0.06f, 0.66f);
        Box("Ventana_Vidrio", 37.6f, 51.4f, 7.6f, 17.4f, glass, deco, false, 0.04f, 0.62f);
        // cortina (se trepa) + barra
        Box("Cortina", 34f, 37f, 0.25f, 18.8f, curtainM, deco, false, 0.12f, 0.45f);
        Box("Cortina_Barra", 33.4f, 38.4f, 18.8f, 19.2f, brownL, deco, false, 0.1f, 0.45f);
        var climb = Trigger("Zona_Cortina_Trepar", 34f, 37f, 0f, 18.2f, zones, ZoneType.Climb);
        // repisa
        Box("Repisa_U", 38.6f, 45f, 15.4f, 16f, brownL, geo);
        Box("Repisa_Soporte1", 39.2f, 40f, 13.4f, 15.4f, brownL, deco, false, 0.3f, 0.45f);
        Box("Repisa_Soporte2", 43.6f, 44.4f, 13.4f, 15.4f, brownL, deco, false, 0.3f, 0.45f);   // alta: solo se llega trepando la cortina
        // agua (visual + zona)
        Box("Agua", 45f, 52f, 0f, 0.5f, water, deco, false, D);
        Trigger("Zona_Agua", 45f, 52f, 0f, 3f, zones, ZoneType.Water);
        // mesa
        Box("Mesa_Tapa", 52f, 64f, 3.6f, 4.4f, brown, geo);
        Box("Mesa_Pata1", 52.4f, 53.2f, 0f, 3.6f, brown, geo);
        Box("Mesa_Pata2", 62.4f, 63.2f, 0f, 3.6f, brown, geo);
        // jarrón
        var vaseGo = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        vaseGo.name = "Jarron";
        vaseGo.transform.SetParent(hazards, false);
        vaseGo.transform.position = new Vector3(M(59f) * S, 4.4f * S + 0.24f, 0f);
        vaseGo.transform.localScale = new Vector3(0.26f, 0.24f, 0.26f);
        vaseGo.GetComponent<Renderer>().sharedMaterial = vase;
        Skin(vaseGo, "jarron", true);
        vaseGo.AddComponent<Rigidbody>();
        vaseGo.AddComponent<Jarron>();

        // ---------- SECCIÓN 3: caja empujable, Roomba, puf
        var caja = Box("Caja_Empujable", 65f, 69f, 0f, 4f, orange, hazards);
        var rbCaja = caja.AddComponent<Rigidbody>();
        rbCaja.mass = 1f;
        var bg = caja.AddComponent<BoxGuard>(); bg.minX = M(60f) * S; bg.maxX = M(100f) * S;
        rbCaja.SetDamping(0.6f);
        rbCaja.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionZ;
        MakeText("CAJA", caja.transform, new Vector3(M(67f) * S, 2f * S, -0.62f), 0.045f, Color.white, 48);
        Box("Puf", 83f, 89f, 0f, 7.5f, purple, geo);
        MakeText("PUF", deco, new Vector3(M(86f) * S, 3.8f * S, -0.62f), 0.05f, Color.white, 48);
        // Roomba
        var roomba = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        roomba.name = "Roomba";
        roomba.transform.SetParent(hazards, false);
        roomba.transform.localScale = new Vector3(0.9f, 0.12f, 0.9f);
        roomba.transform.position = new Vector3(M(73f) * S, 0.12f, 0f);
        roomba.GetComponent<Renderer>().sharedMaterial = gray;
        Skin(roomba, "roomba", true);
        Object.DestroyImmediate(roomba.GetComponent<Collider>());
        var solid = roomba.AddComponent<BoxCollider>();   // sólido: la caja ya no lo atraviesa
        solid.size = new Vector3(1f, 2f, 1f);
        roomba.AddComponent<IgnorePlayerCollision>();
        var rbc = roomba.AddComponent<BoxCollider>();
        rbc.isTrigger = true;
        rbc.size = new Vector3(1.1f, 3f, 1.1f);
        rbc.center = new Vector3(0f, 1f, 0f);
        var led = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        led.name = "Roomba_LED";
        led.transform.SetParent(roomba.transform, false);
        led.transform.localPosition = new Vector3(0f, 1.1f, 0f);
        led.transform.localScale = new Vector3(0.18f, 0.5f, 0.18f);
        led.GetComponent<Renderer>().enabled = false;   // el modelo ya trae su LED
        Object.DestroyImmediate(led.GetComponent<Collider>());
        var roombaRb = roomba.AddComponent<Rigidbody>();
        roombaRb.isKinematic = true;
        var rm = roomba.AddComponent<Roomba>();
        rm.xMin = M(71.5f) * S;
        rm.xMax = M(80.5f) * S;
        rm.speed = 1.5f;

        // ---------- SECCIÓN 4: libros, cascabel, ventilador, ovillo, foso
        // librero escalonado: módulo bajo (7.5 cm) + módulo alto (11 cm), pegados
        Box("Libro_1", 91f, 97f, 0f, 7.5f, bookA, geo);
        Box("Libro_2", 97f, 103f, 0f, 11f, bookB, geo);
        MakeText("LIBRERO", deco, new Vector3(M(94f) * S, 9.2f * S, -0.62f), 0.04f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        // cascabel
        var bell = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        bell.name = "Cascabel";
        bell.transform.SetParent(pick, false);
        bell.transform.position = new Vector3(M(100.5f) * S, 12.3f * S, 0f);
        bell.transform.localScale = Vector3.one * 0.3f;
        bell.GetComponent<Renderer>().sharedMaterial = gold;
        Skin(bell, "cascabel");
        var bsc = bell.GetComponent<SphereCollider>();
        bsc.isTrigger = true;
        bsc.radius = 1.6f;
        var bcol = bell.AddComponent<Collectible>();
        bcol.type = CollectType.Bell;
        // ventilador
        var fanPole = Box("Ventilador_Poste", 108f, 109f, -3f, 8f, Mat("Poste", "#666666"), deco, false, 0.25f, 0.4f);
        var fan = Box("Ventilador_Plataforma", 106f, 111f, 8f, 8.6f, fanM, hazards);
        var fanRb = fan.AddComponent<Rigidbody>();
        fanRb.isKinematic = true;
        var fp = fan.AddComponent<FanPlatform>();
        fp.pole = fanPole.transform;
        fp.poleBottom = -8f * S;   // el poste se apoya en el fondo del foso
        fp.lowY = 8.3f * S;
        fp.highY = 11.8f * S;
        MakeText("VENTILADOR", deco, new Vector3(M(108.5f) * S, 15.5f * S, 0.6f), 0.062f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        // ovillo
        Vector3 pivot = new Vector3(M(115f) * S, 19f * S, 0f);
        float len = 9.4f * S;
        var ovillo = new GameObject("Ovillo");
        ovillo.transform.SetParent(hazards, false);
        ovillo.transform.position = pivot + new Vector3(0f, -len, 0f);
        var ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ball.name = "Ovillo_Bola";
        ball.transform.SetParent(ovillo.transform, false);
        ball.transform.localScale = Vector3.one * (3.6f * S);
        ball.GetComponent<Renderer>().sharedMaterial = red;
        Skin(ball, "ovillo");
        Object.DestroyImmediate(ball.GetComponent<Collider>());
        var top = GameObject.CreatePrimitive(PrimitiveType.Cube);
        top.name = "Ovillo_Superficie";
        top.transform.SetParent(ovillo.transform, false);
        top.transform.localPosition = new Vector3(0f, 1.8f * S, 0f);
        top.transform.localScale = new Vector3(0.6f, 0.1f, 1.0f);
        top.GetComponent<Renderer>().enabled = false;
        var orb = ovillo.AddComponent<Rigidbody>();
        orb.isKinematic = true;
        var pp = ovillo.AddComponent<PendulumPlatform>();
        pp.pivot = pivot;
        pp.length = len;
        var lrGo = new GameObject("Ovillo_Hilo");
        lrGo.transform.SetParent(ovillo.transform, false);
        var lr = lrGo.AddComponent<LineRenderer>();
        lr.positionCount = 2;
        lr.startWidth = 0.03f;
        lr.endWidth = 0.03f;
        lr.useWorldSpace = true;
        lr.sharedMaterial = red;
        pp.string_ = lr;
        Box("Ovillo_Riel", 111f, 119f, 19f, 19.6f, brownL, deco, false, 0.2f, 0.3f);
        Box("Riel_Soporte1", 111.4f, 112.4f, 18.6f, 19.6f, brownL, deco, false, 0.32f, 0.54f);   // unen el riel a la pared
        Box("Riel_Soporte2", 117.6f, 118.6f, 18.6f, 19.6f, brownL, deco, false, 0.32f, 0.54f);
        // foso (caída)
        Trigger("Zona_Foso", 100f, 121f, -9f, -2f, zones, ZoneType.Fall, 3f);
        Box("Foso_Fondo", 104f, 121f, -9f, -8f, Mat("FosoFondo", "#3A2F2A"), deco, false, 2f);

        // ---------- SECCIONES NUEVAS 6, 7 y 8 (coordenadas en cm finales): aprender y usar el DASH
        raw = true;
        Box("Pared_N1", 140f, 170f, 0f, 20.5f, Mat("ParedN1", "#F4E3EF"), geo, false, 0.1f, 0.73f);
        Box("Pared_N2", 170f, 200f, 0f, 20.5f, Mat("ParedN2", "#E2F1EA"), geo, false, 0.1f, 0.73f);
        Box("Pared_N3", 200f, 230f, 0f, 20.5f, Mat("ParedN3", "#F7EBD2"), geo, false, 0.1f, 0.73f);
        // piso con dos fosos que solo se cruzan con salto + dash
        Box("PisoN_1", 140f, 153f, -3f, 0f, wood, geo, true, D + 0.6f);
        Box("PisoN_2", 164f, 213f, -3f, 0f, wood, geo, true, D + 0.6f);
        Box("PisoN_3", 225f, 231f, -3f, 0f, wood, geo, true, D + 0.6f);
        var fosoM = Mat("FosoFondo", "#3A2F2A");
        Trigger("Zona_Foso_N1", 153f, 164f, -9f, -2f, zones, ZoneType.Fall, 3f);
        Box("Foso_Fondo_N1", 153f, 164f, -9f, -8f, fosoM, deco, false, 2f);
        Trigger("Zona_Foso_N2", 213f, 225f, -9f, -2f, zones, ZoneType.Fall, 3f);
        Box("Foso_Fondo_N2", 213f, 225f, -9f, -8f, fosoM, deco, false, 2f);

        // SECCIÓN 6: pasillo de croquetas (enseña el dash)
        MakeText("DASH: Shift", deco, new Vector3(146f * S, 9f * S, -0.62f), 0.075f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        MakeText("gasta 1 de ENERGIA", deco, new Vector3(146f * S, 7.2f * S, -0.62f), 0.055f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        Croqueta(144f, 0.8f, pick);
        Croqueta(148f, 0.8f, pick);
        Box("Cojin_N1", 167f, 172f, 0f, 3.5f, cushion, geo);
        Trigger("Descanso_CojinN1", 167f, 172f, 3f, 8f, zones, ZoneType.Rest);
        Checkpoint("CP_N1", 169.5f, 3.5f, zones);

        // SECCIÓN 7: pasillo de la Roomba rápida (el dash la atraviesa)
        MakeRoomba("Roomba_Rapida", 188f, 175f, 198f, 2.6f, gray, hazards);
        MakeText("ROOMBA RAPIDA", deco, new Vector3(186f * S, 9.5f * S, -0.62f), 0.062f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        Box("Estante_N", 181f, 191f, 5f, 5.6f, brownL, geo);
        Box("Estante_Soporte1", 182f, 182.8f, 0f, 5f, brownL, deco, false, 0.3f, 0.45f);
        Box("Estante_Soporte2", 189.2f, 190f, 0f, 5f, brownL, deco, false, 0.3f, 0.45f);
        Croqueta(184f, 5.6f, pick);
        Croqueta(188f, 5.6f, pick);
        Croqueta(173f, 0.8f, pick);

        // SECCIÓN 8: el gran salto (14 cm): caja de impulso + salto + dash
        Box("Caja_Impulso", 206f, 212f, 0f, 4f, orange, geo);
        MakeText("DASH + SALTO", deco, new Vector3(209f * S, 9f * S, -0.62f), 0.062f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        Croqueta(203f, 0.8f, pick);
        Croqueta(209f, 4.8f, pick);
        // escalón para subir a la encimera (antes era imposible: 10 cm > salto de 7 cm)
        Box("Taburete_Cocina", 225.5f, 229.5f, 0f, 3.5f, Mat("Taburete", "#B0875E"), geo);
        Checkpoint("CP_N2", 227f, 3.5f, zones);
        Box("Techo_B", 140f, 230f, 20.5f, 23f, Mat("TechoCasa", "#5B3F3A"), deco, true, D + 0.6f);
        raw = false;
        Box("Techo_A", -4f, 121f, 20.5f, 23f, Mat("TechoCasa", "#5B3F3A"), deco, true, D + 0.6f);
        Box("Techo_C", 121.5f, 151f, 20.5f, 23f, Mat("TechoCasa", "#5B3F3A"), deco, true, D + 0.6f);
        Box("Base_A", -4f, 121f, -9f, -3f, Mat("BaseCasa", "#3B2B3D"), deco, false, D + 0.6f);
        Box("Base_C", 121.5f, 151f, -9f, -3f, Mat("BaseCasa", "#3B2B3D"), deco, false, D + 0.6f);

        // ---------- SECCIÓN 5: cocina, puerta de gato, taburete, mueble TV, TV, juguete
        Box("Encimera", 121.5f, 129f, 0f, 9.5f, kitchen, geo);
        Box("Encimera_Plato", 122.4f, 125.6f, 9.5f, 9.9f, white, deco, false, 0.8f);
        MakeText("COCINA", deco, new Vector3(M(125f) * S, 5f * S, -0.62f), 0.065f, new Color(0.17f, 0.11f, 0.3f), 48, true);
        // puerta de gato
        var doorRoot = new GameObject("Puerta_Gato");
        doorRoot.transform.SetParent(hazards, false);
        Box("Puerta_Dintel", 131f, 135f, 7f, 20.5f, doorM, geo);
        var panel = Box("Puerta_Panel", 131f, 135f, 0f, 7f, doorM, hazards);
        var arch = Box("Puerta_Gatera", 132.2f, 133.8f, 0.4f, 3.6f, dark, deco, false, 0.02f, -0.62f);
        arch.transform.SetParent(panel.transform, true);
        MakeText("PUERTA DE GATO", deco, new Vector3(M(133f) * S, 8.5f * S, -0.62f), 0.04f, Color.white, 48);
        var dz = new GameObject("Puerta_Zona");
        dz.transform.SetParent(zones, false);
        dz.transform.position = new Vector3((M(131f) - 1.6f) * S, 2f * S, 0f);
        var dbc = dz.AddComponent<BoxCollider>();
        dbc.isTrigger = true;
        dbc.size = new Vector3(1.4f, 1.2f, D);
        var door = dz.AddComponent<Door>();
        door.panel = panel.transform;
        door.panelCollider = panel.GetComponent<Collider>();
        door.openHeight = 8.5f * S;
        // taburete y mueble TV
        Box("Taburete", 136f, 139.5f, 0f, 3.5f, Mat("Taburete", "#B0875E"), geo);
        // mueble de la TV, más ancho y con cada cosa bien separada (coordenadas finales en cm)
        Box("Mueble_TV", 142f, 150f, 0f, 6.5f, brown, geo);
        float mx0 = M(142f), mw = M(150f) - M(142f), mc = mx0 + mw * 0.5f;
        raw = true;
        for (int di = 0; di < 3; di++)
            Box("Mueble_Puerta" + (di + 1), mx0 + 0.6f + di * (mw - 1.2f) / 3f, mx0 + 0.6f + (di + 1) * (mw - 1.2f) / 3f - 0.3f, 0.6f, 5.9f, di == 1 ? brown : brownL, deco, false, 0.05f, -0.62f);
        Box("Control_Remoto", mx0 + 1.2f, mx0 + 3.6f, 6.5f, 7.2f, tv, deco, false, 0.3f);
        Box("Control_Boton", mx0 + 1.5f, mx0 + 2.1f, 7.2f, 7.4f, red, deco, false, 0.12f);
        // TV en la pared, centrada sobre el mueble y más arriba
        Box("TV_Marco", mc - 5.5f, mc + 5.5f, 13.8f, 19.8f, tv, deco, false, 0.1f, 0.6f);
        var screenGo = Box("TV_Pantalla", mc - 4.7f, mc + 4.7f, 14.5f, 19.1f, screenM, deco, false, 0.05f, 0.52f);
        screenGo.GetComponent<Renderer>().sharedMaterial = new Material(screenGo.GetComponent<Renderer>().sharedMaterial);
        var tvText = MakeText("¡RUIDO!", screenGo.transform, new Vector3(mc * S, 16.8f * S, 0.47f), 0.12f, new Color(0.75f, 0.1f, 0.1f), 64);
        var tvc = screenGo.AddComponent<TVController>();
        tvc.screen = screenGo.GetComponent<Renderer>();
        tvc.label = tvText;
        raw = false;
        Trigger("Zona_Ruido_TV", 142f, 150f, 6f, 24f, zones, ZoneType.Noise);
        // juguete (meta)
        var toy = new GameObject("Juguete_META");
        toy.transform.SetParent(pick, false);
        toy.transform.position = new Vector3((M(150f) - 2.2f) * S, 9.2f * S, 0f);
        var mf = toy.AddComponent<MeshFilter>();
        var starMesh = StarMesh(0.3f);
        Directory.CreateDirectory("Assets/Models");
        AssetDatabase.CreateAsset(starMesh, "Assets/Models/Star.asset");
        mf.sharedMesh = starMesh;
        toy.AddComponent<MeshRenderer>().sharedMaterial = Mat("Juguete", "#F4C430");
        var tbc = toy.AddComponent<SphereCollider>();
        tbc.isTrigger = true;
        tbc.radius = 0.5f;
        toy.AddComponent<Collectible>().type = CollectType.Toy;

        // ---------- letras S-U-R-I-E
        Letter(0, 18.5f, 3.5f, pick);
        Letter(1, 42f, 16f, pick);
        Letter(2, 53.3f, 4.4f, pick);
        var lI = Letter(3, 67f, 4f, pick);
        lI.transform.SetParent(caja.transform, true);
        raw = true;
        Letter(4, mx0 + mw * 0.58f, 6.5f, pick);
        raw = false;

        // ====================================================================
        //  NIVEL BONUS "La alacena de croquetas" (se entra con S-U-R-I-E completo)
        //  Está en el mismo escenario, lejos a la derecha (coordenadas crudas en cm).
        // ====================================================================
        raw = true;
        var bonusRoot = new GameObject("Bonus_Alacena").transform; bonusRoot.SetParent(root);
        var bWall = Mat("ParedAlacena", "#4A3426");
        var bShelf = Mat("EstanteAlacena", "#B07A4A");
        var bShelfD = Mat("EstanteAlacenaOsc", "#8A5A36");
        const float BX0 = 395f, BX1 = 600f;
        Box("Bonus_Fondo", BX0, BX1, -14f, 30f, bWall, bonusRoot, false, 0.2f, 0.7f);
        // latas y frascos de decoración al fondo (sin collider)
        string[] canCol = { "#C0504D", "#4F81BD", "#F2C14E", "#9BBB59", "#8064A2", "#E8845A" };
        for (int i = 0; i < 16; i++)
        {
            var can = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            can.name = "Bonus_Lata_" + i;
            can.transform.SetParent(bonusRoot, false);
            float cx = BX0 + 8f + i * 12.5f, ch = 3.5f + (i * 7 % 5) * 1.2f;
            can.transform.position = new Vector3(cx * S, (14f + ch * 0.5f + (i % 3) * 5f) * S, 0.55f);
            can.transform.localScale = new Vector3(2.4f * S, ch * 0.5f * S, 2.4f * S);
            can.GetComponent<Renderer>().sharedMaterial = Mat("Lata" + (i % 6), canCol[i % 6]);
            Object.DestroyImmediate(can.GetComponent<Collider>());
        }
        MakeText("ALACENA SECRETA", bonusRoot, new Vector3(412f * S, 8.5f * S, -0.2f), 0.1f, new Color(1f, 0.9f, 0.5f), 64, true);
        MakeText("¡Llega al frasco!", bonusRoot, new Vector3(578f * S, 12.5f * S, -0.2f), 0.07f, new Color(1f, 0.9f, 0.5f), 64, true);

        // plataformas fijas: (x0, x1, altura superior)
        float[,] plats =
        {
            { 395f, 418f, 0f },
            { 422f, 428f, 2f }, { 433f, 439f, 4f }, { 444f, 450f, 6f }, { 455f, 461f, 4f },
            { 480f, 508f, 4f },                       // estante largo con Roomba
            { 521f, 527f, 4f },                       // tras el salto con dash (hueco de 13 cm)
            { 543f, 549f, 10f }, { 553f, 558f, 8f }, { 562f, 567f, 10f },
            { 572f, 590f, 6f }
        };
        for (int i = 0; i < plats.GetLength(0); i++)
        {
            float ptop = plats[i, 2];
            Box("Bonus_Estante_" + i, plats[i, 0], plats[i, 1], ptop - (i == 0 ? 2f : 1.2f), ptop, i % 2 == 0 ? bShelf : bShelfD, bonusRoot);
        }
        // plataformas móviles
        var s1 = Box("Bonus_Mov_H", 467.5f, 472.5f, 3.2f, 4f, Mat("PlataformaMovil", "#6FB7C9"), hazards);
        s1.AddComponent<Rigidbody>().isKinematic = true;
        var sp1 = s1.AddComponent<SlidePlatform>(); sp1.amplitude = new Vector3(4f * S, 0f, 0f); sp1.period = 3.6f;
        var s2 = Box("Bonus_Mov_V", 533f, 538f, 3.2f, 4f, Mat("PlataformaMovil", "#6FB7C9"), hazards);
        s2.AddComponent<Rigidbody>().isKinematic = true;
        var sp2 = s2.AddComponent<SlidePlatform>(); sp2.amplitude = new Vector3(0f, 3f * S, 0f); sp2.period = 4.4f;
        s2.transform.position += new Vector3(0f, 3f * S, 0f);   // oscila entre altura 4 y 10
        // peligro: Roomba rápida sobre el estante largo
        var rb2 = MakeRoomba("Roomba_Bonus", 486f, 483f, 505f, 2.7f, gray, hazards);
        rb2.transform.position = new Vector3(486f * S, 4f * S + 0.12f, 0f);
        // zona de descanso + punto de control en el estante largo (recupera energía para el dash)
        Trigger("Bonus_Descanso", 498f, 508f, 4f, 9f, zones, ZoneType.Rest);
        Checkpoint("CP_Bonus_1", 458f, 4f, zones);
        Checkpoint("CP_Bonus_2", 503f, 4f, zones);
        Checkpoint("CP_Bonus_3", 556f, 8f, zones);
        Trigger("Bonus_Foso", BX0, BX1 + 10f, -14f, -2.5f, zones, ZoneType.Fall, 3f);
        // croquetas (+100 puntos cada una): en arcos que invitan a saltar
        float[,] cro =
        {
            { 425f, 4.5f }, { 436f, 6.5f }, { 447f, 8.5f }, { 458f, 6.5f }, { 470f, 7f },
            { 490f, 5.5f }, { 494f, 8.2f }, { 500f, 5.5f },
            { 514f, 8f }, { 524f, 6.5f }, { 535f, 12f }, { 546f, 12.5f }, { 555.5f, 10.5f }, { 564.5f, 12.5f }, { 580f, 8f }
        };
        for (int i = 0; i < cro.GetLength(0); i++) Croqueta(cro[i, 0], cro[i, 1], pick);
        // frasco de meta
        var jar = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        jar.name = "Bonus_Frasco";
        jar.transform.SetParent(pick, false);
        jar.transform.position = new Vector3(584f * S, (6f + 2.2f) * S, 0f);
        jar.transform.localScale = new Vector3(2.6f * S, 2.2f * S, 2.6f * S);
        jar.GetComponent<Renderer>().sharedMaterial = Mat("Frasco", "#F4C430");
        var jcol = jar.GetComponent<Collider>(); Object.DestroyImmediate(jcol);
        var jsc = jar.AddComponent<SphereCollider>(); jsc.isTrigger = true; jsc.radius = 1.3f;
        jar.AddComponent<Collectible>().type = CollectType.BonusEnd;
        MakeText("FRASCO", jar.transform, jar.transform.position + new Vector3(0f, 0f, -0.45f), 0.05f, Color.black, 48);
        Vector3 bonusStartPos = new Vector3(402f * S, 1.6f, 0f);
        float bonusCamMin = BX0 * S + 5.5f, bonusCamMax = BX1 * S - 5.5f;
        raw = false;

        // ---------- zonas de descanso y puntos de control
        Trigger("Descanso_Cama", 2f, 13f, 2.5f, 8f, zones, ZoneType.Rest);
        Trigger("Descanso_Cojin1", 16f, 21f, 3f, 8f, zones, ZoneType.Rest);
        Trigger("Descanso_Cojin2", 24f, 29f, 3f, 8f, zones, ZoneType.Rest);
        Checkpoint("CP_Cojin2", 26.5f, 3.5f, zones);
        Checkpoint("CP_Sofa", 40f, 4f, zones);
        Checkpoint("CP_Mesa", 55.5f, 4.4f, zones);
        Checkpoint("CP_Puf", 86f, 7.5f, zones);
        Checkpoint("CP_Libro2", 99.5f, 11f, zones);
        Checkpoint("CP_Encimera", 125f, 9.5f, zones);
        Checkpoint("CP_Taburete", 137.7f, 3.5f, zones);

        // ---------- jugador (Surie)
        Vector3 startPos = new Vector3(M(7.5f) * S, 3f * S + 1.6f, 0f);   // Surie cae sobre la cama
        var player = new GameObject("Surie_Jugadora");
        player.tag = "Player";
        player.transform.position = startPos;
        var prb = player.AddComponent<Rigidbody>();
        prb.mass = 1f;
        var cap = player.AddComponent<CapsuleCollider>();
        cap.direction = 0;          // eje X
        cap.radius = 0.2f;
        cap.height = 0.85f;
        cap.center = new Vector3(0f, 0.22f, 0f);
        var pc = player.AddComponent<PlayerController2D>();
        var model = Cat("Surie", player.transform, Vector3.zero, 0.55f);
        pc.model = model.transform;

        // ---------- Benito (no jugable)
        var benito = new GameObject("Benito_NPC");
        benito.transform.position = new Vector3(M(26.5f) * S, 3.5f * S, 0f);
        var bm = Cat("Benito", benito.transform, Vector3.zero, 0.5f);
        bm.transform.localRotation = Quaternion.identity;   // BenitoRun gira el objeto raíz
        var br = benito.AddComponent<BenitoRun>();
        br.player = player.transform;
        br.triggerX = 1.2f;
        br.waypoints = new[]
        {
            new Vector3(M(30f) * S, 0f, 0.0f), new Vector3(M(60f) * S, 0f, 0.0f), new Vector3(M(100f) * S, 2f * S, 0.0f),
            new Vector3(160f * S, 0f, 0.0f), new Vector3(195f * S, 0f, 0.0f), new Vector3(222f * S, 0f, 0.0f),
            new Vector3(M(135f) * S, 0f, 0.0f), new Vector3(M(146f) * S, 6.5f * S, 0.0f)
        };

        // ---------- gestor del juego
        var gmGo = new GameObject("GameManager");
        var gm = gmGo.AddComponent<GameManager>();
        gm.player = pc;
        gm.startPoint = startPos;
        gm.respawnPoint = startPos;
        gm.sceneStamp = BuildInfo.Stamp;
        gm.bonusStart = bonusStartPos; gm.bonusCamMin = bonusCamMin; gm.bonusCamMax = bonusCamMax;
        gm.sectionStartsCm = new float[] { M(0f), M(30f), M(60f), M(90f), M(104f), 140f, 170f, 200f, 230f };

        // ---------- cámara y luz
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 35f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = C("#251C3F");
        camGo.AddComponent<AudioListener>();
        var cf = camGo.AddComponent<CameraFollow>();
        cf.target = player.transform;
        cf.minX = 5.5f;
        cf.maxX = M(150f) * S - 5.5f;
        camGo.transform.position = new Vector3(startPos.x, 2f, -10f);

        var lightGo = new GameObject("Luz_Direccional");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.15f;
        light.color = new Color(1f, 0.96f, 0.9f);
        lightGo.transform.rotation = Quaternion.Euler(38f, -28f, 0f);
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.62f, 0.62f, 0.66f);

        // ---------- guardar escena
        Directory.CreateDirectory("Assets/Scenes");
        string scenePath = "Assets/Scenes/Nivel_Surie.unity";
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        ExportLayout(geo, gm.sectionStartsCm);
        BuildMenuScene();
        var menuAsset = AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/Scenes/Menu_Surie.unity");
        if (menuAsset != null) EditorSceneManager.playModeStartScene = menuAsset;   // Play siempre arranca en el menú
        RegisterScenes();
        Debug.Log("Nivel de Surie construido. Pulsa Play. Controles: A/D o flechas = mover, Espacio = saltar, W = trepar cortina, R = reiniciar.");
        if (missingSkins > 0) EditorUtility.DisplayDialog("Surie · modelos 3D", "Faltan " + missingSkins + " modelos en Assets/Models/Muebles: esas piezas se ven como cubos.\n\nCopia la carpeta Assets/Models/Muebles del parche (con sus .obj y .mtl), espera a que Unity los importe y vuelve a ejecutar Surie > Construir nivel completo.", "OK");
        EditorUtility.DisplayDialog("Surie", "¡Nivel construido!\n\nAbre Assets/Scenes/Menu_Surie y pulsa Play (menú principal).\n\n\nA/D o flechas = mover\nEspacio = saltar\nW = trepar la cortina\nR = reiniciar", "OK");
    }

    // ---- menú principal (escena Menu_Surie) ----
    static void BuildMenuScene()
    {
        var sc = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = C("#261F52");
        camGo.AddComponent<AudioListener>();
        new GameObject("MenuPrincipal").AddComponent<MainMenu>();
        EditorSceneManager.SaveScene(sc, "Assets/Scenes/Menu_Surie.unity");

        // historieta de inicio
        var sc2 = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var cg = new GameObject("Main Camera");
        cg.tag = "MainCamera";
        var cc = cg.AddComponent<Camera>();
        cc.clearFlags = CameraClearFlags.SolidColor;
        cc.backgroundColor = C("#1A1029");
        cg.AddComponent<AudioListener>();
        new GameObject("Historieta").AddComponent<ComicIntro>();
        EditorSceneManager.SaveScene(sc2, "Assets/Scenes/Comic_Surie.unity");
    }

    // ---- exporta la geometría del nivel (cm) para dibujar el mapa de calor en el dashboard ----
    static void ExportLayout(Transform geo, float[] sections)
    {
        var sb = new System.Text.StringBuilder();
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        sb.Append("{\"scale\":").Append((1f / S).ToString(ci)).Append(",\"sections\":[");
        for (int i = 0; i < sections.Length; i++) sb.Append(i > 0 ? "," : "").Append(sections[i].ToString("0.0", ci));
        sb.Append("],\"blocks\":[");
        bool first = true;
        foreach (var c in geo.GetComponentsInChildren<Collider>())
        {
            if (c.name.StartsWith("Pared") || c.name.StartsWith("Limite") || c.name.StartsWith("Techo")) continue;
            Bounds bd = c.bounds;
            if (!first) sb.Append(",");
            first = false;
            sb.Append("{\"n\":\"").Append(c.name).Append("\",\"x0\":").Append((bd.min.x / S).ToString("0.0", ci))
              .Append(",\"x1\":").Append((bd.max.x / S).ToString("0.0", ci))
              .Append(",\"y0\":").Append((bd.min.y / S).ToString("0.0", ci))
              .Append(",\"y1\":").Append((bd.max.y / S).ToString("0.0", ci)).Append("}");
        }
        sb.Append("]}");
        Directory.CreateDirectory("Assets/Metrics");
        File.WriteAllText("Assets/Metrics/level_layout.json", sb.ToString());
    }
}
#endif
